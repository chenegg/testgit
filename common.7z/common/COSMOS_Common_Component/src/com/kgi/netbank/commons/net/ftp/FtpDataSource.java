package com.kgi.netbank.commons.net.ftp;

import java.util.Map;
import com.cosmos.ebank.util.AESUtils;

public class FtpDataSource {

	public FtpDataSource() {

	}
	
	protected String username;
	protected String host;
	protected String password;
	protected String port;
	protected int bufferSize;
	protected int clientMode;
	protected int fileType;
	protected String controlEncoding;
	private Integer connectTimeout;
	private Integer defaultTimeout;
	private Integer dataTimeout;
	private String filenameRegex;
	private Map<String, String> putFiles; // key: remote file, value: local file
	private Map<String, String> getFiles; // key: remote file, value: local file
	
	private Map<String, String> otherProperties; //放置其它設定
	
	
	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = Integer.valueOf(connectTimeout);
	}

	public void setDefaultTimeout(int defaultTimeout) {
		this.defaultTimeout = Integer.valueOf(defaultTimeout);
	}

	public void setDataTimeout(int dataTimeout) {
		this.dataTimeout = Integer.valueOf(dataTimeout);
	}

	public void setUsername(String user) {
		this.username = AESUtils.getDecryptPassword(user, "www.cosmos.com.tw/ebank");
	}

	public void setPassword(String pass) {
		this.password = AESUtils.getDecryptPassword(pass, "www.cosmos.com.tw/ebank");
	}

	public void setFileType(int fileType) {
		this.fileType = fileType;
	}

	public void setControlEncoding(String controlEncoding) {
		this.controlEncoding = controlEncoding;
	}

	public void setBufferSize(int bufferSize) {
		this.bufferSize = bufferSize;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public void setClientMode(int clientMode) {
		this.clientMode = clientMode;
	}

	public Integer getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(Integer connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public Integer getDefaultTimeout() {
		return defaultTimeout;
	}

	public void setDefaultTimeout(Integer defaultTimeout) {
		this.defaultTimeout = defaultTimeout;
	}

	public Integer getDataTimeout() {
		return dataTimeout;
	}

	public void setDataTimeout(Integer dataTimeout) {
		this.dataTimeout = dataTimeout;
	}

	public String getFilenameRegex() {
		return filenameRegex;
	}

	public void setFilenameRegex(String filenameRegex) {
		this.filenameRegex = filenameRegex;
	}

	public String getUsername() {
		return username;
	}

	public String getHost() {
		return host;
	}

	public String getPassword() {
		return password;
	}

	public String getPort() {
		return port;
	}

	public int getBufferSize() {
		return bufferSize;
	}

	public int getClientMode() {
		return clientMode;
	}

	public int getFileType() {
		return fileType;
	}

	public String getControlEncoding() {
		return controlEncoding;
	}

	public Map<String, String> getPutFiles() {
		return putFiles;
	}

	public void setPutFiles(Map<String, String> putFiles) {
		this.putFiles = putFiles;
	}

	public Map<String, String> getGetFiles() {
		return getFiles;
	}

	public void setGetFiles(Map<String, String> getFiles) {
		this.getFiles = getFiles;
	}

	public Map<String, String> getOtherProperties() {
		return otherProperties;
	}

	public void setOtherProperties(Map<String, String> otherProperties) {
		this.otherProperties = otherProperties;
	}
	
}

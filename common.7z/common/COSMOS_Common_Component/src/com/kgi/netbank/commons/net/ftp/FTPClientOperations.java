package com.kgi.netbank.commons.net.ftp;

import java.io.IOException;
import java.util.Collection;

import org.apache.commons.net.ftp.FTPFile;

/** 
 * FTP操作的客戶端操作上傳下載 
 * @author longgangbai 
 * 
 */
public interface FTPClientOperations {
	/** 
	 * 文件上傳的方法 
	 * @param remote 
	 * @param local 
	 * @return 
	 * @throws IOException 
	 */
	public UploadStatus upload(String remote, String local) throws IOException;

	/** 
	 *  
	 * 從遠程服務器目錄下載文件到本地服務器目錄中 
	 * @param localdir FTP服務器保存目錄 
	 * @param remotedir FTP下載服務器目錄 
	 * @param localTempFile臨時下載記錄文件 
	 * @return 成功返回true，否則返回false 
	 */
	public Collection<String> downloadList(final String localdir, final String remotedir, final String localTmpFile)
			throws IOException;

	/** 
	 * 文件下載的方法 
	 * @param remote 
	 * @param local 
	 * @return 
	 * @throws IOException 
	 */
	public DownloadStatus downloadFile(String local, String remote) throws IOException;

	/** 
	 * 查看服務器上文件列表方法 
	 * @param remotedir 
	 * @return 
	 * @throws IOException 
	 */
	public FTPFile[] list(final String remotedir) throws IOException;
}
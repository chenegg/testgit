package com.kgi.netbank.commons.net.ftp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collection;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.FalseFileFilter;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.log4j.Logger;

/** 
 * 文件操作工具類 
 *  
 * @author longgangbai 
 *  
 */
public class FileOperateUtils {

	private static final Logger logger = Logger.getLogger(FileOperateUtils.class);

	/** 
	 * 查找需要合併文件的臨時文件信息  
	 *  
	 * @param directory 
	 *          臨時文件所在的目錄 
	 * @param prefix 
	 *          臨時文件的前綴 
	 * @param caseSensitivity 
	 *          臨時文件的大小寫敏感 
	 * @return 
	 */
	public static Collection<File> searchPrefixFile(File directory, String prefix, boolean caseSensitivity) {
		IOCase iocase = IOCase.INSENSITIVE;
		if (caseSensitivity) {
			iocase = IOCase.SENSITIVE;
		}
		// 創建相關的過濾器
		IOFileFilter fileFilter = FileFilterUtils.prefixFileFilter(prefix, iocase);
		// 檢查相關的過濾信息
		return FileUtils.listFiles(directory, fileFilter, FalseFileFilter.INSTANCE);
	}

	/** 
	 *  查找目錄下特定後綴的文件 
	 * @param directory     
	 *       特定的目錄 
	 * @param extensions 
	 *      臨時文件的後綴擴展 
	 * @param recursive 
	 *      是否查詢臨時文件所在的目錄下的子目錄 
	 * @return 
	 */
	public static Collection<File> searchExtensionFile(File directory, String[] extensions, boolean recursive) {
		return FileUtils.listFiles(directory, extensions, recursive);
	}

	/** 
	 * 文件追加功能 
	 * @param lines 
	 * @param tmpFilePath 
	 */
	public static void writeLinesToFile(Collection<String> lines, String tmpFilePath) {
		OutputStream output = null;
		try {
			output = new FileOutputStream(tmpFilePath, true);
			IOUtils.writeLines(lines, "UTF-8", output);
		} catch (Exception e) {
			logger.error(tmpFilePath + "追加文件失敗" + e.getMessage());
		}

	}
}
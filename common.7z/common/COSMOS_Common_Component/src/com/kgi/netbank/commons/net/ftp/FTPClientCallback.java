package com.kgi.netbank.commons.net.ftp;

import java.io.IOException;

import org.apache.commons.net.ftp.FTPClient;

/** 
 * FTPCLient回調 
 * @author longgangabai 
 * 
 * @param <T> 
 */
public interface FTPClientCallback<T> {

	public T doTransfer(FTPClient ftp) throws IOException;

}
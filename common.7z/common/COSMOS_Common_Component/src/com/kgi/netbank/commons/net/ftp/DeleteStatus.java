package com.kgi.netbank.commons.net.ftp;

import com.ibm.tw.commons.util.EnumUtils;

public enum DeleteStatus {
	// Create_Directory_Fail(0, "遠程服務器相應目錄創建失敗"), // 遠程服務器相應目錄創建失敗
	// Create_Directory_Success(1, "遠程服務器闖將目錄成功"), // 遠程服務器闖將目錄成功
	Upload_Del_File_Success(2, "刪除文件成功"), // 上傳新文件成功
	Upload_Del_File_Failed(3, "刪除文件失敗"); // 上傳新文件失敗

	private int code;

	private String description;

	private DeleteStatus(int code, String description) {
		this.code = code;
		this.description = description;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/** 
	 * 下載狀態中中使用的code 
	 * @param code 
	 * @return 
	 */
	public static DeleteStatus fromCode(int code) {
		return EnumUtils.fromEnumProperty(DeleteStatus.class, "code", code);
	}
}
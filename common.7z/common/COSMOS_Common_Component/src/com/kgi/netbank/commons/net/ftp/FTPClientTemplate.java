package com.kgi.netbank.commons.net.ftp;

import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.log4j.Logger;

/** 
 * Ftp回調模板 
 *  
 * @author longgangbai 
 * 
 */
public class FTPClientTemplate implements FTPClientOperations {
	private static final Logger logger = Logger.getLogger(FTPClientTemplate.class);

	private static String DEAFULT_REMOTE_CHARSET = "UTF-8";
	private static int DEAFULT_REMOTE_PORT = 21;
	private static String separator = File.separator;
	private FTPClientConfig ftpClientConfig;

	protected String username;
	protected String host;
	protected String password;
	protected String port;
	protected int bufferSize;
	protected int clientMode;
	protected int fileType;
	protected String controlEncoding;
	private Integer connectTimeout;
	private Integer defaultTimeout;
	private Integer dataTimeout;

	public FTPClientTemplate() {

		this.port = "21";

		this.bufferSize = 2048;

		this.clientMode = 0;

		this.fileType = 2;

		this.controlEncoding = "ISO-8859-1";
	}

	public FTPClientTemplate(String host, String user, String pwd, String port) {
		this.host = host;
		this.username = user;
		this.password = pwd;
		this.port = port;
	}

	/** 
	 * 查看服務器上文件列表方法 
	 * @param remotedir 
	 * @return 
	 * @throws IOException 
	 */
	public FTPFile[] list(final String remotedir) throws IOException {
		return execute(new FTPClientCallback<FTPFile[]>() {
			public FTPFile[] doTransfer(FTPClient ftp) throws IOException {
				ftp.changeWorkingDirectory(remotedir);
				FTPFile[] files = ftp.listFiles(remotedir);
				return files;
			}
		});
	}

	/** 
	 * 文件上傳的方法 
	 * @param remote 
	 * @param local 
	 * @return 
	 * @throws IOException 
	 */
	public DeleteStatus deleteFile(final String remote) throws IOException {
		return execute(new FTPClientCallback<DeleteStatus>() {
			public DeleteStatus doTransfer(FTPClient ftpClient) throws IOException {
				return FtpHelper.getInstance().deleteFile(ftpClient, remote);
			}
		});
	}

	/** 
	 * 文件上傳的方法 
	 * @param remote 
	 * @param local 
	 * @return 
	 * @throws IOException 
	 */
	public UploadStatus upload(final String local, final String remote) throws IOException {
		return execute(new FTPClientCallback<UploadStatus>() {
			public UploadStatus doTransfer(FTPClient ftpClient) throws IOException {
				return FtpHelper.getInstance().upload(ftpClient, local, remote);
			}
		});
	}

	/** 
	 * 上傳文件到服務器,新上傳和斷點續傳 
	 * @param remoteFile  遠程文件名，在上傳之前已經將服務器工作目錄做了改變 
	 * @param localFile   本地文件File句柄，絕對路徑 
	 * @param processStep  需要顯示的處理進度步進值 
	 * @param ftpClient  FTPClient引用 
	 * @return 
	 * @throws IOException 
	 */
	public UploadStatus uploadFile(String remoteFile, File localFile, FTPClient ftpClient, long remoteSize)
			throws IOException {
		return FtpHelper.getInstance().uploadFile(remoteFile, localFile, ftpClient, remoteSize);
	}

	/** 
	 * 從遠程服務器目錄下載文件到本地服務器目錄中 
	 * @param localdir FTP服務器保存目錄 
	 * @param remotedir FTP下載服務器目錄 
	 * @param localTempFile臨時下載記錄文件 
	 * @return  成功下載記錄 
	 */
	public Collection<String> downloadList(final String localdir, final String remotedir, final String localTmpFile)
			throws IOException {
		return execute(new FTPClientCallback<Collection<String>>() {
			public Collection<String> doTransfer(final FTPClient ftp) throws IOException {
				// 切換到下載目錄的中
				ftp.changeWorkingDirectory(remotedir);
				// 獲取目錄中所有的文件信息
				FTPFile[] ftpfiles = ftp.listFiles();
				Collection<String> fileNamesCol = new ArrayList<String>();
				// 判斷文件目錄是否為空
				if (!ArrayUtils.isEmpty(ftpfiles)) {
					for (FTPFile ftpfile : ftpfiles) {
						String remoteFilePath = remotedir + separator + ftpfile.getName();
						String localFilePath = localdir + separator + ftpfile.getName();
						System.out.println("remoteFilePath =" + remoteFilePath + " localFilePath=" + localFilePath);
						// 單個文件下載狀態
						DownloadStatus downStatus = downloadFile(remoteFilePath, localFilePath);
						if (downStatus == DownloadStatus.Download_New_Success) {
							// 臨時目錄中添加記錄信息
							fileNamesCol.add(remoteFilePath);
						}
					}
				}
				if (CollectionUtils.isNotEmpty(fileNamesCol)) {
					FileOperateUtils.writeLinesToFile(fileNamesCol, localTmpFile);
				}
				return fileNamesCol;
			}
		});
	}

	/** 
	 * 從FTP服務器上下載文件,支持斷點續傳，上傳百分比匯報 
	 * @param remote  遠程文件路徑 
	 * @param local 本地文件路徑 
	 * @return 上傳的狀態 
	 * @throws IOException 
	 *  
	 */
	public DownloadStatus downloadFile(final String remote, final String local) throws IOException {
		return execute(new FTPClientCallback<DownloadStatus>() {
			public DownloadStatus doTransfer(FTPClient ftpClient) throws IOException {
				DownloadStatus result = FtpHelper.getInstance().download(ftpClient, remote, local);
				return result;
			}
		});
	}

	/** 
	 * 執行FTP回調操作的方法 
	 * @param callback   回調的函數 
	 * @throws IOException 
	 */
	public <T> T execute(FTPClientCallback<T> callback) throws IOException {
		FTPClient ftp = new FTPClient();
		try {

			/*
			 * if(getFtpClientConfig()!=null){
			 * ftp.configure(getFtpClientConfig());
			 * ftpClientConfig.setServerTimeZoneId
			 * (TimeZone.getDefault().getID()); }
			 */
			// 登錄FTP服務器
			try {
				// 設置超時時間
				ftp.setDataTimeout(7200);
				// 設置默認編碼
				ftp.setControlEncoding(DEAFULT_REMOTE_CHARSET);
				// 設置默認端口
				ftp.setDefaultPort(DEAFULT_REMOTE_PORT);
				// 設置是否顯示隱藏文件
				ftp.setListHiddenFiles(false);
				// 連接ftp服務器
				if (StringUtils.isNotEmpty(port) && NumberUtils.isDigits(port)) {
					ftp.connect(host, Integer.valueOf(port));
				} else {
					ftp.connect(host);
				}
			} catch (ConnectException e) {
				logger.error("連接FTP服務器失敗：" + ftp.getReplyString() + ftp.getReplyCode());
				throw new IOException("Problem connecting the FTP-server fail", e);
			}
			// 得到連接的返回編碼
			int reply = ftp.getReplyCode();

			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
			}
			// 登錄失敗權限驗證失敗
			if (!ftp.login(username, password)) {
				ftp.quit();
				ftp.disconnect();
				logger.error("連接FTP服務器用戶或者密碼失敗：：" + ftp.getReplyString());
				throw new IOException("Cant Authentificate to FTP-Server");
			}
			if (logger.isDebugEnabled()) {
				logger.info("成功登錄FTP服務器：" + host + " 端口：" + port);
			}
			ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
			// 回調FTP的操作
			return callback.doTransfer(ftp);
		} finally {
			// FTP退出
			ftp.logout();
			// 斷開FTP連接
			if (ftp.isConnected()) {
				ftp.disconnect();
			}
		}
	}

	protected String resolveFile(String file) {
		return null;
		// return file.replace(System.getProperty("file.separator").charAt(0),
		// this.remoteFileSep.charAt(0));
	}

	/** 
	 * 獲取FTP的配置操作系統 
	 * @return 
	 */
	public FTPClientConfig getFtpClientConfig() {
		// 獲得系統屬性集
		Properties props = System.getProperties();
		// 操作系統名稱
		String osname = props.getProperty("os.name");
		// 針對window系統
		if (osname.equalsIgnoreCase("Windows XP")) {
			ftpClientConfig = new FTPClientConfig(FTPClientConfig.SYST_NT);
			// 針對linux系統
		} else if (osname.equalsIgnoreCase("Linux")) {
			ftpClientConfig = new FTPClientConfig(FTPClientConfig.SYST_UNIX);
		}
		if (logger.isDebugEnabled()) {
			logger.info("the ftp client system os Name " + osname);
		}
		return ftpClientConfig;
	}

}
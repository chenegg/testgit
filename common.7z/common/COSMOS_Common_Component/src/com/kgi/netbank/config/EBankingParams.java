package com.kgi.netbank.config;

public class EBankingParams extends CacheManager {
	/** 匯率到價 **/
	public static final String RATENOTIFY_URL = "webservice.rateNotify.ip";

	public static final String TRUSTSERVICE_URL = "TRUSTSERVICE_URL";

	public static final String WEBSERVICE_NEWACCOUNT_URL = "WEBSERVICE_NEWACCOUNT_URL";

	/** 資產負債總覽 **/
	public static final String ASSETS_WEBSERVICE_URL = "ASSETS_WEBSERVICE_URL";

	/** 信用卡 **/
	public static final String RTES_WEBSERVICE_URL = "RTES_WEBSERVICE_URL";

	/** SSO **/
	public static final String NETBANK_WEBSERVICE_URL = "NETBANK_WEBSERVICE_URL";

	public static final String WEBSERVICE_COSALE_AUTHORIZATION_URL = "webservice.cosale_authorization.url";

	public static final String WEBSERVICE_FCS_URL = "webservice.fcs.url";

	public static final String WEBSERVICE_FCS_TIMEOUT = "webservice.fcs.timeout";

	public static final String METAAMLSERVICE_URL = "meta.aml.service.url";

	// public static final String ASSETS_WEBSERVICE_URL =
	// "assets.webservice.url";

	public EBankingParams() throws Exception {
		load();
	}

	@Override
	public void load() throws Exception {
		if (properties == null) {
			synchronized (this) {
				/** 先抓config底下的,當預留找不到改抓tomcat下 **/
				if (properties == null) {
					properties = loadFile(CONTEXT_REAL_CONFIG_PATH, "e-Banking.xml");
				}
			}
		}
	}

}

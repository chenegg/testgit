package com.kgi.netbank.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.InvalidPropertiesFormatException;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cosmos.netbank.config.EBankingConfig;
import cosmos.netbank.config.GetVbFilePath;
import cosmos.netbank.gateway.SNA;

public abstract class CacheManager {
	protected static Logger logger = LoggerFactory.getLogger(CacheManager.class);

	/**
	 * 設定檔服務
	 */
	private static Map<Class<? extends CacheManager>, CacheManager> caches = new HashMap<Class<? extends CacheManager>, CacheManager>();
	/**
	 * 
	 * 本文路徑
	 */
	public static String CONTEXT_REAL_PATH;

	/**
	 * 
	 * Config路徑
	 */
	public static String CONTEXT_REAL_CONFIG_PATH;

	protected Properties properties;

	public abstract void load() throws Exception;

	/**
	 * get setting.properties 的 Value by key
	 * 
	 * @param key
	 * @return
	 */
	public String getString(String key) {
		String returnValue = (String) getObject(key);
		return returnValue == null ? "?????key=" + key : StringUtils.trim(returnValue);
	}

	public int getInteger(String key) {
		return Integer.parseInt(getString(key));
	}

	public Object getObject(String key) {
		try {
			load();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return properties == null ? null : properties.get(key);
	}

	public Properties getProperties() {
		return properties;
	}

	public static void setCONTEXT_REAL_PATH() {
		setCONTEXT_REAL_PATH(null);
	}

	// public static Setting setting;
	//
	// public static EBankingConfig eBankingConfig = null;
	//
	// public static ParamValue paramValue = null;

	protected static Properties loadFile(String CONTEXT_REAL_CONFIG_PATH, String filename)
			throws InvalidPropertiesFormatException, IOException {
		Properties prop = new Properties();
		InputStream is = null;
		is = CacheManager.class.getClassLoader().getResourceAsStream(filename);
		if (is == null) {
			is = (new FileInputStream(CONTEXT_REAL_CONFIG_PATH.concat(filename)));
		}
		if (StringUtils.endsWithIgnoreCase(filename, "xml")) {
			prop.loadFromXML(is);
		} else {
			prop.load(is);
		}
		return prop;
	}

	/**
	 * 一開始就載入
	 * 
	 * @param value
	 * @throws Exception 
	 */
	public static void setCONTEXT_REAL_PATH(String value) {
		synchronized (caches) {
			CONTEXT_REAL_PATH = value;

			if (CONTEXT_REAL_PATH == null) {
				CONTEXT_REAL_PATH = new File("").getAbsolutePath() + File.separator + "WebContent" + File.separator;
			}
			CONTEXT_REAL_CONFIG_PATH = value + "web-inf\\config\\";

			System.out.println(CONTEXT_REAL_CONFIG_PATH);
			File f = new File(CONTEXT_REAL_CONFIG_PATH);

			if (f.exists() == false) {
				logger.error("warn:********************************path is null" + CONTEXT_REAL_CONFIG_PATH);
			}
		}
	}

	/**
	 * 註冊服務
	 * @param cache
	 */
	public static void register(CacheManager cache) {
		caches.put(cache.getClass(), cache);
	}

	public static SNA getSNA() {
		return (SNA) getCache(SNA.class);
	}

	public static EBankingParams getEBankingParams() {
		return (EBankingParams) getCache(EBankingParams.class);
	}

	public static EBankingConfig getEBankingConfig() {
		return (EBankingConfig) getCache(EBankingConfig.class);
	}

	public static GetVbFilePath getGetVbFilePath() {
		return (GetVbFilePath) getCache(GetVbFilePath.class);
	}

	private static CacheManager getCache(Class<? extends CacheManager> cacheClazz) {
		CacheManager cache = caches.get(cacheClazz);
		if (cache != null) {
			return cache;
		}

		synchronized (caches) {
			cache = caches.get(cacheClazz);
			if (cache == null) {
				try {
					cache = cacheClazz.newInstance();
					CacheManager.register(cache);
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
			return cache;
		}
	}
}

package com.kgi.netbank.utils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Hashtable;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;

import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.time.DateFormatUtils;
import com.ibm.tw.commons.util.time.DateUtils;

public class Field {

	/**
	 * 名稱
	 */
	private String name;

	// private String type;

	private Integer length;

	private String padding;

	/**
	 * left,right
	 */
	private String align = "right";

	private String dateFormat;

	/**
	 * 最大值
	 */
	private BigDecimal max;

	/**
	 * 最小值
	 */
	private BigDecimal min;

	public void setMax(BigDecimal max) {
		this.max = max;
	}

	public void setMin(BigDecimal min) {
		this.min = min;
	}

	public void setName(String name) {
		this.name = name;
	}

	// public void setType(String type) {
	// this.type = type;
	// }

	public void setLength(Integer length) {
		this.length = length;
	}

	public void setPadding(String padding) {
		this.padding = padding;
	}

	public void setAlign(String align) {
		this.align = align;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	/**
	 * 處理欄位值
	 * 
	 * @param node
	 * @return
	 * @throws Exception
	 */
	protected String getValue(Hashtable<String, Object> dataMap) throws Exception {
		/** 有entity **/
		String names[] = name.split("\\.");
		Object value = null;
		if (names.length >= 2) {
			value = PropertyUtils.getProperty(dataMap.get(names[0]), names[1]);
			String sValue = getValueString(value);
			return sValue;
		} else {
			value = PropertyUtils.getProperty(dataMap, name);
			String sValue = getValueString(value);
			return sValue;
		}
	}

	/**
	 * @param value
	 * @return
	 * @throws Exception
	 */
	private String getValueString(Object value) throws Exception {
		/** 將日期轉成文字 **/
		if (value instanceof Date) {
			value = getDateValue(dateFormat, (Date) value);
		}

		String sValue = (value == null ? "" : value.toString());

		/** 數字格式 **/
		if (min != null && min.compareTo(ConvertUtils.str2BigDecimal(sValue)) > 0) {
			throw new Exception("數值小於MIN設定:" + name);
		}
		if (max != null && max.compareTo(ConvertUtils.str2BigDecimal(sValue)) < 0) {
			throw new Exception("數值大於MAX設定:" + name);
		}

		/** 檢查長度 **/
		int poorDigits = 0;
		if (length != null) {
			poorDigits = length - sValue.length();
		}
		if (poorDigits > 0) {
			if (StringUtils.isNotEmpty(padding)) {
				/** padding **/
				if (StringUtils.equalsIgnoreCase(align, "left")) {
					sValue = StringUtils.leftPad(sValue, length, padding);
				} else {
					/** 預設向右 **/
					sValue = StringUtils.rightPad(sValue, length, padding);
				}
			}
		} else if (poorDigits < 0) {
			throw new Exception("長度大於LENGTH設定之長度：" + name);
		}
		return sValue;
	}

	/**
	 * 處理 field 為日期型態
	 * 
	 * @param clz
	 * @param value
	 * @param config
	 * @return
	 * @throws Exception
	 */
	private static String getDateValue(String dateFormat, Date value) throws Exception {
		String result = null;
		if (dateFormat == null) {
			/** 預設值 **/
			result = DateUtils.format(DateFormatUtils.SIMPLE_DATETIME_FORMAT, value);
		} else {
			if (StringUtils.equalsIgnoreCase("YYYY-MM-DD hh24:mi:ss", dateFormat)) {
				result = DateUtils.format(DateFormatUtils.SQL_DATETIME_FORMAT, value);
				/** 異常的日期，先by pass **/
				if (StringUtils.equals("1-01-01 00:00:00", result)) {
					result = "";
				}
			} else if (StringUtils.equalsIgnoreCase("yyyy-MM-dd", dateFormat)) {
				result = DateUtils.getISODateStr(value);
			} else if (StringUtils.equalsIgnoreCase("yyyyMMdd", dateFormat)) {
				result = DateUtils.format(DateFormatUtils.SIMPLE_ISO_DATE_FORMAT, value);
			}
		}
		return result;
	}
}

package com.kgi.netbank.utils;

import java.util.Hashtable;
import java.util.Vector;

public class FileParse {

	private String filename;

	private Vector<Field> head = new Vector<Field>();

	public Vector<Field> body = new Vector<Field>();

	public Vector<Field> footer = new Vector<Field>();

	public FileParse(String filename) {
		this.filename = filename;
	}

	public String getFilename() {
		return filename;
	}

	public void addHead(Field field) {
		head.add(field);
	}

	public void addBody(Field field) {
		body.add(field);
	}

	/**
	 * 取得 head 內容
	 * 
	 * @return
	 * @throws Exception
	 */
	public String getHeadContent(Hashtable<String, Object> dataMap) throws Exception {
		return parseRow(head, dataMap, "");
	}

	/**
	 * 取得 body 內容
	 * 
	 * @return
	 * @throws Exception
	 */
	public String getBodyContent(Hashtable<String, Object> dataMap) throws Exception {
		return parseRow(body, dataMap, "&!");
	}

	/**
	* 組欄位資料
	*
	* @param node
	* @return
	* @throws Exception
	*/
	private String parseRow(Vector<Field> field, Hashtable<String, Object> dataMap, String postfix) throws Exception {
		/**全部的資料**/
		StringBuilder sb = new StringBuilder();
		int len = field.size();
		for (int i = 0; i < len; i++) {
			/**item**/
			sb.append(field.get(i).getValue(dataMap).replaceAll("(\\r|\\n|\\r\\n)", "")).append(postfix);
		}

		/**append**/
		if (sb.toString().endsWith(postfix)) {
			return sb.substring(0, sb.length() - postfix.length());
		}
		return sb.toString();
	}

}

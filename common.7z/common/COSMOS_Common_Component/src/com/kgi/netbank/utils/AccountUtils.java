package com.kgi.netbank.utils;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.tw.commons.util.StringUtils;

import cosmos.netbank.util.CodeUtil;

public abstract class AccountUtils {
	protected static Logger logger = LoggerFactory.getLogger(AccountUtils.class);

	public static final String KGIBANK_NO = "809";

	/**
	 * 
	 */
	public static final int DB_HAVE = 1;
	/**
	 * 
	 */
	public static final int DB_NO_ID = 2;
	/**
	 * 
	 */
	public static final int DB_NO_ACCOUNT = 3;
	/**
	 * 
	 */
	public int status = 0;
	/**
	 * 
	 */
	public static final String SAVE_ACCOUNT_CODE_11 = "11";
	/**
	 * 
	 */
	public static final String SAVE_ACCOUNT_CODE_52 = "52";
	/**
	 * 
	 */
	public static final String SAVE_ACCOUNT_CODE_53 = "53";
	/**
	 * 
	 */
	public static final String CHECK_ACCOUNT_CODE = "30";
	/**
	 * 
	 */
	public static final String CHECK_ACCOUNT_CODE31 = "31";
	/**
	 * 
	 */
	public static final String GM_ACCOUNT_CODE = "18";

	public static final String EDB_ACCOUNT_CODE = "88618";

	/**
	 * 
	 */
	public static final String FOREIGN_ACCOUNT_CODE_56 = "56";
	/**
	 * 
	 */
	public static final String FOREIGN_ACCOUNT_CODE_58 = "58";
	/**
	 * 
	 */
	public static final String FOREIGN_T_ACCOUNT_CODE_57 = "57";
	/**
	 * 
	 */
	public static final String FOREIGN_T_ACCOUNT_CODE_59 = "59";

	/**
	 * 有效帳號
	 * 
	 * @param acct
	 * @return
	 */
	public static boolean isValidAccount(String acct) {
		return NumberUtils.isDigits(acct);
	}

	/**
	 * 有效科目別18
	 * 
	 * 必需為有效帳戶,且第3-5碼為18
	 * 
	 * @param acct
	 * @return
	 */
	public static boolean isAcctSubject18(String acct) {
		/** 轉入帳號809時，用0補滿16碼後判斷第1至4碼為0且第8,9碼為18，阻擋交易 **/
		acct = StringUtils.leftPad(acct, 16, '0');
		return isValidAccount(acct) && StringUtils.startsWith(acct, "0000")
				&& StringUtils.equals(StringUtils.substring(acct, 7, 9), "18");
	}

	/**
	 * 是否為809凱基銀行
	 * 
	 * @param bankNo
	 * @return
	 */
	public static boolean isKgibankNo(String bankNo) {
		return KGIBANK_NO.equals(bankNo);
	}

	/**
	 * 電文取出的中文需要轉碼
	 * 
	 * @param str
	 * @return
	 */
	public static String fetchChinese(String str) {
		String newStr = "";
		try {
			newStr = CodeUtil.fetchChinese(str);
		} catch (Exception e) {
			e.printStackTrace();
			newStr = str;
		}
		return StringUtils.trim(newStr);
	}

	/**
	 * 將帳號前的0給過濾掉
	 * 
	 * @param str
	 * @return
	 */
	public static String pureAccount(String str) {
		String account = "";
		if (StringUtils.isNotBlank(str)) {
			for (int i = 0; i < str.length(); i++)
				if (StringUtils.equals(str.substring(i, i + 1), "0") == false) {
					account = str.substring(i, str.length());
					break;
				}
		}
		return account;
	}

	/**
	 * 檢查帳號是否相同
	 * 
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static boolean equals(String str1, String str2) {
		logger.info("str1=" + str1 + ",str2=" + str2);
		return AccountUtils.pureAccount(str1).equals(AccountUtils.pureAccount(str2));
	}

	/**
	 * 取得第一個銀行分行代碼
	 * 
	 * @param accountArr
	 * @return
	 */
	public static String getAnyBranchCode(String[] accountArr) {
		String branch = StringUtils.EMPTY;
		if (accountArr != null) {
			for (String account : accountArr) {
				branch = getBranchCode(account);
				if (StringUtils.isNotBlank(branch)) {
					/** 已經取得其中一個銀行分行代碼了 **/
					break;
				}
			}
		}
		return branch;
	}

	/**
	 * 金融卡啟用
	 * <ul>
	 * <li>16碼表示前補0後補000為卡號,所以要取2,3,4碼</li>
	 * <li>若15碼表示後補000為卡號,取前3碼</li>
	 * <li>若12碼同15碼</li>
	 * <li>其他判斷應該不存在，但以防萬一仍取前3碼</li>
	 * </ul>
	 * 
	 * @param account
	 * @return
	 */
	public static String getBranchCode(String account) {
		account = StringUtils.trim(account);
		if (StringUtils.isBlank(account)) {
			return account;
		}
		String branch = StringUtils.EMPTY;
		if (StringUtils.length(account) == 16) {
			branch = account.substring(1, 4);
		} else {
			branch = account.substring(0, 3);
		}
		return branch;
	}

	/**
	 * 檢查是否為臺幣帳號
	 * 
	 * @param account
	 * @return
	 */
	public static boolean isNTDAccount(String account) {
		if (null == account || account.length() < 6)
			return false;
		if ("52".equals(account.substring(3, 5)) || "53".equals(account.substring(3, 5))
				|| "11".equals(account.substring(3, 5))) {
			return true;
		} else
			return false;
	}

	/**
	 * 檢查是否為外幣帳號
	 * 
	 * @param account
	 * @return
	 */
	public static boolean isForeignAccount(String account) {
		if (null == account || account.length() < 6)
			return false;
		if ("56".equals(account.substring(3, 5)) || "58".equals(account.substring(3, 5))) {
			return true;
		} else
			return false;
	}

	/**
	 *
	 * 將下行電文轉成數字
	 *
	 */
	public static String wrapDownAccount(String str) {
		StringBuffer tempAN = new StringBuffer(500);
		try { // 轉成數字
			str = new String(str.getBytes(), "8859_1");
			for (int i = 0; i < str.length(); i++) {
				if (i > 88) {
					tempAN.append(Character.isSpaceChar(str.charAt(i)) ? "0" : String.valueOf(str.charAt(i)));
				} else {
					tempAN.append(Character.isDigit(str.charAt(i)) ? String.valueOf(str.charAt(i)) : "0");
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		str = tempAN.toString();
		return str;
	}

	/**
	 * 取得簡短的帳號,將前面的0給濾掉
	 * 
	 * @param account
	 * @return
	 */
	public static String getShortAccount(String account) {
		if (StringUtils.isBlank(account)) {
			return account;
		}
		account = StringUtils.trim(account);
		int len = StringUtils.length(account);
		if (len <= 12) {
			return account;
		}

		int startIndex = 0;
		int endIndex = len - 12;
		for (; startIndex < endIndex; startIndex++) {
			if (account.charAt(startIndex) == '0') {
				continue;
			}
			break;
		}
		return account.substring(startIndex);
	}

	/**
	 * 查詢台幣活存帳戶號碼
	 */
	public synchronized static String[] SaveBalanceID(String accountNumber) {
		Set<String> vector = null;
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];

		vector = SaveBalanceID2(accountNumber);

		int count = vector.size();
		String result[] = new String[count];
		vector.toArray(result);
		return result;
	}

	/**
	 * 查詢台幣活存帳戶號碼
	 */
	public synchronized static Set<String> SaveBalanceID2(String accountNumber) {
		Set<String> vector = new HashSet<String>();
		// if(accountNumber==null) return new String[0];
		// if(accountNumber.trim().length()<30) return new String[0];
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String testAccount = accountNumber.substring(i * 12 + 87, i * 12 + 89);
			if (testAccount.equals(SAVE_ACCOUNT_CODE_11) || testAccount.equals(SAVE_ACCOUNT_CODE_52)
					|| testAccount.equals(SAVE_ACCOUNT_CODE_53)) {
				String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
				if (!tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
					vector.add(tempaccount);
				}
				// vector.addElement(accountNumber.substring(i * 12 + 84, i * 12
				// + 96));
			}
		}

		return vector;
	}

	/**
	 * 查詢台幣支存帳戶號碼
	 */
	public synchronized static String[] CheckBalanceID(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String testAccount = accountNumber.substring(i * 12 + 87, i * 12 + 89);
			if (testAccount.equals(CHECK_ACCOUNT_CODE) || testAccount.equals(CHECK_ACCOUNT_CODE31)) {
				String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
				if (!tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
					vector.addElement(tempaccount);
				}
				// vector.addElement(accountNumber.substring(i * 12 + 84, i * 12
				// + 96));
			}
		}
		int count = vector.size();
		String result[] = new String[count];
		vector.toArray(result);
		return result;
	}

	/**
	 * 查詢數位帳戶號碼
	 * 
	 * @param accountNumber
	 * @return
	 */
	public synchronized static String[] DigitalBalanceID(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];

		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String tempaccount = accountNumber.substring(84 + 18 * i, 84 + 18 * (i + 1));
			if (StringUtils.isNotBlank(tempaccount) && tempaccount.length() >= 15) {
				String status1 = tempaccount.substring(12, 13);
				String status2 = tempaccount.substring(13, 14);
				String acctNo = tempaccount.substring(0, 12);
				// 數位帳號 => 狀態1:0+1 ; 狀態2:非0
				if (("0".equals(status1) || "1".equals(status1)) && (!"0".equals(status2))) {
					vector.addElement(acctNo);
				}
			}
		}

		int count = vector.size();
		String result[] = new String[count];
		vector.toArray(result);
		return result;
	}

	/**
	 * 查詢數位帳戶號碼
	 * 
	 * @param accountNumber
	 * @return
	 */
	public synchronized static String[] getGreenAccount(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];

		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String tempaccount = accountNumber.substring(84 + 18 * i, 84 + 18 * (i + 1));
			if (StringUtils.isNotBlank(tempaccount) && tempaccount.length() >= 15) {
				// String status1 = tempaccount.substring(12, 13);
				// String status2 = tempaccount.substring(13, 14);
				// String status3 = tempaccount.substring(14, 15);
				String status4 = tempaccount.substring(15, 16);
				String status1234 = tempaccount.substring(12, 16);
				String acctNo = tempaccount.substring(0, 12);
				// 1357 為green account
				if (("1".equals(status4)) || ("3".equals(status4)) || ("5".equals(status4)) || ("7".equals(status4))) {
					vector.addElement(acctNo);
				}
			}
		}

		int count = vector.size();
		String result[] = new String[count];
		vector.toArray(result);
		return result;
	}

	/**
	 * 從 OA02 抓取帳號
	 * 
	 * @param accountStr
	 * @return
	 */
	public static List<String> getAccountFromOA02(String accountStr) {
		List<String> acountList = new ArrayList<String>();
		for (int i = 0; i < 150; i++) {
			String account = accountStr.substring(84 + 12 * i, 84 + 12 * (i + 1));
			if (!"000000000000".equals(account)) {
				acountList.add(account);
			}
		}
		return acountList;
	}

	/**
	 * 查詢放款帳戶號碼 科目存放的是日期，要以日期做判斷
	 */
	public synchronized static String[] LoanBalanceID(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		// accountNumber += "0";
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String testAccount = accountNumber.substring(i * 12 + 87, i * 12 + 89);
			String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
			if (tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
																		// 20060111
				tempaccount = tempaccount.substring(0, 11).concat("0");
				vector.addElement(tempaccount);
			}
			/*
			 * if (testAccount.equals("81") || testAccount.equals("82") ||
			 * testAccount.equals("83") || testAccount.equals("84") ||
			 * testAccount.equals("85") || testAccount.equals("86") ||
			 * testAccount.equals("87") || testAccount.equals("88") ||
			 * testAccount.equals("89") || testAccount.equals("90") ||
			 * testAccount.equals("91") || testAccount.equals("92") ||
			 * testAccount.equals("93") || testAccount.equals("94") ||
			 * testAccount.equals("95") || testAccount.equals("96") ||
			 * testAccount.equals("97") || testAccount.equals("98")) { String
			 * account=accountNumber.substring(i * 12 + 84, i * 12 + 96);
			 * if(account.charAt(11)=='0') //放款只有11位 vector.addElement(account);
			 * 
			 * }
			 */
		}
		int count = vector.size();
		String result[] = new String[count];
		for (int i = 0; i < count; i++)
			result[i] = vector.elementAt(i).toString();
		return result;
	}

	/**
	 * 查詢匯款入帳明細傳真帳戶號碼
	 * 
	 * @param accountNumber
	 * @return
	 */

	public synchronized static String[] getRemitID(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String testAccount = accountNumber.substring(i * 12 + 87, i * 12 + 89);
			// || testAccount.equals("18") 嘉惠說不要18科目
			if (testAccount.equals("11") || testAccount.equals("52") || testAccount.equals("53")
					|| testAccount.equals("30") || testAccount.equals("31") || testAccount.equals("32")
					|| testAccount.equals("33")) {
				String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
				if (!tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
					vector.addElement(tempaccount);
				}
				// vector.addElement(accountNumber.substring(i * 12 + 84, i * 12
				// + 96));
			}
		}
		int count = vector.size();
		String result[] = new String[count];
		for (int i = 0; i < count; i++)
			result[i] = vector.elementAt(i).toString();
		return result;
	}

	/**
	 * 查詢ID的所有的帳戶號碼
	 * 
	 * @param accountNumber
	 * @return
	 */

	public synchronized static String[] getAllID(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		accountNumber += "000000";
		for (int i = 0; i < accountLength; i++) {
			String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
			if (!tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
				vector.addElement(tempaccount);
			} else {
				tempaccount = tempaccount.substring(0, 11);
				vector.addElement(tempaccount);
			}

			// vector.addElement(accountNumber.substring(i * 12 + 84, i * 12 +
			// 96));
		}
		int count = vector.size();
		String result[] = new String[count];
		for (int i = 0; i < count; i++)
			result[i] = vector.elementAt(i).toString();
		return result;
	}

	/**
	 * 查詢GM帳戶號碼
	 */

	public synchronized static String[] GM_ID(String accountNumber) {
		// logger.info("accountNumber:"+accountNumber);
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		Hashtable<String, String> ht = new Hashtable<String, String>();
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			// 5碼
			String acctnumPart_ = accountNumber.substring(i * 12 + 87 - 3, i * 12 + 89);
			boolean isExclude = false;
			if (acctnumPart_.equals(EDB_ACCOUNT_CODE)) {
				isExclude = true;
			}
			// 排除非現金卡
			if (!isExclude) {
				if (accountNumber.substring(i * 12 + 87, i * 12 + 89).equals(GM_ACCOUNT_CODE)) {

					String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
					if (!tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
						ht.put(tempaccount, "");
					}

				}
			} else {

			}

		}
		int count = ht.size();
		String result[] = new String[count];
		ht.keySet().toArray(result);
		return result;
	}

	/**
	 * 查詢額度型貸款帳戶
	 * 
	 * @param accountNumber
	 * @return
	 */
	public synchronized static String[] getEDebitID(String accountNumber) {

		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		Hashtable<String, String> ht = new Hashtable<String, String>();
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String acctnum_ = accountNumber.substring(i * 12 + 87 - 3, i * 12 + 89);
			if (acctnum_.equals(EDB_ACCOUNT_CODE)) {
				String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
				if (!tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
					ht.put(tempaccount, "");
				}

			}
		}
		int count = ht.size();
		String result[] = new String[count];
		ht.keySet().toArray(result);
		return result;
	}

	/**
	 * 查詢外幣帳戶號碼 外幣活期帳號
	 */

	public synchronized static String[] ForeignSaveID(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		String strAccount = "";
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		for (int i = 0; i < Integer.parseInt(accountNumber.substring(27, 30), 10); i++) {
			if (accountNumber.substring(i * 12 + 87, i * 12 + 89).equals(FOREIGN_ACCOUNT_CODE_56)
					|| accountNumber.substring(i * 12 + 87, i * 12 + 89).equals(FOREIGN_ACCOUNT_CODE_58)) {
				String tempAccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
				if (strAccount.indexOf(tempAccount) < 0) {
					strAccount = strAccount.concat(tempAccount); // 可能重覆
					if (!tempAccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
						vector.addElement(tempAccount);
					}
					// vector.addElement(tempAccount);
				}
			}
		}
		strAccount = null;

		int count = vector.size();
		String result[] = new String[count];
		for (int i = 0; i < count; i++)
			result[i] = vector.elementAt(i).toString();
		return result;

	}

	/**
	 * 查詢外幣定存帳戶號碼
	 */
	public synchronized static String[] ForeignTimeID(String accountNumber) {
		Vector<String> vector = new Vector<String>();
		if (accountNumber == null)
			return new String[0];
		if (accountNumber.trim().length() < 30)
			return new String[0];
		int accountLength = Integer.parseInt(accountNumber.substring(27, 30), 10);
		for (int i = 0; i < accountLength; i++) {
			String testAccount = accountNumber.substring(i * 12 + 87, i * 12 + 89);
			if (testAccount.equals(FOREIGN_T_ACCOUNT_CODE_57) || testAccount.equals(FOREIGN_T_ACCOUNT_CODE_59)) {
				String tempaccount = accountNumber.substring(i * 12 + 84, i * 12 + 96);
				if (!tempaccount.substring(11, 12).equalsIgnoreCase("Y")) { // Y是放款帳號
					vector.addElement(tempaccount);
				}
				// vector.addElement(accountNumber.substring(i * 12 + 84, i * 12
				// + 96));
			}
		}
		int count = vector.size();
		String result[] = new String[count];
		vector.toArray(result);
		return result;
	}

	/**
	 * 檢查帳號是否相同
	 * 
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static boolean equalsAccount(String str1, String str2) {
		return AccountUtils.pureAccount(str1).equals(AccountUtils.pureAccount(str2));
	}

	public static void main(String[] args) {
		String acct = StringUtils.leftPad("0000553182997987", 16, '0');
		System.out.println(
				"--------------------" + StringUtils.startsWith(acct, "0000") + "-----------------------------");
		System.out.println("--------------------" + StringUtils.substring(acct, 7, 9));
	}
}

package com.kgi.netbank.utils;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Hashtable;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.ibm.tw.commons.util.BeanUtilsEx;

public class XmlConfig {

	private static final String BODY = "BODY";

	private static final String HEAD = "HEAD";

	private static final Hashtable<String, FileParse> fieldsMap = new Hashtable<String, FileParse>();
	static {
		/** 同一裝置 **/
		loadXml("INBK_EXCHANGE_LOG", "/INBK_EXCHANGE_LOG.xml");
		/** 外幣 **/
		loadXml("INBK_APPOINTMENT_EXCHANGE", "/INBK_APPOINTMENT_EXCHANGE.xml");
		loadXml("INBK_APPOINTMENT_ATTRIBUTE", "/INBK_APPOINTMENT_ATTRIBUTE.xml");
		/** 臺幣 **/
		loadXml("INBK_V_TWFLOWDOC_OTPTRANSFER", "/INBK_V_TWFLOWDOC_OTPTRANSFER.xml");
		loadXml("INBK_V_TWFLOWDOC_PACTTRANSFER", "/INBK_V_TWFLOWDOC_PACTTRANSFER.xml");
		loadXml("INBK_V_TWFLOWDOC_PRECREDITCARD", "/INBK_V_TWFLOWDOC_PRECREDITCARD.xml");
		loadXml("INBK_V_TWFLOWDOC_TRANSFERDMD", "/INBK_V_TWFLOWDOC_TRANSFERDMD.xml");
		//
		loadXml("INBK_ACCESSLOG", "/INBK_ACCESSLOG.xml");
		loadXml("INBK_NETBANKAPPLYDATATYPE", "/INBK_NETBANKAPPLYDATATYPE.xml");
		loadXml("INBK_NETBANKAPPLYSUBDATATYPE", "/INBK_NETBANKAPPLYSUBDATATYPE.xml");
		loadXml("INBK_NETBANKBILLAPPLY", "/INBK_NETBANKBILLAPPLY.xml");
		loadXml("INBK_NETBANKDATAAPPLY", "/INBK_NETBANKDATAAPPLY.xml");
		loadXml("INBK_NETBANKMILIAGEAPPLY", "/INBK_NETBANKMILIAGEAPPLY.xml");
		loadXml("INBK_NETBANK_LOGON", "/INBK_NETBANK_LOGON.xml");
		loadXml("INBK_NETWORK_SEGMENT", "/INBK_NETWORK_SEGMENT.xml");
		loadXml("INBK_EFUND_LOG", "/INBK_EFUND_LOG.xml");
		loadXml("INBK_TRUST_OPEN_ACCOUNT", "/INBK_TRUST_OPEN_ACCOUNT.xml");
		loadXml("INBK_RPL_ACTIVITY_LOG", "/INBK_RPL_ACTIVITY_LOG.xml");
		loadXml("INBK_ACH_ACTIVITY_LOG", "/INBK_ACH_ACTIVITY_LOG.xml");
		loadXml("INBK_PRE_LOAN_PWD_LOG", "/INBK_PRE_LOAN_PWD_LOG.xml");
	}

	/**
	 * 載入 xml 設定
	 * 
	 * @param xmlPath
	 * @return
	 */
	private static void loadXml(String pid, String xmlPath) {
		InputStream fis = null;
		Document document = null;
		try {
			fis = XmlConfig.class.getResourceAsStream(xmlPath);

			// File f = new File(xmlPath);
			// fis = new FileInputStream(f);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			InputSource is = new InputSource(fis);
			document = builder.parse(is);
			// fis.close();
			// xmls.put(name, document);
			if (document == null) {
				throw new Exception("未載入 XML 設定");
			}

			FileParse fields = new FileParse(pid);

			/** 全部的資料 **/
			parseHead(fields, findNode(document.getFirstChild().getChildNodes(), HEAD));
			parseBody(fields, findNode(document.getFirstChild().getChildNodes(), BODY));
			fieldsMap.put(pid, fields);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static void parseHead(FileParse fields, Node node)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		/** 全部的資料 **/
		NodeList childNodes = node.getChildNodes();
		int len = childNodes.getLength();
		for (int i = 0; i < len; i++) {
			/** item **/
			Node childNode = childNodes.item(i);
			if (childNode.hasAttributes()) {
				Field field = getAttributes(childNode);
				fields.addHead(field);
			}
		}
	}

	private static void parseBody(FileParse fields, Node node)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		/** 全部的資料 **/
		NodeList childNodes = node.getChildNodes();
		int len = childNodes.getLength();
		for (int i = 0; i < len; i++) {
			/** item **/
			Node childNode = childNodes.item(i);
			if (childNode.hasAttributes()) {
				Field field = getAttributes(childNode);
				fields.addBody(field);
			}
		}
	}

	/**
	 * 取得欄位條件設定
	 * 
	 * @param node
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	private static Field getAttributes(Node node)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (node.hasAttributes()) {
			NamedNodeMap nnm = node.getAttributes();
			Field field = new Field();
			for (int i = 0; i < nnm.getLength(); i++) {
				String key = nnm.item(i).getNodeName();
				String value = nnm.item(i).getNodeValue();
				BeanUtilsEx.setProperty(field, key, value);
			}
			return field;
		}
		return null;
	}

	/**
	 * 查找標籤
	 * 
	 * @param nodeList
	 * @param name
	 * @return
	 */
	private static Node findNode(NodeList nodeList, String name) {
		for (int i = 0; i < nodeList.getLength(); i++) {
			if (name.toUpperCase().equals(nodeList.item(i).getNodeName().toUpperCase()))
				return nodeList.item(i);
		}
		return null;
	}

	public static FileParse getFileParse(String pid) {
		return fieldsMap.get(pid);
	}
}

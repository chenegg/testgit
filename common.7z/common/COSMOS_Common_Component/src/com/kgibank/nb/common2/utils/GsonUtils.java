package com.kgibank.nb.common2.utils;

import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

public class GsonUtils {
	protected static Logger logger = LoggerFactory.getLogger(GsonUtils.class);

	private static final ExtDateTypeAdapter extDateTypeAdapter = new ExtDateTypeAdapter();

	private GsonUtils() {

	}

	/**
	 * 將物件轉換成json格式
	 *
	 * @param <T>
	 * @param result
	 * @return
	 */
	public static <T> String toJson(T result) {
		try {
			Gson gson = new Gson();
			return gson.toJson(result);
		} catch (JsonSyntaxException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 將json格式轉成物件
	 *
	 * @param <T>
	 * @param jsonStr
	 * @param clazz
	 * @return
	 */
	public static <T> T fromJson(String jsonStr, Class<T> clazz) {
		Gson gson = new GsonBuilder().registerTypeAdapter(Date.class, extDateTypeAdapter).create();
		try {
			return gson.fromJson(jsonStr, clazz);
		} catch (JsonSyntaxException e) {
			logger.error(e.getMessage(), e);
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * 將json格式轉成陣列格式
	 *
	 * @param jsonStr
	 * @param type
	 * @return
	 */
	public static List<String> fromJsonType(String jsonStr, Type type) {
		Gson gson = new Gson();
		try {
			return gson.fromJson(jsonStr, type);
		} catch (JsonSyntaxException e) {
			logger.error(e.getMessage(), e);
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * 將json格式轉成陣列格式
	 *
	 * @param jsonStr
	 * @param type
	 * @return
	 */
	public static Map<String, String> fromJsonType(String jsonStr) {
		Gson gson = new Gson();
		try {
			Type type = new TypeToken<Map<String, String>>() {
			}.getType();
			return gson.fromJson(jsonStr, type);
		} catch (JsonSyntaxException e) {
			logger.error(e.getMessage(), e);
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * 將json格式轉成物件
	 *
	 * @param <T>
	 * @param jsonStr
	 * @param clazz
	 * @return
	 */
	public static <T> T fromJson(Gson gson, String jsonStr, Class<T> clazz) {

		try {
			return gson.fromJson(jsonStr, clazz);
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
//			logger.error(e.getMessage(), e);
			return null;
		} catch (Exception e) {
			e.printStackTrace();
//			logger.error(e.getMessage(), e);
			return null;
		}
	}
}

package com.kgibank.nb.common2.type.enums;

import com.ibm.tw.commons.util.EnumBase;
import com.ibm.tw.commons.util.EnumUtils;
import com.ibm.tw.commons.util.StringUtils;

public enum IdTypeEnum implements EnumBase {

	/** 個人 **/
	_11("11", "本國自然人"),

	_12("12", "外國自然人(舊編號)"),

	_13("13", "統一證號(大陸/港澳居民)"),

	_14("14", "統一證號(外國人)"),

	//
	/** 公司戶 **/
	_21("21", "統一編號"),

	/** OBU **/

	_15("15", "OBU自然人"),

	_16("16", "籌備處"),

	_17("17", "OBU聯名戶???"),

	_18("18", "OBU聯名戶"),

	_22("22", "OBU法人-聯徵虛擬統編"),

	_23("23", "OBU法人-自行編碼11碼"),

	UNKNOWN(UNKNOWN_STR, "");

	private String code;

	// private String desc;

	private IdTypeEnum(String code, String desc) {
		this.code = code;
		// this.desc = desc;
	}

	public static IdTypeEnum toValueOf(String code) {
		if (StringUtils.isNotBlank(code)) {
			for (IdTypeEnum next : EnumUtils.asList(IdTypeEnum.class)) {
				if (StringUtils.equals(next.code, code)) {
					return next;
				}
			}
		}
		return UNKNOWN;
	}

	public boolean isPersonal() {
		return (this == _11 || this == _12 || this == _13 || this == _14);
	}

	/** 外國人 **/
	public boolean isFrPersonal() {
		return (this == _12 || this == _13 || this == _14);
	}

	public boolean isCompany() {
		return (this == _21);
	}

	public boolean isDbu() {
		return isPersonal() || isCompany();
	}

	public boolean isObu() {
		return (this == _15 || this == _18 || this == _22 || this == _23);
	}

	public String getCode() {
		return code;
	}
}

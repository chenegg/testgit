package com.kgibank.nb.common2.utils;

public class DataVerifier {

	public DataVerifier() {
	}

	public static int str2Int(String s) throws NumberFormatException {
		if (s == null)
			throw new NumberFormatException();
		String s1 = s.trim();
		if (s1.charAt(0) == '+')
			s1 = s1.substring(1);
		return Integer.parseInt(s1);
	}

	public static boolean isNumber(String s) {
		try {
			Double.parseDouble(s);
			boolean flag = true;
			return flag;
		} catch (NumberFormatException numberformatexception) {
			boolean flag1 = false;
			return flag1;
		}
	}

	public static boolean isPosInt(String s) {
		if (s == null)
			return false;
		boolean flag2;
		try {
			int i = str2Int(s);
			if (i > 0) {
				boolean flag = true;
				return flag;
			} else {
				boolean flag1 = false;
				return flag1;
			}
		} catch (NumberFormatException numberformatexception) {
			flag2 = false;
		}
		return flag2;
	}

	public static boolean isPosNumber(String s) {
		try {
			if (Double.parseDouble(s) > (double) 0) {
				boolean flag = true;
				return flag;
			} else {
				boolean flag1 = false;
				return flag1;
			}
		} catch (NumberFormatException numberformatexception) {
			boolean flag2 = false;
			return flag2;
		}
	}

	public static boolean isValidCardNo(String s) {
		if (s == null)
			return false;
		String s1 = s;
		Object obj = null;
		int i = 0;
		int j = 1;
		boolean flag = false;
		int l = s1.length();
		if (l > 19)
			return false;
		try {
			for (int i1 = 0; i1 < l; i1++) {
				String s2 = s1.substring(l - i1 - 1, l - i1);
				int k = Integer.parseInt(s2) * j;
				if (k >= 10)
					i += k % 10 + 1;
				else
					i += k;
				if (j == 1)
					j++;
				else
					j--;
			}

			if (i % 10 == 0) {
				boolean flag1 = true;
				return flag1;
			} else {
				boolean flag2 = false;
				return flag2;
			}
		} catch (NumberFormatException numberformatexception) {
			boolean flag3 = false;
			return flag3;
		}
	}

	public static boolean isVisa(String s) {
		if (s == null)
			return false;
		String s1 = s.trim();
		int i = s1.length();
		try {
			if ((i == 16 || i == 13) && s1.charAt(0) == '4') {
				boolean flag = isValidCardNo(s1);
				return flag;
			} else {
				boolean flag1 = false;
				return flag1;
			}
		} catch (IndexOutOfBoundsException indexoutofboundsexception) {
			boolean flag2 = false;
			return flag2;
		}
	}

	public static boolean isMaster(String s) {
		if (s == null)
			return false;
		String s1 = s.trim();
		boolean flag;
		try {
			char c = s1.charAt(0);
			char c1 = s1.charAt(1);
			if (s1.length() == 16 && c == '5' && c1 >= '1' && c1 <= '5') {
				boolean flag1 = isValidCardNo(s1);
				return flag1;
			} else {
				boolean flag2 = false;
				return flag2;
			}
		} catch (IndexOutOfBoundsException indexoutofboundsexception) {
			flag = false;
		}
		return flag;
	}

	public static boolean isAmericanExpress(String s) {
		if (s == null)
			return false;
		String s1 = s.trim();
		boolean flag;
		try {
			char c = s1.charAt(0);
			char c1 = s1.charAt(1);
			if (s1.length() == 15 && c == '3' && (c1 == '4' || c1 == '7')) {
				boolean flag1 = isValidCardNo(s1);
				return flag1;
			} else {
				boolean flag2 = true;
				return flag2;
			}
		} catch (IndexOutOfBoundsException indexoutofboundsexception) {
			flag = false;
		}
		return flag;
	}

	public static boolean isDinersClub(String s) {
		if (s == null)
			return false;
		String s1 = s.trim();
		boolean flag;
		try {
			char c = s1.charAt(0);
			char c1 = s1.charAt(1);
			if (s1.length() == 14 && c == '3' && (c1 == '0' || c1 == '6' || c1 == '7')) {
				boolean flag1 = isValidCardNo(s1);
				return flag1;
			} else {
				boolean flag2 = false;
				return flag2;
			}
		} catch (IndexOutOfBoundsException indexoutofboundsexception) {
			flag = false;
		}
		return flag;
	}

	public static boolean isJCB(String s) {
		if (s == null)
			return false;
		String s1 = s.trim();
		boolean flag2;
		try {
			String s2 = s1.substring(0, 4);
			if (s1.length() == 16 && (s2.equals("3088") || s2.equals("3096") || s2.equals("3112") || s2.equals("3158")
					|| s2.equals("3337") || s2.equals("3528"))) {
				boolean flag = isValidCardNo(s1);
				return flag;
			} else {
				boolean flag1 = false;
				return flag1;
			}
		} catch (IndexOutOfBoundsException indexoutofboundsexception) {
			flag2 = false;
		}
		return flag2;
	}

	public static boolean isCreditCard(String s) {
		if (s == null)
			return false;
		if (!isValidCardNo(s))
			return false;
		return isVisa(s) || isMaster(s) || isAmericanExpress(s) || isDinersClub(s) || isJCB(s);
	}

	public static boolean isVisaMaster(String s) {
		if (s == null)
			return false;
		if (!isValidCardNo(s))
			return false;
		return isVisa(s) || isMaster(s);
	}

	public static boolean isID(String s) {
		if (s == null)
			return false;
		String s1 = s.trim();
		int i = s1.length();
		if (i == 10)
			return isPersonalID(s1);
		if (i == 8)
			return isCompanyID(s1);
		else
			return false;
	}

	public static boolean isPersonalID(String s) {
		if (s == null)
			return false;
		String s1 = s;
		int i = 0;
		byte byte0 = 0;
		int ai[] = new int[3];
		int ai1[] = new int[10];
		if (s1.length() != 10)
			return false;
		switch (s1.charAt(0)) {
		case 65: // 'A'
			byte0 = 10;
			break;

		case 66: // 'B'
			byte0 = 11;
			break;

		case 67: // 'C'
			byte0 = 12;
			break;

		case 68: // 'D'
			byte0 = 13;
			break;

		case 69: // 'E'
			byte0 = 14;
			break;

		case 70: // 'F'
			byte0 = 15;
			break;

		case 71: // 'G'
			byte0 = 16;
			break;

		case 72: // 'H'
			byte0 = 17;
			break;

		case 74: // 'J'
			byte0 = 18;
			break;

		case 75: // 'K'
			byte0 = 19;
			break;

		case 76: // 'L'
			byte0 = 20;
			break;

		case 77: // 'M'
			byte0 = 21;
			break;

		case 78: // 'N'
			byte0 = 22;
			break;

		case 80: // 'P'
			byte0 = 23;
			break;

		case 81: // 'Q'
			byte0 = 24;
			break;

		case 82: // 'R'
			byte0 = 25;
			break;

		case 83: // 'S'
			byte0 = 26;
			break;

		case 84: // 'T'
			byte0 = 27;
			break;

		case 85: // 'U'
			byte0 = 28;
			break;

		case 86: // 'V'
			byte0 = 29;
			break;

		case 88: // 'X'
			byte0 = 30;
			break;

		case 89: // 'Y'
			byte0 = 31;
			break;

		case 87: // 'W'
			byte0 = 32;
			break;

		case 90: // 'Z'
			byte0 = 33;
			break;

		case 73: // 'I'
			byte0 = 34;
			break;

		case 79: // 'O'
			byte0 = 35;
			break;

		default:
			return false;
		}
		ai[1] = byte0 / 10;
		ai[2] = byte0 % 10;
		for (int j = 1; j <= 9; j++)
			ai1[j] = Character.digit(s1.charAt(j), 10);

		i = ai[1] + 9 * ai[2] + 8 * ai1[1] + 7 * ai1[2] + 6 * ai1[3] + 5 * ai1[4] + 4 * ai1[5] + 3 * ai1[6] + 2 * ai1[7]
				+ ai1[8] + ai1[9];
		return i % 10 == 0;
	}

	public static boolean isCompanyID(String s) {
		if (s == null)
			return false;
		String s1 = s;
		int ai[] = new int[10];
		int ai1[] = new int[10];
		int ai2[] = new int[10];
		int ai3[] = new int[10];
		int i = 0;
		if (s1.length() != 8)
			return false;
		for (int k = 1; k <= 8; k++)
			ai3[k] = Character.digit(s1.charAt(k - 1), 10);

		ai2[1] = ai3[1] * 1;
		ai2[2] = ai3[3] * 1;
		ai2[3] = ai3[5] * 1;
		ai2[4] = ai3[8] * 1;
		ai[1] = (ai3[2] * 2) / 10;
		ai1[1] = (ai3[2] * 2) % 10;
		ai[2] = (ai3[4] * 2) / 10;
		ai1[2] = (ai3[4] * 2) % 10;
		ai[3] = (ai3[6] * 2) / 10;
		ai1[3] = (ai3[6] * 2) % 10;
		ai[4] = (ai3[7] * 4) / 10;
		ai1[4] = (ai3[7] * 4) % 10;
		i = ai[1] + ai1[1] + ai2[1] + ai[2] + ai1[2] + ai2[2] + ai[3] + ai1[3] + ai2[3] + ai[4] + ai1[4] + ai2[4];
		if (i % 10 == 0)
			return true;
		if (ai3[7] == 7) {
			ai[5] = (ai[4] + ai1[4]) / 10;
			int j = ai[1] + ai1[1] + ai2[1] + ai[2] + ai1[2] + ai2[2] + ai[3] + ai1[3] + ai2[3] + ai[5] + ai2[4];
			if (j % 10 == 0)
				return true;
		}
		return false;
	}

	public static boolean isEmail(String s) {
		if (s == null)
			return false;
		String s1 = s.trim();
		int i = s1.length();
		if (i < 5)
			return false;
		int j = s1.indexOf('@', 1);
		int k = s1.lastIndexOf('.', i - 2);
		if (j == -1 || k == -1)
			return false;
		return k > j + 1;
	}

}
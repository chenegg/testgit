package com.kgibank.nb.common2.type.enums;

import java.util.EnumSet;

import com.ibm.tw.commons.util.EnumBase;
import com.ibm.tw.commons.util.StringUtils;

public enum SystemEnum implements EnumBase {
	DEP("DEP", "存款帳號"),

	LON("LON", "放款帳號"),

	VTA("VTA", "虛擬帳號"),

	GMC("GMC", "速還金(額度型貸款)/靈活卡帳號"),

	OTHER_BANK("", "他行帳號"),

	UNKNOWN(UNKNOWN_STR, "");

	private String code;
	private String desc;

	private SystemEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static SystemEnum toValueOf(String code) {
		if (code != null) {
			for (SystemEnum next : EnumSet.allOf(SystemEnum.class)) {
				if (StringUtils.equals(next.code, code)) {
					return next;
				}
			}
		}
		return UNKNOWN;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	public boolean isDEP() {
		return DEP == this;
	}

	public boolean isLON() {
		return LON == this;
	}

	public boolean isVTA() {
		return VTA == this;
	}

	public boolean isGMC() {
		return GMC == this;
	}

	public boolean isOTHER() {
		return OTHER_BANK == this;
	}
}

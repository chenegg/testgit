package com.kgibank.nb.common2.type;

import org.apache.commons.lang3.StringUtils;

import com.ibm.tw.commons.util.ConvertUtils;

public class AcctUtils {

	// private static final byte[] SAVE_B_ARRAY = { 7, 1, 3, 7, 1, 3, 7, 1, 3,
	// 7, 1, 3, 7 };

	/**
	 * 
	 */
	public static final String GM_ACCOUNT_CODE = "18";

	public static final String EDB_ACCOUNT_CODE = "88618";

	public static final String KGI_BANK_ID = "809";

	private AcctUtils() {

	}

	/**
	 * 是否為現金卡帳號
	 */
	public static boolean isCachCardAcct(String acct) {
		return StringUtils.leftPad(acct, 16, '0').substring(7, 9).equals("18");
	}

	public static boolean equals(String s1, String s2) {
		s1 = StringUtils.leftPad(s1, 16, '0');
		s2 = StringUtils.leftPad(s2, 16, '0');
		return StringUtils.equals(s1, s2);
	}

	public static void main(String[] args) {
		// System.out.println(isValidSelfSaveAcct("60038812345677")); // true
		String s = "49180603100";
		System.out.println(isCachCardAcct(s));// false
		// System.out.println(isValidSelfSaveAcct("67115523456780"));// false

	}

	public static boolean isEdbCachCard(String s) {
		if (StringUtils.isBlank(s)) {
			return false;
		}
		// 大於12位數的帳號，去掉開頭的0後為88618起始的是e貸寶
		// 小於等於12位數的，直接看開頭
		if (s.length() > 12) {
			s = s.substring(0, 12);
		}
		if (s.startsWith(EDB_ACCOUNT_CODE)) {
			return true;
		}
		return false;
	}

	public static boolean isGmCachCard(String s) {
		if (StringUtils.isBlank(s)) {
			return false;
		}
		if (s.length() > 12) {
			s = s.substring(0, 12);
		}
		// 如果是現金卡但不是e貸寶時回傳true
		if (isCachCardAcct(s) && !isEdbCachCard(s)) {
			return true;
		}
		return false;
	}

	/**
	 * 舊核心原14碼,但新核心時轉成16碼,造成客戶不變,故使用此將帳號轉成14碼
	 * 
	 * @param acct
	 * @return
	 */
	public static String getAccount14(String acct) {
		if (StringUtils.isBlank(acct)) {
			return acct;
		}
		String displayAccount = StringUtils.leftPad(ConvertUtils.str2BigDecimal(acct).toString(), 14, '0');
		return displayAccount;
	}

	/**
	 * 舊核心原14碼,但新核心時轉成16碼,造成客戶不變,故使用此將帳號轉成14碼
	 * 
	 * @param acct
	 * @return
	 */
	public static String getAccount(String bankid, String acct) {
		if (StringUtils.equals(bankid, KGI_BANK_ID)) {
			return getAccount14(acct);
		}
		return acct;
	}

	/**
	 * 第二版,新增手機10碼/凱基14碼/其他16碼
	 * 
	 * @param bankid
	 * @param acct
	 * @return
	 */
	public static String getDisplayAccount(String bankid, String acct) {
		if (StringUtils.isBlank(acct)) {
			return acct;
		}
		String temp_acct = ConvertUtils.str2BigDecimal(acct).toString();
		if (StringUtils.length(acct) == 9 && acct.startsWith("9")) {
			return StringUtils.leftPad(temp_acct, 10, '0');
		}
		return getAccount(bankid, acct);
	}

	public static String getCashcardNum2Acct(String cashcardNum) {
		String value = "";
		try {
			value = StringUtils.trim(cashcardNum);
			if (StringUtils.length(value) > 12) {
				value = StringUtils.substring(value, 0, 12);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return StringUtils.trimToEmpty(value);
	}

	public static String getAccountLast5(String acct) {
		return StringUtils.length(acct) > 5 ? StringUtils.substring(acct, StringUtils.length(acct) - 5) : acct;
	}
}

package com.kgibank.nb.common2.type;

import java.util.EnumSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;

import com.ibm.tw.commons.util.CollectionUtils;
import com.ibm.tw.commons.util.EnumBase;
import com.ibm.tw.commons.util.StringUtils;

public enum CurrencyEnum implements EnumBase {
	USD("USD", "美元", "01", true)/**/,

	HKD("HKD", "港幣", "02", true)/**/,

	GBP("GBP", "英鎊", "04", true)/**/,

	AUD("AUD", "澳幣", "06", true)/**/,

	SGD("SGD", "新幣", "11", true)/**/,

	CHF("CHF", "瑞郎", "08", true)/**/,

	JPY("JPY", "日圓", "14", true)/**/,

	CAD("CAD", "加幣", "03", true)/**/,

	SEK("SEK", "瑞典幣", "89", true)/**/,

	// MYR("MYR", "馬來幣",true)/* 應該沒有 */,

	NZD("NZD", "紐幣", "31", true)/**/,

	ZAR("ZAR", "南非幣", "16", true)/**/,

	EUR("EUR", "歐元", "29", true)/**/,

	TWD("TWD", "新臺幣", "00", true)/**/,

	THB("THB", "泰銖", "30", false)/**/,

	CNH("CNH", "人民幣", "34", true)/**/,

	UNKNOWN(UNKNOWN_STR, "", UNKNOWN_STR, false);
	private String code = null;

	private String desc = null;

	private String number;

	private boolean isActive = false;

	private static Map<String, String> currs = new LinkedHashMap<String, String>();

	private CurrencyEnum(String code, String desc, String number, boolean isActive) {
		this.code = code;
		this.desc = desc;
		this.number = number;
		this.isActive = isActive;
	}

	public static CurrencyEnum toValueOf(String code) {
		if (StringUtils.isNotBlank(code)) {
			for (CurrencyEnum next : EnumSet.allOf(CurrencyEnum.class)) {
				if (StringUtils.equalsIgnoreCase(next.code, code)) {
					return next;
				}
			}
		}
		return UNKNOWN;
	}

	public static CurrencyEnum toValueOfNumber(String number) {
		if (StringUtils.isNotBlank(number)) {
			for (CurrencyEnum next : EnumSet.allOf(CurrencyEnum.class)) {
				if (StringUtils.equalsIgnoreCase(next.number, number)) {
					return next;
				}
			}
		}
		return UNKNOWN;
	}

	/**
	 * {TWD=新臺幣, MYR=馬來幣, CNH=人民幣, THB=泰銖, ZAR=南非幣, SGD=新幣, JPY=日圓, CHF=瑞郎, AUD=澳幣, HKD=港幣, USD=美元, NZD=紐幣, SEK=瑞典幣, EUR=歐元, GBP=英鎊, CAD=加幣}
	 * @return
	 */
	public static synchronized Map<String, String> getMap() {
		if (CollectionUtils.isEmpty(currs)) {
			synchronized (currs) {
				if (CollectionUtils.isEmpty(currs)) {
					Hashtable<String, String> temp = new Hashtable<String, String>();
					for (CurrencyEnum next : CurrencyEnum.values()) {
						if (next == CurrencyEnum.UNKNOWN) {
							continue;
						}
						temp.put(next.getCode(), next.getDesc());
					}
					currs = temp;
				}
			}
		}
		return currs;
	}

	public boolean isUnknown() {
		return this == UNKNOWN;
	}

	public String getDesc() {
		return desc;
	}

	public String getCode() {
		return code;
	}

	public String getNumber() {
		return number;
	}

	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.println(getMap());
		}
	}

	public boolean isTaiwan() {
		return this == CurrencyEnum.TWD;
	}

	@Override
	public String toString() {
		return desc;
	}

	public boolean isActive() {
		return isActive;
	}
}

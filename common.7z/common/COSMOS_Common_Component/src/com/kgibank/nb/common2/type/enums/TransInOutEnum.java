package com.kgibank.nb.common2.type.enums;

import java.util.EnumSet;

import com.ibm.tw.commons.util.EnumBase;
import com.ibm.tw.commons.util.StringUtils;

public enum TransInOutEnum implements EnumBase {
	IN("I", "轉入帳號"),

	OUT("O", "轉出帳號"),

	INOUT("A", "可轉入轉出的帳號"),

	UNKNOWN(UNKNOWN_STR, "狀態不明");

	private String code;
	private String desc;

	private TransInOutEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static TransInOutEnum toValueOf(String code) {
		if (StringUtils.isNotBlank(code)) {
			for (TransInOutEnum next : EnumSet.allOf(TransInOutEnum.class)) {
				if (StringUtils.equals(next.code, code)) {
					return next;
				}
			}
		}
		return UNKNOWN;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	public boolean isInAcct() {
		return this == IN || this == INOUT;
	}

	public boolean isOutAcct() {
		return this == OUT || this == INOUT;
	}

}

package com.kgibank.nb.common2.type;

import java.util.Date;

import com.kgibank.nb.common2.type.enums.SameIDEnum;
import com.kgibank.nb.common2.type.enums.SystemEnum;
import com.kgibank.nb.common2.type.enums.TransInOutEnum;

/**
 * 轉出帳號
 * @author Egg.chen
 *
 */
public interface ITransferAcct {

	public String getKey();

	/**
	 * 銀行代碼
	 * @return
	 */
	public String getBSBCode();

	/**
	 * 約定帳號
	 */
	public String getNomAcct();

	// /**
	// * 銀行代碼
	// * @return
	// */
	// public String getBankNo();
	//
	// /**
	// * 約定帳號
	// */
	// public String getAccount();

	public SystemEnum getSystem();

	public String getAcctStat();

	public TransInOutEnum getTransINOUT();

	public String getApplyChannel();

	public Date getApplyDate();

	public String getTellerID();

	public SameIDEnum getSameIDFlg();

	public String getActive();

	public CurrencyEnum getCurrencytype();

	public String getProductType();

	/**
	 * 收款分行代碼
	 */
	public String getRecipBranch();

	/**
	 * 收款人戶名
	 */
	public String getRecipname();

	// public String getValidateFlag();
}

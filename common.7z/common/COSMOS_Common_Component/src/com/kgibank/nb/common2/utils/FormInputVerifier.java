package com.kgibank.nb.common2.utils;

import java.util.Date;
import java.util.Vector;

import com.ibm.tw.commons.util.time.DateUtils;

public class FormInputVerifier {
	private boolean isError;
	private Vector message;

	public FormInputVerifier() {
		isError = false;
		message = new Vector();
	}

	public boolean isError() {
		return isError;
	}

	public Vector getErrorMesg() {
		return message;
	}

	public Vector getWarningMesg() {
		return message;
	}

	public boolean setError(String s) {
		isError = true;
		message.add(s);
		return false;
	}

	public boolean setWarningMesg(String s) {
		return setError(s);
	}

	public static int str2Int(String s) throws Exception {
		String s1 = s.trim();
		if (s1.charAt(0) == '+')
			s1 = s1.substring(1);
		return Integer.parseInt(s1);
	}

	public boolean isNotBlank(String s, String s1) {
		if (s.trim().length() == 0)
			return setError(s1);
		else
			return true;
	}

	public boolean isNotBlank(String s, boolean flag, String s1) {
		if (s.trim().length() == 0 && !flag)
			return true;
		else
			return isNotBlank(s, s1);
	}

	public boolean isInt(String s, String s1) {
		try {
			str2Int(s);
		} catch (Exception exception) {
			boolean flag = setError(s1);
			return flag;
		}
		return true;
	}

	public boolean isInt(String s, boolean flag, String s1) {
		if (s.trim().length() == 0 && !flag)
			return true;
		else
			return isInt(s, s1);
	}

	public boolean isNumber(String s, String s1) {
		if (!DataVerifier.isNumber(s))
			return setError(s1);
		else
			return true;
	}

	public boolean isNumber(String s, boolean flag, String s1) {
		if (s.trim().length() == 0 && !flag)
			return true;
		else
			return isNumber(s, s1);
	}

	public boolean isPosInt(String s, String s1) {
		boolean flag2;
		try {
			int i = str2Int(s);
			if (i > 0) {
				boolean flag = true;
				return flag;
			} else {
				boolean flag1 = setError(s1);
				return flag1;
			}
		} catch (Exception exception) {
			flag2 = setError(s1);
		}
		return flag2;
	}

	public boolean isPosInt(String s, boolean flag, String s1) {
		if (s.trim().length() == 0 && !flag)
			return true;
		else
			return isPosInt(s, s1);
	}

	public boolean isPosNumber(String s, String s1) {
		if (!DataVerifier.isPosNumber(s))
			return setError(s1);
		else
			return true;
	}

	public boolean isPosNumber(String s, boolean flag, String s1) {
		if (s.trim().length() == 0 && !flag)
			return true;
		else
			return isPosNumber(s, s1);
	}

	public boolean isNotZero(String s, String s1) {
		boolean flag2;
		try {
			int i = str2Int(s);
			if (i != 0) {
				boolean flag = true;
				return flag;
			} else {
				boolean flag1 = setError(s1);
				return flag1;
			}
		} catch (Exception exception) {
			flag2 = setError(s1);
		}
		return flag2;
	}

	public boolean isNotZero(String s, boolean flag, String s1) {
		if (s.trim().length() == 0 && !flag)
			return true;
		else
			return isNotZero(s, s1);
	}

	public boolean isFloat(String s, String s1) {
		String s2 = s.trim();
		try {
			Double.parseDouble(s2);
		} catch (Exception exception) {
			boolean flag = setError(s1);
			return flag;
		}
		return true;
	}

	public boolean isFloat(String s, boolean flag, String s1) {
		if (s.trim().length() == 0 && !flag)
			return true;
		else
			return isFloat(s, s1);
	}

	public boolean isGT(String s, String s1, String s2) {
		String s3 = s.trim();
		String s4 = s1.trim();
		try {
			double d = Double.parseDouble(s3);
			double d1 = Double.parseDouble(s4);
			if (d > d1) {
				boolean flag1 = true;
				return flag1;
			} else {
				boolean flag2 = setError(s2);
				return flag2;
			}
		} catch (Exception exception) {
			boolean flag = setError(s2);
			return flag;
		}
	}

	public boolean isGTE(String s, String s1, String s2) {
		String s3 = s.trim();
		String s4 = s1.trim();
		try {
			double d = Double.parseDouble(s3);
			double d1 = Double.parseDouble(s4);
			if (d >= d1) {
				boolean flag1 = true;
				return flag1;
			} else {
				boolean flag2 = setError(s2);
				return flag2;
			}
		} catch (Exception exception) {
			boolean flag = setError(s2);
			return flag;
		}
	}

	public boolean isLT(String s, String s1, String s2) {
		String s3 = s.trim();
		String s4 = s1.trim();
		try {
			double d = Double.parseDouble(s3);
			double d1 = Double.parseDouble(s4);
			if (d < d1) {
				boolean flag1 = true;
				return flag1;
			} else {
				boolean flag2 = setError(s2);
				return flag2;
			}
		} catch (Exception exception) {
			boolean flag = setError(s2);
			return flag;
		}
	}

	public boolean isLTE(String s, String s1, String s2) {
		String s3 = s.trim();
		String s4 = s1.trim();
		try {
			double d = Double.parseDouble(s3);
			double d1 = Double.parseDouble(s4);
			if (d <= d1) {
				boolean flag1 = true;
				return flag1;
			} else {
				boolean flag2 = setError(s2);
				return flag2;
			}
		} catch (Exception exception) {
			boolean flag = setError(s2);
			return flag;
		}
	}

	public boolean isInBetween(String s, String s1, String s2, String s3) {
		String s4 = s1.trim();
		String s5 = s.trim();
		String s6 = s2.trim();
		try {
			double d = Double.parseDouble(s4);
			double d1 = Double.parseDouble(s5);
			double d2 = Double.parseDouble(s6);
			if (d <= d1 && d1 <= d2) {
				boolean flag1 = true;
				return flag1;
			} else {
				boolean flag2 = setError(s3);
				return flag2;
			}
		} catch (Exception exception) {
			boolean flag = setError(s3);
			return flag;
		}
	}

	public Date isDate(String s, String s1, String s2, String s3) {
		return isDate(s, s1, s2, "0", "0", "0", s3);
	}

	public Date isDate(String s, String s1, String s2, String s3, String s4, String s5, String s6) {
		try {
			Date date = DateUtils.parseDateFields(Integer.parseInt(s), Integer.parseInt(s1), Integer.parseInt(s2),
					Integer.parseInt(s3), Integer.parseInt(s4), Integer.parseInt(s5));
			return date;
		} catch (Exception exception) {
			setError(s6);
		}
		Date date1 = null;
		return date1;
	}

	public Date isROCDate(String s, String s1, String s2, String s3) {
		try {
			String s4 = Integer.toString(Integer.parseInt(s) + 1911);
			Date date = isDate(s4, s1, s2, s3);
			return date;
		} catch (NumberFormatException numberformatexception) {
			setError(s3);
		}
		Date date1 = null;
		return date1;
	}

	public Date isROCDate(String s, String s1, String s2, String s3, String s4, String s5, String s6) {
		try {
			String s7 = Integer.toString(Integer.parseInt(s) + 1911);
			Date date = isDate(s7, s1, s2, s3, s4, s5, s6);
			return date;
		} catch (NumberFormatException numberformatexception) {
			setError(s6);
		}
		Date date1 = null;
		return date1;
	}

	public boolean isDateInRange(Date date, Date date1, int i, int j, String s) {
		try {
			if (DateUtils.isDateInRange(date, date1, i, j)) {
				boolean flag = true;
				return flag;
			} else {
				boolean flag1 = setError(s);
				return flag1;
			}
		} catch (IllegalArgumentException illegalargumentexception) {
			boolean flag2 = setError(illegalargumentexception.getMessage());
			return flag2;
		}
	}

	public boolean isDateInBetween(Date date, Date date1, Date date2, String s) {
		if (date.after(date1) && date.before(date2))
			return true;
		else
			return setError(s);
	}

	public boolean isDateBefore(Date date, Date date1, String s) {
		if (date.before(date1))
			return true;
		else
			return setError(s);
	}

	public boolean isDateAfter(Date date, Date date1, String s) {
		if (date.after(date1))
			return true;
		else
			return setError(s);
	}

	public boolean isVisa(String s, String s1) {
		if (DataVerifier.isVisa(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isVisa(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isVisa(s, s1);
	}

	public boolean isMaster(String s, String s1) {
		if (DataVerifier.isMaster(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isMaster(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isMaster(s, s1);
	}

	public boolean isAmericanExpress(String s, String s1) {
		if (DataVerifier.isAmericanExpress(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isAmericanExpress(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isAmericanExpress(s, s1);
	}

	public boolean isDinersClub(String s, String s1) {
		if (DataVerifier.isDinersClub(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isDinersClub(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isDinersClub(s, s1);
	}

	public boolean isJCB(String s, String s1) {
		if (DataVerifier.isJCB(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isJCB(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isJCB(s, s1);
	}

	public boolean isVisaMaster(String s, String s1) {
		if (DataVerifier.isVisaMaster(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isVisaMaster(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isVisaMaster(s, s1);
	}

	public boolean isCreditCard(String s, String s1) {
		if (DataVerifier.isCreditCard(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isCreditCard(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isCreditCard(s, s1);
	}

	public boolean isID(String s, String s1) {
		if (DataVerifier.isID(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isID(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isID(s, s1);
	}

	public boolean isPersonalID(String s, String s1) {
		if (DataVerifier.isPersonalID(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isPersonalID(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isPersonalID(s, s1);
	}

	public boolean isCompanyID(String s, String s1) {
		if (DataVerifier.isCompanyID(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isCompanyID(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isCompanyID(s, s1);
	}

	public boolean isEmail(String s, String s1) {
		if (DataVerifier.isEmail(s))
			return true;
		else
			return setError(s1);
	}

	public boolean isEmail(String s, boolean flag, String s1) {
		if (s.length() == 0 && !flag)
			return true;
		else
			return isEmail(s, s1);
	}

}
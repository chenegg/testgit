package com.kgibank.nb.common2.type.enums;

import java.util.EnumSet;

import com.ibm.tw.commons.util.EnumBase;
import com.ibm.tw.commons.util.StringUtils;

public enum SameIDEnum implements EnumBase {
	Y("Y", "本人的帳號"),

	N("N", "非本人的帳號"),

	UNKNOWN(UNKNOWN_STR, "狀態不明");

	private String code;
	private String desc;

	private SameIDEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static SameIDEnum toValueOf(String code) {
		if (StringUtils.isNotBlank(code)) {
			for (SameIDEnum next : EnumSet.allOf(SameIDEnum.class)) {
				if (StringUtils.equals(next.code, code)) {
					return next;
				}
			}
		}
		return UNKNOWN;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	public boolean isSelf() {
		return Y == this;
	}

}

package com.kgibank.nb.common2.type;

/**
 * 轉出帳號
 * @author Egg.chen
 *
 */
public interface ITransferOut {

	public String getAccount();

	public String getAccountName();

	public String getBankName();

	public String getBankNo();

	public String getType();

	public String getDormantAcctFlag();

	public String getNickName();

	public String getEachOtherSeq();

	public String getKey();

}

package com.kgibank.nb.common2.utils;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.JsonSyntaxException;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class ExtDateTypeAdapter implements JsonDeserializer<Date>, JsonSerializer<Date> {

	private final static Logger logger = LoggerFactory.getLogger(ExtDateTypeAdapter.class);
	private final DateFormat enUsFormat;
	private final DateFormat localFormat;
	private final DateFormat iso8601Format;
	private final DateFormat iso8601Format_1;
	private final DateFormat iso8601Format_2;

	public ExtDateTypeAdapter() {
		this(DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, Locale.US),
				DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT));
	}

	public ExtDateTypeAdapter(String datePattern) {
		this(new SimpleDateFormat(datePattern, Locale.US), new SimpleDateFormat(datePattern));
	}

	public ExtDateTypeAdapter(int style) {
		this(DateFormat.getDateInstance(style, Locale.US), DateFormat.getDateInstance(style));
	}

	public ExtDateTypeAdapter(int dateStyle, int timeStyle) {
		this(DateFormat.getDateTimeInstance(dateStyle, timeStyle, Locale.US),
				DateFormat.getDateTimeInstance(dateStyle, timeStyle));
	}

	public ExtDateTypeAdapter(DateFormat enUsFormat, DateFormat localFormat) {
		this.enUsFormat = enUsFormat;
		this.localFormat = localFormat;
		this.iso8601Format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
		this.iso8601Format.setTimeZone(TimeZone.getTimeZone("UTC"));
		this.iso8601Format_1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US);
		this.iso8601Format_2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
	}

	@Override
	public JsonElement serialize(Date src, Type typeOfSrc, JsonSerializationContext context) {
		synchronized (localFormat) {
			String dateFormatAsString = enUsFormat.format(src);
			return new JsonPrimitive(dateFormatAsString);
		}
	}

	@Override
	public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
			throws JsonParseException {
		if (json == null) {
			return null;
		}
		if (!(json instanceof JsonPrimitive)) {
			throw new JsonParseException("The date should be a string value");
		}
		/* 使用長度來判斷 */
		Date date = deserializeToDate(json);
		if (typeOfT == Date.class) {
			return date;
		} else if (typeOfT == Timestamp.class) {
			return new Timestamp(date.getTime());
		} else if (typeOfT == java.sql.Date.class) {
			return new java.sql.Date(date.getTime());
		} else {
			throw new IllegalArgumentException(getClass() + " cannot deserialize to " + typeOfT);
		}
	}

	private Date deserializeToDate(JsonElement json) {
		synchronized (localFormat) {
			if (Pattern.matches("^[\\d]{4,}-[0-1][0-9]-[0-3][0-9]T.*", json.getAsString())) {
				if (json.getAsString().length() > 25) {
					try {
						return iso8601Format_1.parse(json.getAsString());
					} catch (ParseException ignored) {
					}
				}
				try {
					return iso8601Format_2.parse(json.getAsString());
				} catch (ParseException ignored) {
				}
			}
			/* 本專案預設為這個,所以以這個排在前面 */
			try {
				return enUsFormat.parse(json.getAsString());
			} catch (ParseException ignored) {
			}
			try {
				/* Apr 30, 2015 11:00:00 AM */
				// SimpleDateFormat formatter = new SimpleDateFormat("MMM dd,
				// yyyy hh:mm:ss a", Locale.US);
				return localFormat.parse(json.getAsString());
			} catch (ParseException ignored) {
			}
			try {
				return iso8601Format.parse(json.getAsString());
			} catch (ParseException e) {
				throw new JsonSyntaxException(json.getAsString(), e);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(ExtDateTypeAdapter.class.getSimpleName());
		sb.append('(').append(localFormat.getClass().getSimpleName()).append(')');
		return sb.toString();
	}
}

package com.kgibank.nb.common2.type;

public interface IAccount {
	public String getAccountNo();

}

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2009.
 *
 * ===========================================================================
 */
package com.cosmos.code;


/**
 * <p>系統代碼表</p>
 *
 * @author  jeff
 * @version 1.0, Oct 13, 2009
 * @see	    
 * @since 
 */
public enum CosmosSystemId {
 
//	/** 企網服務系統 */
//	CIB("CIB", "000"),
	
	/** 企網客戶服務系統 */
	B2C("B2C", "001"),
	
	/** 企網行員管理系統 */
	B2E("B2E", "002"),
	
	/** 中介系統 */
	ESB("ESB", "100"),
	
	/** CICS 主機 */
	CICS("CICS", "200"),
	
	/** 台幣 WebService */
	BILL("BILL", "300"),
	
	/** 外幣主機 */
	NEFX("NEFX", "400"),
	
	/** 貸款 (CICS主機) */
	LOAN("LOAN", "500"),
	
	/** 貸款 (開發主機) */
	CDI("CDI", "600"),
	
	/** 企業網銀(含前後台) */
	EB("EB", "010"),
	
	/** 個人網銀(含前後台) */
	PB("PB", "011");
	
	
	/** 系統代碼 */
	private String systemId;
	
	/** 系統識別碼 */
	private String systemCode;

	
	CosmosSystemId(String systemId, String systemCode) {
		this.systemId = systemId;
		this.systemCode = systemCode;
	}


	public String getSystemId() {
		return systemId;
	}


	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}


	public String getSystemCode() {
		return systemCode;
	}


	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
	
	 

}



 
/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.code;

import java.math.BigDecimal;



/**
 * <p>凱基共用ID</p>
 *
 * @author  Leo
 * @version 1.0, 2011/3/29
 * @see	    
 * @since 
 */
public class CosmosCommonId {

	public static String COSMOS_BANK = "809";

	public static String COSMOS_BANK_ACC = "8090000";
	
	/** 逾時未作業時間 (min) */
	public final static int EXPIRE_TIME = 10;
	
	
	/** 帳號限額：若設定99999萬，視為無上限 */
	public static BigDecimal UNLIMITED_MOENY = new BigDecimal(999999999);
	
	/** 下載檔案編碼 */
	public static String DOWNLOAD_FILE_ENCODING = "BIG5";
	
	/** CHECKBOX 共同參數 */
	public static String CHECKBOX_ALL = "CHECKBOX_ALL"; 
	public static String CHECKBOX_KEY = "CHECKBOX_KEY";
	
	/** 流程套餐交易代號 */
	public final static String UAA_SCHEMASUIT_TASKID = "CAAAG106";
	
	
	
}



 
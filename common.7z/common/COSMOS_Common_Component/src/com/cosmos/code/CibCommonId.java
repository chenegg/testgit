/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.code;

import java.math.BigDecimal;



/**
 * <p>企網共用ID</p>
 *
 * @author  Leo
 * @version 1.0, 2011/3/29
 * @see	    
 * @since 
 */
public class CibCommonId {

	public static String CIB_BANK_ID = "001";
	
	public static String CIB_BANK_B2C = "IBM 企業網路銀行";
	
	public static String CIB_BANK_B2E = "IBM 企網管理平台";
	
	/** 逾時未作業時間 (min) */
	public final static int EXPIRE_TIME = 5;
	
	
	/** 帳號限額：若設定99999萬，視為無上限 */
	public static BigDecimal UNLIMITED_MOENY = new BigDecimal(999999999);
	
	/** 下載檔案編碼 */
	public static String DOWNLOAD_FILE_ENCODING = "BIG5";
	
	/** CHECKBOX 共同參數 */
	public static String CHECKBOX_ALL = "CHECKBOX_ALL"; 
	public static String CHECKBOX_KEY = "CHECKBOX_KEY";
	
	/** 流程套餐交易代號 */
	public final static String UAA_SCHEMASUIT_TASKID = "CAAAG106";
	
	
	
}



 
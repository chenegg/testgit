/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2009.
 *
 * ===========================================================================
 */
package com.cosmos.code;

import com.ibm.tw.commons.util.StringUtils;


/**
 * <p>
 * 網銀共同錯誤代碼
 * </p>
 * 
 * 系統代碼以”NB”統稱
 * 
 * @author jeff
 * @version 1.0, Oct 16, 2009
 * @see
 * @since
 */
public enum CibErrorCode {
	/* 系統異常 */
	

	BUILD_PAGE_CODE_FAILED("0001", "無法建立Page code"),

	BUILD_VIEW_PARAM_FAILED("0002", "無法建立View Param"),

	BUILD_VIEW_FORM_FAILED("0003", "無法建立View Form"),
	
	INIT_VIEW_FORM_FAILED("0004", "無法初始View Form"),
	
	BUILD_ACTION_FAILED("0005", "無法建立Action"),
	
	DATABASE_EXCEPTION("0006", "資料庫異常"),
	
	FEE_EXCEPTION("0007", "手續費查詢異常"),
	
	EXNO_EXCEPTION("0008", "議價編號查詢異常"),
	
	CURRENCY_EXCEPTION("0009", "幣別轉換異常"),
	
	ILLEGAL_LOGIN("0010", "非開發模式禁止由開發登入頁登入"),
	
	NOT_VALID_TIME("0011", "非標準日期格式"),

	CRYPT_EXCEPTION("0012", "加解密異常"),
	
	BUSINESS_DAY_EXCEPTION("0013", "營業日查詢異常"),
	
	BUSINESS_TIME_EXCEPTION("0014", "營業時間查詢異常"),
	
	SSO_CHECK_FAILED("0015", "SSO檢核失敗"),
	
	XML_VERIFY_CN_ERROR("0016", "身分檢驗失敗"),
	XML_VERIFY_CERT_ERROR("0017", "憑證檢驗失敗"),
	XML_CERT_NOT_FOND_ERROR("0018", "本功能需持有憑證方可進行,請洽有權限人員進行人員憑證設定"),
	XML_PASS_CERT_NOT_FOND_ERROR("0019", "方才交易已送呈,請洽主管至待辦事項進行放行"),		
	PMTID_EXCEPTION("0020", "無法取得交易序號（PMTID）"),

	CONVERT_TABLE_NOT_FOUND("0021", "轉碼表不存在"),
	CONVERT_EXCEPTION("0022", "轉碼異常"),
	INT_RATE_NOT_READY("0023", "今日匯利率尚未掛牌，請稍後再試。"),
	INT_RATE_EXCEPTION("0023", "無法取得今日利率。"),
	FX_EXCEPTION("0024", "當日尚未開放外匯交易。"),
 
	REMITTER_PAYEETYP_DENY("0025", "居留證證載有效期限未滿一年或持官員證/護照之外國人不開放自動化通路外匯交易，如有需要，請洽分行辦理。"),
	
	/* 開戶管理 */
	EMPLOYEE_ROLE_CHECK_FAILED("0101", "員工角色檢核失敗"),
	EMPLOYEE_PASSWORD_CHECK_FAILED("0102", "員工密碼檢核失敗"),
	
	MANAGER_VERIFY_ERROR("0103", "主管代號密碼驗證失敗"),
	MAN_EMP_DEPARTMENT_ERROR("0104", "主管代號與行員代號需屬同單位"),
	MANAGER_NOT_FOUND("0105", "主管代號不存在"),
	REGISTER_ACCOUNT_NOT_FOUND("0106", "帳號不存在"),
	
	REGISTER_ACCOUNT_SYNC_ERROR("0107", "帳號同步錯誤"),
	
	REGISTER_COMPANY_NOT_FOUND("0108", "查無授權人公司資料"),
	
	REGISTER_ACCOUNT_MUST_ADD("0109", "請至少新增一筆授權帳號"),
	
	REGISTER_ACCOUNT_NONE_ACTION("0110", "無變更任何約定轉出帳號狀態"),
	
	REGISTER_REL_ACCOUNT_NONE_ACTION("0111", "無變更任何授權帳號狀態"),
	
	REGISTER_REL_ACCOUNT_MUST_ONERECORD("0112", "至少存在一筆授權帳號"),
	
	MANAGER_ROLE_VERIFY_ERROR("0113", "主管代號密碼驗證失敗"),

	
	/* 流程異常 */
	FLOW_SAVE_FAIL("0201", "無法儲存草稿"),
	
	FLOW_EDIT_FAIL("0202", "無法儲存草稿"),
	 
	FLOW_START_FAIL("0203", "流程啟動失敗"),
	
	FLOW_VERIFY_FAIL("0204", "流程審核失敗"),
	FLOW_PASS_FAIL("0205", "流程放行失敗"),
	FLOW_DEL_WORKITEM_FAIL("0206", "工作項目刪除失敗"),	
	FLOW_DEL_DRAFTITEM_FAIL("207", "草稿項目刪除失敗"),		
	FLOW_REJECT_FAIL("0208", "流程退件失敗"),			
	FLOW_DOC_NOTFOUND("0209", "無法取得流程文件"),
	FLOW_WORKITEM_NOTFOUND("0210", "無法取得工作項目"),
	FLOW_DRAFTITEM_NOTFOUND("0211", "無法取得工作項目"),	 
	FLOW_COMPLETE_WORK_FAIL("0212", "無法完成工作項目"),
	FLOW_LOCK_WORK_FAIL("0213", "此筆案件已被其他使用者執行,不可重複執行"),
	FLOW_EDIT_MONEY_FAIL("0214", "付款金額超過授權轉出金額，請修改金額，或洽 貴公司系統管理員提高您的每筆(批)扣帳限額"),
	FLOW_VERIFY_MONEY_FAIL("0215", "付款金額超過授權轉出金額，請修改金額，或洽 貴公司系統管理員提高您的每筆(批)扣帳限額"),
	FLOW_PASS_MONEY_FAIL("0216", "付款金額超過授權轉出金額，請修改金額，或洽 貴公司系統管理員提高您的每筆(批)扣帳限額"),
	FLOW_DAILY_MONEY_FAIL("0217", "您本日放行總金額已超過授權累計放行金額，可洽 貴公司系統管理員提高您的每日放行累計限額"),
	FLOW_UAA_MONEY_FAIL("0218", "交易金額轉換授權中心計算金額失敗"),
	
	FLOW_NO_LIST_PARAM("0219", "查無待辦清單參數（待辦清單總覽頁導向各交易之清單頁面）"),
	 

	/* 中介異常 */
	ESB_MQ_EXCEPTION("0300", "MQ連線異常"),
	ESB_INVALID_TITA("0301", "EAI TITA Error"),	
	ESB_INVALID_TOTA("0302", "EAI TOTA Error"), 
	ESB_TIMEOUT_EXCEPTION("0303", "EAI Timeout Exception(WMB未回應)"),	 
	ESB_SYNC_TXN_FAIL("0304", "執行同步交易失敗"),   
	ESB_RS_CLASS_NOTOUND("0305", "查無RQ對應之RS物件，通常此錯誤發生於交易不是同步交易，因此沒有回應電文"),
	ESB_MQ_DATA_EXCEPTION("0306", "主機資料異常"),
	
	 
	/* 登入異常 */
	USER_NOT_FOUND("0401", "使用者不存在"),
	
	USER_IS_STOPPED("0402", "使用者已被暫停使用"),
	
	PASSWORD_VALIDATE_ERROR("0403", "密碼驗證失敗"),
	
	PASSWORD_FAIL_COUNT("0404", "密碼輸入錯誤達 n 次"),
	
	PASSWORD_EXPIRED("0405", "密碼已逾期未變更"),
	
	USER_FIRST_LOGIN("0406", "使用者首次登入"),
	
	USER_LOGIN_DUPLICATE("0407", "使用者重覆登入"),
	
	USER_REQUIRED_CHANGE_PASSWORD("0408", "使用者必需更改密碼"),
	
	USER_FIRST_LOGIN_EXPIRED("0409", "使用者首次登入逾時"),
	
	ROOT_IS_STOPPED("0410", "授權管理者已被暫停使用"),
	
	/* 服務系統錯誤 */
	 
	SERVICE_START_STATUS_EXCEPTION("0601", "服務系統執行中，無法再次啟動（請檢查B2E JMXSERVICE TABLE）"),
	SERVICE_START_ONCE_EXCEPTION("0602", "服務系統本日已經執行，無法再次啟動"),
	SERVICE_NOT_BUSINESS_DATE("0603", "系統日非營業日，無法啟動"),
	SERVICE_INIT_EXCEPTION("0604", "服務系統初始化異常"),
	DOC_LOCK_ERROR("0605", "交易鎖定失敗"),
	FILE_OPERATION_FAIL("0606", "檔案處理失敗"),
	FTP_OPERATION_FAIL("0607", "FTP檔案處理失敗"),
	SERVICE_DATABASE_EXCEPTION("0608", "服務資料庫處理失敗"),
	
	/* 憑證作業錯誤 */
	RA_LOGIN_FAIL("0701", "憑證系統登入失敗"),
	
	CERT_APLLY_FAIL("0702", "憑證申請失敗"),
	
	CERT_APLLY_WAIT("0703", "CA尚未核發憑證"),
	
	COMPANY_NOT_FOUND("0704", "此統一編號非企網客戶"),
	
	VERIFY_SIGNDATA_FAIL("0705", "驗章失敗"),
	
	NO_CERTIFICATE_AUTH("0706", "無此憑證的使用權限"),
	
	CERTIFICATE_INVALID("0707", "無效之憑證"),
	
	CERT_RENEW_FAIL("0708", "憑證更新失敗"),
	
	NOT_COMPANY_CERTIFICATE("0709", "非公司所屬之憑證"),
	
	VERIFY_CARD_FAIL("0710", "驗證卡片失敗"),
	
	CERT_RENEW_FEE_FREE("0711", "此企業戶憑証更新不需收費"),
	
	CERT_RENEW_FEE_ZERO("0712", "此憑證不需繳費，不可執行繳費動作！"),
	
	CERT_RENEW_DUE_DATE("0713", "已超過憑證到期日，不可進行憑證繳費！"),
	
	CERT_REPAY_FEE("0714", "此憑證已申請線上繳費中，請勿重複交易！"),
	
	CERT_FEE_NOT_FOUND("0715", "憑證優惠不存在！"),
	
	CERT_FEE_OUT_DATE("0716", "已超過優惠期限，須依規作繳費！"),
	
	COMPANY_NOT_FOUND_TRY_AGAIN("0717", "該統編非企網客戶，請重新輸入"),
	
	NOT_COSMOS_ACCOUNT("0718", "扣款帳號非凱基銀行帳號"),
	
	CERT_FEE_REJECT("0719", "與應繳憑證費用不符，請退件後重新執行憑證線上繳費！"),
	
	TOKEN_MAC_CHECK_FAIL("0729", "載具 MAC Server 驗證失敗"),
	
	GET_CERT_MAC_FAIL("0730", "憑證 MAC Server 驗證失敗"),
	
	/* 授權作業錯誤 */
	USER_LOGINACCOUNT_EXIST("0802", "使用者代號已存在"),
	
	USER_PASSWORD_CRYPT_ERROR("0803", "使用者密碼壓碼異常"),
	
	USER_ROLE_EXIST("0804", "該人員已有所屬角色"),
	
	ROLE_NOT_FOUND("0811", "角色不存在"),
	
	ROLE_EXIST("0812", "角色已存在"),
	
	ROLE_USER_EXIST("0813", "該角色已有所屬人員，不可刪除"),
	
	ROLE_NODE_EXIST("0814", "該角色已設定於簽核流程步驟，不可刪除"),
	
	FLOWSCHEMA_NOT_FOUND("0821", "流程不存在"),
	
	XML_PARSE_ERROR("0822", "Flex XML 解析錯誤"),
		
	IN_FLOW_DOC("0823", "尚有流程中案件，不可變更"),
	
	FLOWSCHEMA_EXIST("0824", "流程名稱已存在"),
	
	USER_STATUS_ACTIVE("0825", "此統一編號已啟用"),
	
	 
	/* 以下為FileParser錯誤 */
	
	FILE_DOWNLOAD_EXCEPTION("0901", "檔案下載錯誤"),
	FILE_UNSUPPORTED_ENCODING("0902", "不支援編碼"),

	FILE_DATA_FIELD_NOT_MATCH("0903", "資料欄位不符"),

	FILE_DATA_FORMAT_ERROR("0904", "資料格式錯誤，請檢查後重新匯入"),
	FILE_DATA_LENGTH_NOT_MATCH("0905", "資料格式錯誤，請檢查後重新匯入"),
	FILE_FORMAT_NOT_FOUND("0906", "資料格式不存在，請檢查後重新匯入"),
	
	
	VALIDATE_PAYEE_ERROR_1("0911", "付款通路不可為空白"),
	VALIDATE_PAYEE_ERROR_2("0912", "付款通路錯誤"),
	VALIDATE_PAYEE_ERROR_3("0913", "跨行匯款時，收款人戶名不可為空白"),
	VALIDATE_PAYEE_ERROR_4("0914", "自行轉帳收款銀行須為8090000或空白"),
	VALIDATE_PAYEE_ERROR_5("0915", "收款銀行代號不可為空白"),
	VALIDATE_PAYEE_ERROR_6("0916", "收款銀行代號錯誤"),
	VALIDATE_PAYEE_ERROR_7("0917", "收款帳號不可為空白"),
	VALIDATE_PAYEE_ERROR_8("0918", "收款帳號須為數字"),
	VALIDATE_PAYEE_ERROR_9("0919", "凱基銀行收款帳號須為12位數字"),
	VALIDATE_PAYEE_ERROR_10("0920", "收款帳號非凱基銀行帳號"),
	VALIDATE_PAYEE_ERROR_11("0921", "收款人統編格式錯誤"),
	VALIDATE_PAYEE_ERROR_12("0922", "收款人統編錯誤"),
	VALIDATE_PAYEE_ERROR_13("0923", "手續費負擔別錯誤"),
	VALIDATE_PAYEE_ERROR_14("0924", "收款人戶名須為全型字"),
	VALIDATE_PAYEE_ERROR_15("0925", "附言必須為全形字"),
	VALIDATE_PAYEE_ERROR_16("0926", "跨行匯款之收款銀行不可為凱基銀行代碼"),
	VALIDATE_PAYEE_ERROR_17("0927", "收款人資料不存在"),
	VALIDATE_PAYEE_ERROR_18("0928", "查詢常用收款人失敗"),
	VALIDATE_PAYEE_ERROR_19("0929", "收款人Email格式錯誤"),
	VALIDATE_PAYEE_ERROR_20("0930", "收款人地址必須為全形字"),
	
	
	
	VALIDATE_PAYER_ERROR_1("0931", "付款人統編不可為空白"),
	VALIDATE_PAYER_ERROR_2("0932", "付款人統編不正確"),
	VALIDATE_PAYER_ERROR_3("0933", "付款日期不可為空白"),
	VALIDATE_PAYER_ERROR_4("0934", "日期錯誤"),
	VALIDATE_PAYER_ERROR_5("0935", "付款日期已超過,請修改付款日期"),
	VALIDATE_PAYER_ERROR_6("0936", "預約付款日期限365天內,請修改付款日期"),
	VALIDATE_PAYER_ERROR_7("0937", "付款帳號不可為空白"),
	VALIDATE_PAYER_ERROR_8("0938", "付款帳號須為數字"),
	VALIDATE_PAYER_ERROR_9("0939", "查詢有轉帳權限付款帳號失敗"),
	VALIDATE_PAYER_ERROR_10("0940", "無付款帳號轉帳權限"),
	VALIDATE_PAYER_ERROR_11("0941", "付款性質必須為全形字"),
	VALIDATE_PAYER_ERROR_12("0942", "付款金額須大於0"),
	VALIDATE_PAYER_ERROR_13("0943", "跨行匯款金額不可大於 5000萬"),
	VALIDATE_PAYER_ERROR_14("0944", "付款性質查詢失敗"),
	VALIDATE_PAYER_ERROR_15("0945", "付款性質不存在"),
	VALIDATE_PAYER_ERROR_16("0946", "營業時間已過，請修改付款日期"),
	VALIDATE_PAYER_ERROR_17("0947", "付款金額格式錯誤"),
	VALIDATE_PAYER_ERROR_18("0948", "付款統編無此付款帳號"),	
	
	VALIDATE_INVOICE_ERROR_1("0951", "請輸入發票號碼"),
	VALIDATE_INVOICE_ERROR_2("0952", "請輸入會計憑證日期"),
	VALIDATE_INVOICE_ERROR_3("0953", "會計憑證日期錯誤"),
	VALIDATE_INVOICE_ERROR_4("0954", "請輸入會計憑證金額"),
	VALIDATE_INVOICE_ERROR_5("0955", "會計憑證金額須大於0"),
	VALIDATE_INVOICE_ERROR_6("0956", "發票號碼錯誤"),
	VALIDATE_INVOICE_ERROR_7("0957", "會計憑證總筆數最多為99筆"),
	VALIDATE_INVOICE_ERROR_8("0958", "會計憑證金額格式錯誤"),
	VALIDATE_PBS_PAYEEACCOUNTNO_ERROR("0959", "證券款檔案上傳檔扣入帳號不正確與所選的不一致"),
	VALIDATE_PBS_TRANTYPE_ERROR("0960", "證券款檔案上傳轉帳業務種類與所選的不一致"),	
	VALIDATE_PAYEE_ERROR_21("0961", "收款銀行國別為CN時才可輸入中文"),
	VALIDATE_PBS_DATE_ERROR_1("0962", "證券款檔案上傳轉帳日期必須為同ㄧ日"),	
	VALIDATE_PBS_PAYEEUID_ERROR("0963", "證券款檔案上傳券商統一編號必須一致"),	
	VALIDATE_PBS_TRANSTYPE_ERROR("0964", "證券款檔案上傳轉帳業務種類必須一致"),	
	VALIDATE_PBS_PAYEEACCOUNT_ERROR("0965", "證券款檔案上傳證券商專戶帳號必須一致"),
	VALIDATE_PBS_DB_ERROR("0966", "證券款檔案上傳重複"),
	VALIDATE_PBS_DUPLICATE_ERROR("0967", "證券款檔案上傳檔重複,若要重新傳檔,須執行原上傳檔案取消或刪除"),	
	VALIDATE_PBS_ACCOUNTTYPEID_ERROR("0968", "帳號轉帳類別代號必須為1115或1315"),	
	VALIDATE_PBS_TRANSTYPE_ERROR_1("0969", "轉帳業務種類必須為101或102或103或104或201"),	
	VALIDATE_PBS_DEDUCTSEQ_ERROR("0970", "當業務種類為103時扣款順序必填"),	
	VALIDATE_PBS_TOTALCOUNT_ERROR("1970", "首筆總筆數與明細總筆數不符"),	
	VALIDATE_PBS_TOTALAMT_ERROR("1971", "首筆總金額與明細總金額不符"),	
	VALIDATE_PBS_PAYERACCOUNT_ERROR1("1972", "客戶銀行轉帳帳號必須為數字"),	
	VALIDATE_PBS_PAYERACCOUNT_ERROR2("1973", "客戶銀行轉帳帳號不可為空白"),	
	VALIDATE_PBS_PAYERACCOUNT_ERROR3("1974", "非凱基銀行帳號"),		
	VALIDATE_PBS_DATE_ERROR_2("1975", "轉帳日期不可為空白"),
	VALIDATE_PBS_DATE_ERROR_3("1976", "轉帳日期錯誤"),
	VALIDATE_PBS_DATE_ERROR_4("1978", "轉帳日期限365天內,請修改轉帳日期"),
	VALIDATE_PBS_DATE_ERROR_5("1979", "轉帳日期已超過,請修改付款日期"),
	VALIDATE_PBS_DATE_ERROR_6("1980", "放行時間已超過!"),
	VALIDATE_PBS_ACCOUNTTYPEID1_ERROR("1981", "當檔案為申購扣款只能有扣帳金額"),
	VALIDATE_PBS_ACCOUNTTYPEID2_ERROR("1982", "當檔案為申購退款只能有入帳金額"),
	VALIDATE_PBS_ACCOUNTTYPEID3_ERROR("1983", "當檔案為手續費折讓款只能有入帳金額"),
	VALIDATE_PBS_PAYERACCOUNT1_ERROR("1984", "客戶銀行轉帳帳號必須為凱基帳號"),
	VALIDATE_PBS_DEDUCT_ERROR("1985", "扣款順序錯誤"),
	VALIDATE_PBS_DATE_ERROR_7("1986", "上傳時間已超過!"),
	
	VALIDATE_DETAIL_ERROR_1("0971", "付款金額不足支付手續費，請重新輸入"),
	VALIDATE_DETAIL_ERROR_2("0972", "收款銀行代號錯誤"),
	VALIDATE_DETAIL_ERROR_3("0973", "收款人資料不存在"),
	VALIDATE_DETAIL_ERROR_4("0974", "收款帳號不可與付款帳號相同"),	
	VALIDATE_DETAIL_ERROR_5("0975", "指定還款本金必須為正整數、且不得大於本金餘額！"),	
	
	VALIDATE_DATE_ERROR_1("0991", "付款日期已超過，請修改付款日期"),
	VALIDATE_DATE_ERROR_2("0992", "營業時間已過，請修改付款日期"),
	VALIDATE_DATE_ERROR_3("0993", "預約付款日期限365天內，請修改付款日期"),
	VALIDATE_CD_DATE_ERROR_3("5993", "預約定存日限定180天內"),
	VALIDATE_DATE_ERROR_4("0994", "預約週期起始日須大於今日"),
	VALIDATE_DATE_ERROR_5("0995", "預約週期迄日限365天內"),
	VALIDATE_DATE_ERROR_6("0996", "整批交易的付款日期必須為同ㄧ日"),	
	VALIDATE_DATE_ERROR_7("0997", "多扣多入整批交易的付款性質必須相同"),
	
	
	VALIDATE_DATE_ERROR_8("0990", "繳款日期已過，請刪除本案件！"),	
	VALIDATE_DATE_ERROR_9("0999", "營業時間已過！"),
	VALIDATE_DATE_ERROR_10("0989", "營業時間未到！"),
	VALIDATE_DATE_ERROR_11("0981", "今日為非營業日！"),
	VALIDATE_DATE_ERROR_12("0976", "開立定存日已逾期！"),
	
	VALIDATE_SIZE_ERROR("0998", "匯入總筆數不可超過$params.MAXCOUNT筆"),
	VALIDATE_DATE_ERROR_13("1987", "查詢時間已過！"),
	 
	/* 以上為FileParser錯誤 */
	

	/* 交易異常 */
	
	NO_TASK_PERMISSION("1001", "查無交易權限"),
	INVALID_ACTION_TYPE("1002", "無此作業項目"),
	DUPLICATE_PAYEE("1003", "收款銀行與收款帳號已存在"),
	DUPLICATE_FR_PAYEE("1103", "收款帳號已存在"),
	PAYEE_NOT_FOUND("1004", "收款人資料不存在"),
	AFTER_BUSINESS_TIME("1005", "營業時間已過，請修改付款日期"),
	INVALID_TXTYPE("1006", "不合法的交易類型"),
	EXPIRED_TXDATE("1007", "付款日期已超過，請修改付款日期"),
	VERIFY_ERROR("1008", "驗章失敗"),
	
	CANCEL_FLOW_EXISTS("1009", "尚有註銷中的流程，不可重複註銷"),
	
	CANCEL_DOC_NOT_FOUND("1010", "被註銷的交易不存在"),
	
	CANCEL_DOC_INVALID_STATUS("1011", "被註銷的交易已經不是預約狀態，請至「轉帳付款交易處理狀態查詢」查詢交易狀態"),
	
	OVER_AMT_LIMIT("1012", "週期預約之跨行交易，付款限額為5,000萬"),
	NO_PAYER_ACCOUNT_PERMISSION("1013", "您無付款帳號轉帳權限，可洽 貴公司系統管理員修改您的帳號權限"),
	TX_DATE_EXPIRED("1014", "付款日期已逾期超過14天以上，請退件重新修改付款日期"),
	CD_DATE_EXPIRED("5014", "開立定存日已逾期超過14天以上，請退件重新修改開立定存日"),
	CD_CANCEL_DATE_EXPIRED("5015", "解約日期已逾期超過14天以上，請退件重新修改日期"),
	LC_DATE_EXPIRED("6014", "申請日已逾期超過14日,請退件刪除並重新申請"),
	LC_DATE_EXPIRED_APPLYD("6015", "有效期限不得早於申請日"),
	LC_DATE_EXPIRED_SYSD("6016", "有效期限需大於本系統日"),
	LC_DATE_EXPIRED_LAD("6017", "最後裝運日不得大於有效期限"),
	OLD_PWD_ERROR("1015", "您的舊密碼有誤，請核對後再重新輸入，謝謝!」 "),
	NEW_PWD_ERROR("1016", "新密碼錯誤，請參考安全說明，重新輸入"),
	SAME_PWD_ACCOUNT_ERROR("1017", "新密碼和使用者代號或用戶代號/統編相同，請參考安全說明，重新輸入"),
	SAME_PWD_ERROR("1018", "新密碼和舊密碼相同，請參考安全說明，重新輸入"),
	NEW_PWD_ERROR02("1019", "需與新密碼欄位內容相同，若不同，顯示錯誤「確認密碼輸入錯誤」"),
	OLD_PWD_ERROR02("1020", "password error time over 3 times"),	
	NO_PAYER_ACCOUNT_QUERY_PERMISSION("1021", "您無綜活存帳號查詢權限，可洽 貴公司系統管理員修改您的帳號權限"),
	AFTER_BUSINESS_HOUR_NO_PASS("1022", "已超過營業時間，不可作放行!"),
	CD_CANCEL_DATE_OVER_DUE("1023", "解約日期已逾期，請修改解約日期"),
	AFTER_BUSINESS_HOUR_DUE_TOMORROW("1024", "營業時間已過且此存單於明日到期，不得進行解約"),
	AFTER_BUSINESS_HOUR_ASSIGN_CD_CANCEL_DATE("1025", "營業時間已過，請修改解約日期"),
	CD_CANCEL_DATE_WITHIN_180_DAYS("1026", "預約解約日期限定180天內"),
	CD_DATE_WITHIN_180_DAYS("5026", "預約定存日限定180天內"),
	INPUT_PERIOD_TYPE_NOT_SHOWN("5027", "沒有存期或到期日"),
	CD_DATE_WITHIN_90_DAYS("5028", "預約定存日限定90天內"),
	CD_CANCEL_DATE_WITHIN_90_DAYS("5029", "預約解約日期限定90天內"),
	
	CD_CANCEL_DATE_OVER_EXPIRE_DATE("1027", "解約日期需小於定存到期日"),
	NO_PAYER_ACCOUNT_TRANSFER_PERMISSION("1028", "您無綜活存帳號轉帳權限，可洽 貴公司系統管理員修改您的帳號權限"),
	
	NOT_IN_BUSINESS_TIME("1029", "非營業時間！"),
	AFTER_BUSINESS_HOUR_NO_CD_TX("0130", "營業時間已過，請修改開立定存日期"),
	AFTER_SYSTEM_DATE_UPDATE_CD_DATE("0131", "開立定存日已超過系統日，請修改開立定存日"),
	AFTER_SYSTEM_DATE_CD_DATE("0132", "開立定存日已逾期"),
	AFTER_BUSINESS_HOUR("0133", "營業時間已過"),
	AFTER_SYSTEM_DATE_14DAYS("0134", "開立定存日已逾期超過14天"),
	AFTER_SYSTEM_DATE_14DAYS_UPDATE("0135", "開立定存日已逾期超過14天，請退件重新修改日期"),
	AFTER_SYSTEM_DATE_CD_CANCEL_DATE("0136", "解約日期已逾期"),
	
	EMPLOYEENO_IS_NULL("2001", "員工編號為空白"),
	EMPLOYEENO_IS_NOT_EXIST("2002", "員工編號不存在"),
	EMPLOYEENO_IS_EXIST("2003", "員工編號已存在"),
	INVALID_DATE_FORMAT("2004", "日期格式錯誤"),
	ACTION_NOT_DEFINED("2005", "無此功能"),
	LOAN_HIS_NOT_FOUND("2006", "對不起, 您輸入的統一編號無對應帳號存在。"),
	DATA_NOT_FOUND("2007", "查詢無資料"),
	TXDATA_NOT_FOUND("2008", "付款日期無資料"),
	CD_CANCEL_DOC_INVALID_STATUS("2009", "被註銷的交易已經不是預約狀態，請至「臺幣綜定存交易處理狀態查詢」查詢交易狀態"),
	FR_CD_CANCEL_DOC_INVALID_STATUS("2010", "被註銷的交易已經不是預約狀態，請至「外幣綜定存交易處理狀態查詢」查詢交易狀態"),
	FR_CD_CANCEL_DATE_INVALID("2011", "預約生效日需大於當日系統日"),
	
	/* 外匯交易 */
	NO_FX_PERMISSION("0501","貴戶身分別無權限執行外匯交易，請洽分行。 "),
	FX_DETAIL_MUST_ONERECORD("0543", "至少需存在一筆明細資料"),
	FX_DETAIL_ERROR_1("0544", "請確認資料正確"),
	
	DATABASE_FX_ERROR_1("0539","收款行國別查詢失敗"),
	DATABASE_FX_ERROR_2("0541","匯款性質查詢失敗"),
	
	VALIDATE_FX_DATE_ERROR_1("0502", "預約付款日限定90天內，請修改付款日期"),
	
	VALIDATE_FX_PAYEY_ERROR_1("0516","付款帳號幣別不得為空白"),
	VALIDATE_FX_PAYEY_ERROR_2("0533","付款幣別錯誤"),
	
	VALIDATE_FX_PAYEE_ERROR_1("0503","收款帳號不可為外幣活存"),
	VALIDATE_FX_PAYEE_ERROR_2("0504","收款帳號需為外幣活存"),
	VALIDATE_FX_PAYEE_ERROR_3("0517","收款帳號須為英數字"),
	VALIDATE_FX_PAYEE_ERROR_4("0518","交易類型不可為空白"),
	VALIDATE_FX_PAYEE_ERROR_5("0519","交易類型錯誤"),
	VALIDATE_FX_PAYEE_ERROR_6("0520","收款人戶名包含非允許字元"),
	VALIDATE_FX_PAYEE_ERROR_7("0521","收款人戶名不可為中文"),
	VALIDATE_FX_PAYEE_ERROR_8("0522","收款人地址包含非允許字元"),
	VALIDATE_FX_PAYEE_ERROR_9("0523","收款人地址不可為中文"),
	VALIDATE_FX_PAYEE_ERROR_10("0524","收款人電話格式錯誤"),
	VALIDATE_FX_PAYEE_ERROR_11("0525","收款銀行名稱包含非允許字元"),
	VALIDATE_FX_PAYEE_ERROR_12("0526","收款銀行名稱不可為中文"),
	VALIDATE_FX_PAYEE_ERROR_13("0527","收款銀行地址包含非允許字元"),
	VALIDATE_FX_PAYEE_ERROR_14("0528","收款銀行地址不可為中文"),
	VALIDATE_FX_PAYEE_ERROR_15("0529","匯款附言包含非允許字元"),
	VALIDATE_FX_PAYEE_ERROR_16("0530","匯款附言不可為中文"),
	VALIDATE_FX_PAYEE_ERROR_17("0531","匯出匯款方式不得為空白"),
	VALIDATE_FX_PAYEE_ERROR_18("0532","匯出匯款方式錯誤"),
	VALIDATE_FX_PAYEE_ERROR_19("0534","交易金額不得為空白"),
	VALIDATE_FX_PAYEE_ERROR_20("0536","跨行匯款，收款銀行名稱不可為空白"),
	VALIDATE_FX_PAYEE_ERROR_21("0538","收款行國別錯誤"),
	VALIDATE_FX_PAYEE_ERROR_22("0542","匯款性質不可為空白"),
	
	VALIDATE_FX_DETAIL_ERROR_1("0505","收款銀行非RTGS參加行"),
	VALIDATE_FX_DETAIL_ERROR_2("0506","間接匯款為僅當付款人統編為DBU客戶,收款幣別=USD,收款銀行國別=CN"),
	VALIDATE_FX_DETAIL_ERROR_3("0507","自行結匯及幣轉交易，收、付款帳號需屬同ID"),
	VALIDATE_FX_DETAIL_ERROR_4("0508","請輸入CNAPS"),
	VALIDATE_FX_DETAIL_ERROR_5("0509","包含非允許字元"),
	VALIDATE_FX_DETAIL_ERROR_6("0510","資料欄位不可為中文"),
	VALIDATE_FX_DETAIL_ERROR_7("0511","請輸入付款人英文名稱"),
	VALIDATE_FX_DETAIL_ERROR_8("0512","請輸入付款人英文地址"),
	VALIDATE_FX_DETAIL_ERROR_9("0513","請輸入收款人戶名"),
	VALIDATE_FX_DETAIL_ERROR_10("0514","請輸入收款銀行名稱"),
	VALIDATE_FX_DETAIL_ERROR_11("0515","請輸入匯出匯款方式"),
	VALIDATE_FX_DETAIL_ERROR_12("0535","交易幣別為台幣或日幣，交易金額須為正整數"),
	VALIDATE_FX_DETAIL_ERROR_13("0537","CNAPS不得為空白"),
	VALIDATE_FX_DETAIL_ERROR_14("0540","匯款性質格式錯誤"),
	VALIDATE_FX_DETAIL_ERROR_15("0545","匯款性質錯誤"),
	VALIDATE_FX_DETAIL_ERROR_16("0546","請選擇匯款性質"),
	VALIDATE_FX_DETAIL_ERROR_17("0547","請選擇分類細項"),
	VALIDATE_FX_DETAIL_ERROR_18("0548","議價編號已逾期"),
	VALIDATE_FX_DETAIL_ERROR_19("0549","今日匯利率尚未掛牌，請稍後再試"),
	
	// 證券專區
	SEC_AGENT_ERROR_1("1201","非證券公司無權限使用此項功能"),
	SEC_AGENT_ERROR_2("1202","券商代號錯誤"),
	SEC_AGENT_ERROR_3("1203", "轉帳日期已過，請刪除本案件！"),
	SEC_AGENT_ERROR_4("1204", "輸入資料有誤！"),
	SEC_AGENT_ERROR_5("1219", "最後放行主管最早須於轉帳日前一營業日才可以放行！"),
	
	// VB52 Servlet Query
	
	VB52_SERVLET_QUERY_ERROR_1("1205", "uid 參數錯誤"),
	VB52_SERVLET_QUERY_ERROR_2("1206", "accountNo 參數錯誤"),
	VB52_SERVLET_QUERY_ERROR_3("1207", "sDate 參數錯誤"),
	VB52_SERVLET_QUERY_ERROR_4("1208", "eDate 參數錯誤"),
	VB52_SERVLET_QUERY_ERROR_5("1209", "password 參數錯誤"),
	VB52_SERVLET_QUERY_ERROR_6("1210", "密碼不正確"),
	VB52_SERVLET_QUERY_ERROR_7("1211", "uid 或 password 參數錯誤"),
	VB52_SERVLET_QUERY_ERROR_9("1213", "網路位址不正確"),
	VB52_SERVLET_QUERY_ERROR_10("1214", "日期格式錯誤"),
	
	//期貨入金
	TBX_FU2_ERROR_1("1215","不可查詢非本戶之入金資料"),
	TBX_FU2_ERROR_2("1216","期貨商統編格式有誤"),
	TBX_FU2_ERROR_3("1217","虛擬帳號有誤"),
	TBX_FU2_ERROR_4("1218","非期貨專戶帳號"),
	
	VALIDATE_AR_ERROR_1("2013", "查無買方資料"),
	
	VALIDATE_LOAN_ERROR_1("2014", "查無貸款帳號"),
	VALIDATE_LOAN_ERROR_2("2015", "EI12違約不可輸入預定清償本金"),
	VALIDATE_LOAN_ERROR_3("2016", "提前還本數與預計還本數不等"),
	
	VALIDATE_ACHSIZE_ERROR("5047", "匯入總筆數不可超過10000筆"),
	VALIDATE_ACH_ERROR_1("5048", "交易日期須大於或等於系統日"),
	VALIDATE_ACH_ERROR_2("5049", "處理日期已過，請重新輸入下個營業日為處理日期"),
	VALIDATE_ACH_ERROR_3("5050", "交易序號重複"),
	VALIDATE_ACH_ERROR_4("5051", "欄位格式不符"),
	VALIDATE_ACH_ERROR_5("5052", "交易日期與輸入日期不一致,請修改交易日期"),
	VALIDATE_ACH_ERROR_6("5057", "發動者統一編號不符"),
	FILE_UPLOAD_ERROR("3010", "檔案上傳錯誤"),
	FILE_BACKUP_ERROR("3012", "檔案備份錯誤"),
	FILE_DOWNLOAD_ERROR("3009", "檔案下傳錯誤"),
	UNKNOWN_EXCEPTION("9999", "NB unknown exception");

	/** 錯誤代碼 */
	private String errorCode;

	/** 備註說明 */
	private String memo;

	CibErrorCode(String errorCode, String memo) {
		this.errorCode = errorCode;
		this.memo = memo;
	}

	/**
	 * 取得系統代碼
	 * 
	 * @return
	 */
	public String getSystemId() {
		return CosmosSystemId.PB.getSystemId();
	}

	/**
	 * 取得 錯誤代碼
	 * 
	 * @return
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * 取得備註說明
	 * 
	 * @return
	 */
	public String getMemo() {
		return memo;
	}
	
	public static CibErrorCode getErrorCode(String systemId, String errorCode) {
		String value1 = systemId + ":" + errorCode;
		for(CibErrorCode code: values()) {
			
			
			String value2 = code.getSystemId() + ":" + code.getErrorCode();
			
			if(StringUtils.equalsIgnoreCase(value1, value2)) {
				return code;
			}
		}
		return null;
	}
}

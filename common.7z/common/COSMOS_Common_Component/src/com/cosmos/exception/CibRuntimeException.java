/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.exception;


/**
 * <p>網銀Runtime Exception</p>
 *
 * @author  jeff
 * @version 1.0, 2011/3/18
 * @see	    
 * @since 
 */
@SuppressWarnings("serial")
public class CibRuntimeException extends RuntimeException {

	public CibRuntimeException(String message) {
		super(message);
	}
	
	public CibRuntimeException(String message, Throwable cause) {
		
		super(message, cause);
	}

}



 
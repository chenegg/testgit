/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.convert.exception;

import com.cosmos.code.CibErrorCode;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.id.CommonStatus;
import com.ibm.tw.commons.id.ICommonCode;


/**
 * <p>轉碼異常物件</p>
 *
 * @author  jeff
 * @version 1.0, 2011/7/27
 * @see	    
 * @since 
 */
@SuppressWarnings("serial")
public class ConvertException extends ActionException {

	public ConvertException(CibErrorCode error) {
		super(error.getSystemId(), error.getErrorCode(), ICommonCode.SEVERITY_ERROR, error.getMemo());
	}
	
	public ConvertException(String msg, CibErrorCode error) {
		super(msg, error.getSystemId(), error.getErrorCode(), ICommonCode.SEVERITY_ERROR, error.getMemo());
	}
	
	public ConvertException(CibErrorCode error, Throwable cause) {
		super(error.getSystemId(), error.getErrorCode(), ICommonCode.SEVERITY_ERROR, error.getMemo(), cause);
	}
	
	public ConvertException(String msg, CibErrorCode error, Throwable cause) {
		super(error.getSystemId(), error.getErrorCode(), ICommonCode.SEVERITY_ERROR, error.getMemo() + ": " + msg, cause);
	}
	
	
	public ConvertException(String systemId, String statusCode, String severity, String statusDesc) {
		super(systemId, statusCode, severity, statusDesc);
		
	}
	
	public ConvertException(String systemId, String statusCode, String severity, String statusDesc, Throwable cause) {
		super(systemId, statusCode, severity, statusDesc, cause);
		
	}
	 
	public ConvertException(CommonStatus status) {
		super(status);
	}
	
	public ConvertException(CommonStatus status, Throwable cause) {
		super(status, cause);
	}
	
	public ConvertException(String msg, CommonStatus status) {
		super(msg, status);
	}
	
	public ConvertException(String msg, CommonStatus status, Throwable cause) {
		super(msg, status, cause);
	}
}



 
/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.convert.type;


/**
 * <p>創泰轉碼參數</p>
 *
 * @author  jeff
 * @version 1.0, 2011/7/27
 * @see	    
 * @since 
 */
public enum ConvertType {
	
 
	
	HOST_TO_UTF8("HosttoUTF8", "data 全部視為中文,且0e/0f 會Ignore"),
	
	HOST_TO_BIG5("HosttoBig5", "data 全部視為中文,且0e/0f 會Ignore"),
	
	HOST_TO_UTF8_MIX("HosttoUTF8Mix", "中英文混合(0e 0f 內的data 才視為中文,其餘為英文)"),
	
	HOST_TO_BIG5_MIX("HosttoBig5Mix", "中英文混合(0e 0f 內的data 才視為中文,其餘為英文)"),
	
	UTF8_TO_HOST("UTF8toHost", "中英文混合(中文到主機自動產生0e 0f)"),
	
	BIG5_TO_HOST("Big5toHost", "中英文混合(中文到主機自動產生0e 0f)"),
	
	UNKNOWN("", "");
	
	
	/** 轉碼參數 */
	private String code = "";
	
	/** 備註 */
	private String memo = "";
	
	ConvertType(String code, String memo) {
		
		this.code = code;
		this.memo = memo;
	}

	/**
	 * 取得轉碼參數 
	 * @return  
	 */
	public String getCode() {
		return code;
	}

	/**
	 * 設定轉碼參數 
	 * @param code  
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 取得備註
	 * @return 
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * 設定備註
	 * @param memo  
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

	
	
}



 
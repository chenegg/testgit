/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.convert;

import java.net.URL;

import com.cosmos.code.CibErrorCode;
import com.cosmos.convert.exception.ConvertException;
import com.cosmos.convert.type.ConvertType;
import com.cosmos.ebank.util.AESUtils;
import com.ibm.tw.commons.util.ClassLoaderException;
import com.ibm.tw.commons.util.ClassLoaderHelper;
import com.ibm.tw.commons.util.ConvertUtils;

import ciben.data.converter.Converter;

/**
 * <p>
 * 萬 泰轉碼程式
 * </p>
 *
 * 使用創泰的轉碼程式及轉碼表
 * 
 * @author jeff
 * @version 1.0, 2011/7/27
 * @see
 * @since
 */
public class CosmosConvertUtils {

	/** 轉碼表明稱 */
	public final static String CONVERT_TABLE_NAME = "UserUnicode.txt";

	/**
	 * <p>
	 * UTF8 -> CICS 主碼
	 * </p>
	 * 
	 * 中英文混合(中文到主機自動產生0e 0f)
	 * 
	 * @param inData
	 * @return
	 * @throws ConvertException
	 */
	public static byte[] utf8ToHost(byte[] inData) throws ConvertException {

		if (null == inData || inData.length <= 0) {
			return new byte[0];
		}

		String fileName = getConvertTableFileName();

		Converter convert = new Converter();
		convert.setExTableFileName(fileName);
		byte[] result = null;
		try {
			result = convert.convert(ConvertType.UTF8_TO_HOST.getCode(), inData);
		} catch (Exception e) {
			throw new ConvertException("轉碼失敗(UTF8 -> CICS 主碼), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION, e);
		}

		if (null == result) {
			throw new ConvertException("轉碼失敗(UTF8 -> CICS 主碼), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION);

		}

		return result;
	}

	/**
	 * <p>
	 * CICS 主碼 -> UTF8
	 * </p>
	 * 
	 * data 全部視為中文,且0e/0f 會Ignore
	 * 
	 * @param inData
	 * @return
	 * @throws ConvertException
	 */
	public static byte[] hostToUtf8(byte[] inData) throws ConvertException {

		if (null == inData || inData.length <= 0) {
			return new byte[0];
		}

		String fileName = getConvertTableFileName();

		Converter convert = new Converter();
		convert.setExTableFileName(fileName);
		byte[] result = null;
		try {
			result = convert.convert(ConvertType.HOST_TO_UTF8.getCode(), inData);
		} catch (Exception e) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> UTF8), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION, e);
		}

		if (null == result) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> UTF8), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION);

		}

		return result;
	}

	/**
	 * <p>
	 * CICS 主碼 -> UTF8
	 * </p>
	 * 
	 * 中英文混合(0e 0f 內的data 才視為中文,其餘為英文)
	 * 
	 * @param inData
	 * @return
	 * @throws ConvertException
	 */
	public static byte[] hostToUtf8Mix(byte[] inData) throws ConvertException {

		if (null == inData || inData.length <= 0) {
			return new byte[0];
		}

		String fileName = getConvertTableFileName();

		Converter convert = new Converter();
		convert.setExTableFileName(fileName);
		byte[] result = null;
		try {
			result = convert.convert(ConvertType.HOST_TO_UTF8_MIX.getCode(), inData);
		} catch (Exception e) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> UTF8), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION, e);
		}

		if (null == result) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> UTF8), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION);

		}

		return result;
	}

	/**
	 * <p>
	 * Big5 -> CICS 主碼
	 * </p>
	 * 
	 * 中英文混合(中文到主機自動產生0e 0f)
	 * 
	 * @param inData
	 * @return
	 * @throws ConvertException
	 */
	public static byte[] big5ToHost(byte[] inData) throws ConvertException {

		if (null == inData || inData.length <= 0) {
			return new byte[0];
		}

		String fileName = getConvertTableFileName();

		Converter convert = new Converter();
		convert.setExTableFileName(fileName);
		byte[] result = null;
		try {
			result = convert.convert(ConvertType.BIG5_TO_HOST.getCode(), inData);
		} catch (Exception e) {
			throw new ConvertException("轉碼失敗(Big5 -> CICS 主碼), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION, e);
		}

		if (null == result) {
			throw new ConvertException("轉碼失敗(Big5 -> CICS 主碼), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION);

		}

		return result;
	}

	/**
	 * <p>
	 * CICS 主機碼 -> Big5
	 * </p>
	 * 
	 * data 全部視為中文,且0e/0f 會Ignore
	 * 
	 * @param inData
	 * @return
	 * @throws ConvertException
	 */
	public static byte[] hostToBig5(byte[] inData) throws ConvertException {

		if (null == inData || inData.length <= 0) {
			return new byte[0];
		}

		String fileName = getConvertTableFileName();

		Converter convert = new Converter();
		convert.setExTableFileName(fileName);
		byte[] result = null;
		try {
			result = convert.convert(ConvertType.HOST_TO_BIG5.getCode(), inData);
		} catch (Exception e) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> Big5), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION, e);
		}

		if (null == result) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> Big5), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION);

		}

		return result;
	}

	/**
	 * <p>
	 * CICS 主機碼 -> Big5
	 * </p>
	 * 
	 * 中英文混合(0e 0f 內的data 才視為中文,其餘為英文)
	 * 
	 * @param inData
	 * @return
	 * @throws ConvertException
	 */
	public static byte[] hostToBig5Mix(byte[] inData) throws ConvertException {

		if (null == inData || inData.length <= 0) {
			return new byte[0];
		}

		String fileName = getConvertTableFileName();

		Converter convert = new Converter();
		convert.setExTableFileName(fileName);
		byte[] result = null;
		try {
			result = convert.convert(ConvertType.HOST_TO_BIG5.getCode(), inData);
		} catch (Exception e) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> Big5), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION, e);
		}

		if (null == result) {
			throw new ConvertException("轉碼失敗(CICS 主碼 -> Big5), data = " + ConvertUtils.byteArray2HexString(inData),
					CibErrorCode.CONVERT_EXCEPTION);

		}

		return result;
	}

	/**
	 * 取得轉碼表檔名（Full Path）
	 * 
	 * @return
	 * @throws ConvertException
	 */
	private static String getConvertTableFileName() throws ConvertException {

		String fileName = "";
		try {
			URL url = ClassLoaderHelper.getResource(CONVERT_TABLE_NAME);

			fileName = url.getFile();

		} catch (ClassLoaderException e) {
			throw new ConvertException("無法取得轉碼表檔名:" + CONVERT_TABLE_NAME, CibErrorCode.CONVERT_TABLE_NOT_FOUND, e);
		}

		return fileName;
	}

	public static void main(String[] args) {
		AESUtils.encrypt("abcdewgaqreg#%TQ$^$Q");
		// - AESKEY=^0b5f9k=oAsFJ N!R%W)[._2d6h:l?p
		String hexStr = "e3c5c2d3f0e2c1f24040e5c2f0f34040404040f9f9c9c5e5c2f6f6f9f9f9f9f2f3f2f9f0f6f9f94040f0f3f9f1f1f8f0f0f2f3f0f14040009f0ad163080606f0f0f6f0f0f3f9f9f9f9f8f7f6f5f0f0f0f2f1f5404040f0f0f0f0f0f0f0f0f0f9f9f0f1f7f0f1f0f7f1f10e58c1525240404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040400f0e4040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040400f0e4040404040400ff2f0f1f1f0f7f2f7f0f0f1f0f0f0f0f0f0f9f2f0f2f0f0f0f0f9f4f0f0f6";

		try {

			byte[] hostData = ConvertUtils.hexString2ByteArray(hexStr);

			byte[] utf8Data = CosmosConvertUtils.hostToUtf8Mix(hostData);

			String result = ConvertUtils.bytes2Str(utf8Data, "UTF8");

			System.out.println("utf8 = " + result);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

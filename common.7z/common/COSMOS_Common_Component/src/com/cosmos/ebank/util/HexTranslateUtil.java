package com.cosmos.ebank.util;

import java.util.ArrayList;
import java.util.List;

public class HexTranslateUtil {

	private static char[] bio = { 'A', 'B', 'C', 'D', 'E', 'F' };

	public static int hexStrToInteger(String value) {
		int ret = 0;

		int length = value.length();
		for (int i = 0; i < value.length(); i++) {
			char tok = value.charAt(i);
			ret += (int) Math.pow(16, length - 1) * transVal(tok);
			length--;
		}

		return ret;
	}

	private static int transVal(char input) {
		for (int i = 0; i < bio.length; i++) {
			if (input == bio[i]) {
				return (10 + i);
			}
		}

		return Integer.parseInt(String.valueOf(input));

	}

	public static String integerToStr(int value) {
		int myVal = value;
		List<String> list = new ArrayList<String>();
		do {
			int resut_ = myVal % 16;
			if (resut_ > 9) {
				list.add(String.valueOf(bio[resut_ - 10]));
			} else {
				list.add(String.valueOf(resut_));
			}

			myVal = myVal / 16;
		} while (myVal > 0);

		StringBuffer sb = new StringBuffer();
		for (int i = list.size() - 1; i >= 0; i--) {
			sb.append(list.get(i));
		}

		return sb.toString();
	}

}

package com.cosmos.ebank.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

public class SerialGenerator {

	/**
	 * 系統別(2碼)+ID左靠右補0(11碼)+YYMMDDHHMMSS(12碼)+流水號(3碼)+重送次數(1碼)+交易別(0一搬交易;9:沖正交易)(1碼)
	 * @param id
	 * @return
	 */
	public synchronized static String generateTransactionSerialNumber(String id) {
		String returnValue = "";
		StringBuffer stringBuffer = new StringBuffer("NB");
		stringBuffer.append(StringUtils.rightPad(id, 11, '0'));
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyMMddHHmmssSSS");
		stringBuffer.append(simpleDateFormat.format(new Date()));
		stringBuffer.append("00");
		returnValue = stringBuffer.toString();
		return returnValue;
	}

	// not in use yet
	public synchronized static String generateTransactionSerialNumber4COBU(String id) {
		String returnValue = "";
		// to-do COBU
		StringBuffer stringBuffer = new StringBuffer("NB");
		stringBuffer.append(id + "00");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyMMddHHmmssSSS");
		stringBuffer.append(simpleDateFormat.format(new Date()));
		stringBuffer.append("00");
		returnValue = stringBuffer.toString();
		return returnValue;
	}

	public synchronized static String generateNetMessageSequenceNumber() {
		String returnValue = "";
		StringBuffer stringBuffer = new StringBuffer("");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		stringBuffer.append(simpleDateFormat.format(new Date()));
		stringBuffer.append("011");
		simpleDateFormat = new SimpleDateFormat("HHmmssSSS");
		stringBuffer.append("0" + simpleDateFormat.format(new Date()));
		stringBuffer.append("000");
		returnValue = stringBuffer.toString();
		return returnValue;
	}

	public static Map parseTelecode(ArrayList<ComplexItem> fieldList, String codeText) {
		Map fieldMap = new HashMap();
		int index = 0;
		for (int i = 0; i < fieldList.size(); i++) {
			ComplexItem fieldComplexItem = fieldList.get(i);
			int fieldLength = (Integer) fieldComplexItem.getAttachObject();
			String fieldName = (String) fieldComplexItem.getItem();
			fieldMap.put(fieldName, codeText.substring(index, index + fieldLength));
			index += fieldLength;
		}
		return fieldMap;
	}

	// public static void main(String[] args) {
	//
	// SerialGenerator serialGenerator = new SerialGenerator();
	// System.out.println("generateTransactionSerialNumber : "
	// + serialGenerator.generateTransactionSerialNumber("A123456789"));
	// System.out.println("generateNetMessageSequenceNumber : " +
	// serialGenerator.generateNetMessageSequenceNumber());
	// String encryptPassword = Utility.getEncryptPassword("ao",
	// "www.cosmos.com.tw/ebank");
	// System.out.println("encryptPassword : " + encryptPassword);
	// String codeText = "0001AMC FUND              1009999999991";
	// ArrayList<ComplexItem> fieldList = new ArrayList<ComplexItem>();
	// fieldList.add(new ComplexItem("fund code", 4));
	// fieldList.add(new ComplexItem("fund name", 22));
	// fieldList.add(new ComplexItem("flag", 1));
	// fieldList.add(new ComplexItem("total", 12));
	//
	// Map fieldMap = parseTelecode(fieldList, codeText);
	//
	// System.out.println(fieldMap);
	// }

}

package com.cosmos.ebank.util;

import java.io.Serializable;

public class ComplexItem implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5466147490244146732L;

	private Object item;

	private Object attachObject;

	public Object getItem() {
		return item;
	}

	public void setItem(Object item) {
		this.item = item;
	}

	public Object getAttachObject() {
		return attachObject;
	}

	public void setAttachObject(Object attachObject) {
		this.attachObject = attachObject;
	}

	public ComplexItem(Object item, Object attachObject) {
		this.item = item;
		this.attachObject = attachObject;
	}

}

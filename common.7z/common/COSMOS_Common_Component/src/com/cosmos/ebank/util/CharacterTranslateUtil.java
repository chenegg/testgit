package com.cosmos.ebank.util;

import java.io.BufferedReader;
import java.io.CharArrayReader;

import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.text.MessageFormat;
import org.apache.commons.lang3.StringUtils;

public class CharacterTranslateUtil {

	private static Properties properties = new java.util.Properties();
	static {

		InputStream input = CharacterTranslateUtil.class.getClassLoader().getResourceAsStream(
				"fonts/Big5-Unicode.properties");
		try {
			properties.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 驗證 造字區
	 * @param bb
	 * @return
	 */
	private static boolean isMakeWord(int balHigh, int balLow) {

		if (balHigh >= 0xFA && balHigh <= 0xFE && balLow >= 0x40 && balLow <= 0xFE) {
			return true;
		}
		if (balHigh >= 0x8E && balHigh <= 0xA0 && balLow >= 0x40 && balLow <= 0xFE) {
			return true;
		}
		if (balHigh >= 0x81 && balHigh <= 0x8D && balLow >= 0x40 && balLow <= 0xFE) {
			return true;
		}

		return false;
	}

	/**
	 * 
	 * 將Big5 轉為 utf-8
	 * 將難字˙轉換對應 utf-8 code
	 * @param value
	 * @return
	 */
	public static String doTranslate(String value) {

		if (StringUtils.isBlank(value)) {
			return "";

		} else {
			value = value.trim();
			try {

				char[] valueChars = value.toCharArray();

				int idx = 0;
				List<Character> listChar = new ArrayList<Character>();
				List<String> values = new ArrayList<String>();
				String makeWordLog = "";
				for (char bb : valueChars) {

					byte[] valueChar_ = (String.valueOf(bb)).getBytes();
					if (valueChar_.length > 1) {
						int balHigh = valueChar_[0] & 0xFF;
						int balLow = valueChar_[1] & 0xFF;

						if (isMakeWord(balHigh, balLow)) {
							String wordKey_ = HexTranslateUtil.integerToStr(balHigh * 256 + balLow);
							String word_ = properties.getProperty(wordKey_);
							System.out.println("wordKey_=" + wordKey_);
							if (StringUtils.isBlank(word_)) {
								word_ = "";
							} else {
								makeWordLog += wordKey_ + "=" + word_ + ";";
							}
							values.add(word_);
							listChar.add('{');
							String bala = String.valueOf(idx);
							for (int i = 0; i < bala.length(); i++) {
								listChar.add(bala.charAt(i));
							}
							listChar.add('}');
							idx++;
						} else {
							listChar.add(bb);
						}

					} else {
						listChar.add(bb);
					}
				}
				if (StringUtils.isNotBlank(makeWordLog)) {
					System.out.println("makeWordLog=" + makeWordLog);
				}
				Object[] charry = listChar.toArray();
				char[] filtvalueChars = new char[charry.length];
				for (int i = 0; i < charry.length; i++) {
					filtvalueChars[i] = (Character) charry[i];
				}

				CharArrayReader cr = new CharArrayReader(filtvalueChars);

				BufferedReader br = new BufferedReader(cr);

				String myVal_ = br.readLine();

				MessageFormat format = new MessageFormat(myVal_);
				// pw.write(myVal_);
				String retVal = format.format(values.toArray());
				// pw.close();

				return retVal;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return value;
	}

}

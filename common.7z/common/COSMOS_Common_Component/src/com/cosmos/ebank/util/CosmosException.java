package com.cosmos.ebank.util;

public class CosmosException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8082210895703902007L;
	public static String FALSE_MESSAGE = "很抱歉!! 目前系統此功能無法提供服務 ,請洽服務人員或稍後再試!!";
	private String customErrorMessage;
	private Exception sourceException;
	private Object returnObject;
	private boolean useFalseMessage;

	public CosmosException(String customErrorMessage, Exception sourceException) {
		this.customErrorMessage = customErrorMessage;
		this.sourceException = sourceException;
	}

	public String getCustomErrorMessage() {
		return customErrorMessage;
	}

	public void setCustomErrorMessage(String customErrorMessage) {
		this.customErrorMessage = customErrorMessage;
	}

	public Exception getSourceException() {
		return sourceException;
	}

	public void setSourceException(Exception sourceException) {
		this.sourceException = sourceException;
	}

	public Object getReturnObject() {
		return returnObject;
	}

	public void setReturnObject(Object returnObject) {
		this.returnObject = returnObject;
	}

	public boolean isUseFalseMessage() {
		return useFalseMessage;
	}

	public void setUseFalseMessage(boolean useFalseMessage) {
		this.useFalseMessage = useFalseMessage;
	}
}

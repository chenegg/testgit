/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2012.
 *
 * ===========================================================================
 */
package com.cosmos.ebank.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.compress.utils.IOUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.util.ConvertUtils;

/**
 * <p>
 * AES 加解密 defalut mod is AES/ECB/PKCS5Padding
 * </p>
 * 
 * @author Hank
 * @version $Id: AESUtils.java 1883 2015-07-30 07:17:13Z bear $
 * @see
 * @since
 */
public class AESUtils {

	private static Logger logger = LoggerFactory.getLogger(AESUtils.class);

	private static String AESKEY = "";
	private static final String ENCODING = "UTF-8";

	static {
		Security.addProvider(new BouncyCastleProvider());
		InputStream in = AESUtils.class.getClassLoader().getResourceAsStream("META-INF/property/aesSSO.key");
		// InputStream in =
		// AESUtils.class.getClassLoader().getResourceAsStream("property/aesSSO.key");
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		try {
			IOUtils.copy(in, bout);
			AESKEY = new String(bout.toByteArray());
			AESKEY = AESKEY.trim();
			logger.info("AESKEY=" + AESKEY);
		} catch (IOException e) {
			// e.printStackTrace();
			logger.error(e.getMessage(), e);
		}

	}

	/**
	 * "AES" AES/CBC/NoPadding (128) AES/CBC/PKCS5Padding (128) AES/ECB/NoPadding
	 * (128) AES/ECB/PKCS5Padding (128)
	 * 
	 */
	private static final String AES_TYPE = "AES/ECB/PKCS5Padding";

	/**  */
	private static Pattern m_aPattern = Pattern.compile("~[a-fA-F0-9]*~");

	/**
	 * 
	 * @param msg
	 * @return
	 * @throws CryptException
	 * @throws NoSuchAlgorithmException
	 */
	public static String encrypt(String msg) {

		String result = "";

		try {
			// 1. md5
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] array = md.digest(msg.getBytes());
			String md5Result = parseByte(array);
			logger.info("encode step 1 " + md5Result);
			// 2. aes encode
			byte[] msgs = md5Result.getBytes();
			byte[] encode_ = AESUtils.encrypt(msgs, AESKEY);

			logger.info("encode step 2 " + new String(encode_));
			// 3. Base64
			// BASE64Encoder ba64encoder = new BASE64Encoder();
			// logger.info("encode step 3 " + new String(ba64encoder.encode(encode_)));
			logger.info("encode step 3-1 " + new String(Base64.encodeBase64(encode_)));

			result = new String(Base64.encodeBase64(encode_));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * 
	 * TODO modify By cch
	 * 
	 * @param msg
	 * @return
	 * @throws CryptException
	 */
	public static byte[] encrypt(byte[] msg, String password) throws CryptException {

		try {
			byte[] pwdArr = password.getBytes();
			SecretKeySpec spec = new SecretKeySpec(pwdArr, "AES");
			Cipher cipher = Cipher.getInstance(AES_TYPE);
			cipher.init(Cipher.ENCRYPT_MODE, spec);

			return cipher.doFinal(msg);
		} catch (Exception e) {
			throw new CryptException("encrypt failure", e);
		}
	}

	/**
	 * modify by cch
	 * 
	 * @param msg
	 * @return
	 * @throws CryptException
	 */
	public static byte[] decrypt(byte[] msg, String password) throws CryptException {

		try {
			byte[] pwdArr = password.getBytes();
			SecretKeySpec spec = new SecretKeySpec(pwdArr, "AES");
			Cipher cipher = Cipher.getInstance(AES_TYPE);
			cipher.init(Cipher.DECRYPT_MODE, spec);

			return cipher.doFinal(msg);
		} catch (Exception e) {
			throw new CryptException("decrypt failure", e);
		}

	}

	/**
	 * 是否為加入識別字的DES加密資料
	 * 
	 * @param hexString
	 */
	public static boolean isMaskEncrypt(String sHexString) {
		return m_aPattern.matcher(sHexString).matches();
	}

	/**
	 * 取得 去除識別字 資料加密
	 * 
	 * @param makeHexString
	 * @return
	 */
	public static String getEncrypt(String sMaskHexString) {
		return sMaskHexString.replaceAll("~", "");
	}

	/**
	 * 產生AES 128 Key
	 * 
	 * @return
	 */
	protected static byte[] generateAES128Key() {
		SecureRandom sr = new SecureRandom();

		byte[] key = new byte[16];

		sr.nextBytes(key);

		return key;
	}

	private static String parseByte(byte[] array) {

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < array.length; ++i) {
			sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
		}
		return sb.toString();
	}

	public static void genKey() {

		KeyGenerator keyGen;
		try {
			keyGen = KeyGenerator.getInstance("AES");
			keyGen.init(256); // for example
			SecretKey secretKey = keyGen.generateKey();

			logger.info(new String(secretKey.getEncoded()));

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getEncryptPassword(String password, String key) {
		String encryptPassword = null;
		try {
			String algorithm = "DESede";
			KeyGenerator kgen = KeyGenerator.getInstance(algorithm);
			kgen.init(new SecureRandom(key.getBytes()));
			SecretKey skey = kgen.generateKey();
			byte[] raw = skey.getEncoded();
			SecretKeySpec skeySpec = new SecretKeySpec(raw, algorithm);

			Cipher cipher = Cipher.getInstance(algorithm);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
			byte[] encrypted = cipher.doFinal(password.getBytes());
			BigInteger bigInteger = new BigInteger(encrypted);
			encryptPassword = bigInteger.toString(16);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return encryptPassword;
	}

	public static String getDecryptPassword(String password, String key) {
		String decryptPassword = null;
		try {
			String algorithm = "DESede";
			KeyGenerator kgen = KeyGenerator.getInstance(algorithm);
			kgen.init(new SecureRandom(key.getBytes()));
			SecretKey skey = kgen.generateKey();
			byte[] raw = skey.getEncoded();
			SecretKeySpec skeySpec = new SecretKeySpec(raw, algorithm);
			Cipher cipher = Cipher.getInstance(algorithm);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec);
			BigInteger bigInteger = new BigInteger(password, 16);
			byte[] decrypted = cipher.doFinal(bigInteger.toByteArray());
			decryptPassword = new String(decrypted);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return decryptPassword;
	}

	/**
	 * 加密/解密算法 / 工作模式 / 填充方式 Java 6支持PKCS5Padding填充方式 Bouncy
	 * Castle支持PKCS7Padding填充方式
	 */
	private static final String CIPHER_ALGORITHM = "AES/CBC/PKCS7Padding";
	/**
	 * 密鑰算法
	 */
	private static final String KEY_ALGORITHM = "AES";

	/**
	 * 
	 * @param source
	 * @param key
	 * @param iv
	 * @return
	 * @throws Exception
	 */
	public static String encrypt(String data, String KeyString, String iv) throws Exception {
		// iv = genIv();
		byte[] key = KeyString.getBytes();
		SecretKey skeySpec = new SecretKeySpec(key, KEY_ALGORITHM);
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM, "BC");
		IvParameterSpec ivs = new IvParameterSpec(iv.getBytes("ascii"));
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivs);
		byte[] encrypted = cipher.doFinal(data.replace("\\", "").getBytes(ENCODING));
		return toHexString(encrypted);
	}

	public static String genIv() {
		// 亂數產出 16 bytes 長雜湊值
		String salt = genRandom(16).toUpperCase();

		// Byte to Hex 取前 16 bytes 為向量值
		String iv = toHexString(salt.getBytes()).substring(0, 16);

		return iv;
	}

	private static String genRandom(int length) {
		StringBuilder uid = new StringBuilder();

		SecureRandom rd = new SecureRandom();
		for (int i = 0; i < length; i++) {
			// 產生0-2 3位隨機數
			int type = rd.nextInt(3);
			switch (type) {
			case 0:
				// 0-9的隨機數
				uid.append(rd.nextInt(10));
				break;
			case 1:
				// ASCII在65-90之間隨機大寫
				uid.append((char) (rd.nextInt(25) + 65));
				break;
			case 2:
				// ASCII在97-122隨機小寫
				uid.append((char) (rd.nextInt(25) + 97));
				break;
			default:
				break;
			}
		}
		return uid.toString();
	}

	/**
	 */
	public static String decrypt(String data, String KeyString, String iv) throws Exception {
		byte[] key = KeyString.getBytes();
		SecretKey skeySpec = new SecretKeySpec(key, KEY_ALGORITHM);
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM, "BC");
		IvParameterSpec ivs = new IvParameterSpec(iv.getBytes("ascii"));
		cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivs);
		byte[] sourceBytes = ConvertUtils.hexString2ByteArray(data);
		byte[] decoded = cipher.doFinal(sourceBytes);
		return new String(decoded, ENCODING);
	}

	private static String toHexString(byte[] s) {
		StringBuffer str = new StringBuffer();
		String s1;

		for (int i = 0; i < s.length; i++) {
			int ch = (int) s[i];
			s1 = Integer.toHexString(ch);
			int len = s1.length();
			if (len == 1)
				str.append("0" + s1);
			else if (len == 2)
				str.append(s1);
			else
				str.append(s1.substring(len - 2, len));
		}
		return str.toString().toUpperCase();
	}

}

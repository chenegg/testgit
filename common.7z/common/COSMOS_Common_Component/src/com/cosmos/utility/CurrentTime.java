// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 2010/1/12 下午 04:35:18
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) ansi 
// Source File Name:   CurrentTime.java

package com.cosmos.utility;

import java.util.Calendar;


// Referenced classes of package com.cosmos.utility:
//            StringUtility

public class CurrentTime
{

    public CurrentTime()
    {
        Calendar TimeNow = Calendar.getInstance();
        CurrYear = TimeNow.get(1);
        CurrMonth = TimeNow.get(2) + 1;
        CurrDay = TimeNow.get(5);
        CurrHour = TimeNow.get(11);
        CurrMinute = TimeNow.get(12);
        CurrSec = TimeNow.get(13);
        S_CurrHour = StringUtility.doubleChar_Time(String.valueOf(CurrHour));
        S_CurrMinute = StringUtility.doubleChar_Time(String.valueOf(CurrMinute));
        S_CurrSec = StringUtility.doubleChar_Time(String.valueOf(CurrSec));
    }

    public int YEAR()
    {
        return CurrYear;
    }

    public int MONTH()
    {
        return CurrMonth;
    }

    public int DAY()
    {
        return CurrDay;
    }

    public int HOUR()
    {
        return CurrHour;
    }

    public int MINUTE()
    {
        return CurrMinute;
    }

    public int SECOND()
    {
        return CurrSec;
    }

    public String StringYear()
    {
        return StringUtility.doubleChar_Time(String.valueOf(CurrYear));
    }

    public String StringYear_TW()
    {
        if(StringUtility.doubleChar_Time(String.valueOf(CurrYear - 1911)).length() == 2)
            return "0".concat(String.valueOf(String.valueOf(StringUtility.doubleChar_Time(String.valueOf(CurrYear - 1911)))));
        else
            return StringUtility.doubleChar_Time(String.valueOf(CurrYear - 1911));
    }

    public String StringMonth()
    {
        return StringUtility.doubleChar_Time(String.valueOf(CurrMonth));
    }

    public String StringDay()
    {
        return StringUtility.doubleChar_Time(String.valueOf(CurrDay));
    }

    public String StringHour()
    {
        return S_CurrHour;
    }

    public String StringMinute()
    {
        return S_CurrMinute;
    }

    public String StringSecond()
    {
        return S_CurrSec;
    }

    public String HMS()
    {
        return String.valueOf(String.valueOf((new StringBuffer(String.valueOf(String.valueOf(S_CurrHour)))).append(S_CurrMinute).append(S_CurrSec)));
    }

    int CurrYear;
    int CurrMonth;
    int CurrDay;
    int CurrHour;
    int CurrMinute;
    int CurrSec;
    String S_CurrHour;
    String S_CurrMinute;
    String S_CurrSec;
}
/*
  客服交易系統  修改 properties loading 
*/
package com.cosmos.utility;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.ResourceBundle;

 

public class Utility
{

    public String GetErrorMessage()
    {
        return sErrMsg;
    }

    public String GetCode()
    {
        return sCode;
    }

    public String[] GetAPInfo()
    {
        return aAPInfo;
    }

    public String[] GetTokenInfo()
    {
        return aTokenInfo;
    }

    public String GetLoginURL()
    {
        return LoginURL;
    }

    public String[] GetSeamlessInfo()
    {
        return aSeamlessInfo;
    }

    public String GetDepID()
    {
        return DepID;
    }

    public static String getValue(String key, String bundle_name){
    	
        //final String BUNDLE_NAME = "property.email_addr""property.email_addr";
        final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(bundle_name);

    	try{
              return RESOURCE_BUNDLE.getString(key);

        }catch(Exception ex){
        	ex.printStackTrace();
            return "";
        }

  }
    
    
    private Properties settingProperties;
    public Utility(){
    	//WSSOConf.ini 
		settingProperties = new Properties();
		try {
			settingProperties.load(Utility.class.getClassLoader().getResourceAsStream("property/WSSOConf.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    public Utility(String filename)
    {
    	this();//call default constructor
//        filename = null;
        sErrMsg = "";
        aAPInfo = null;
        aTokenInfo = null;
        LoginURL = null;
        aSeamlessInfo = null;
        sCode = null;
        DepID = null;
        //filename = s;
        this.filename = filename;
    }
    

    public String URLGet(String s)
    {
        try
        {
            HttpURLConnection httpurlconnection = (HttpURLConnection)(new URL(s)).openConnection();
            httpurlconnection.setRequestMethod("GET");
            httpurlconnection.setDefaultUseCaches(false);
            httpurlconnection.setUseCaches(false);
            DataInputStream datainputstream = new DataInputStream(httpurlconnection.getInputStream());
            byte abyte0[] = new byte[datainputstream.available()];
            int i = datainputstream.read(abyte0, 0, abyte0.length);
            return new String(abyte0, "UTF8");
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return null;
    }

    public String URLPost(String s, String s1)
    {
        try
        {
            HttpURLConnection httpurlconnection = (HttpURLConnection)(new URL(s)).openConnection();
            httpurlconnection.setRequestMethod("POST");
            httpurlconnection.setDefaultUseCaches(false);
            httpurlconnection.setUseCaches(false);
            httpurlconnection.setDoOutput(true);
            DataOutputStream dataoutputstream = new DataOutputStream(httpurlconnection.getOutputStream());
            dataoutputstream.writeBytes(s1);
            dataoutputstream.close();
            DataInputStream datainputstream = new DataInputStream(httpurlconnection.getInputStream());
            byte abyte0[] = new byte[datainputstream.available()];
            int i = datainputstream.read(abyte0, 0, abyte0.length);
            datainputstream.close();
            return new String(abyte0, "UTF8");
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return null;
    }

    public String ReadIniFileOld(String s, String s1)
    {
        try
        {
            Properties properties = new Properties();
            properties.load(new FileInputStream(s));
            String s2 = properties.getProperty(s1);
            return new String(new String(s2.getBytes("ISO8859_1"), "big5"));
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return null;
    }    
    
    public String ReadIniFile(String filename, String key){
        try
        {      	
            String rtnValue = settingProperties.getProperty(key);
            return rtnValue;
        }catch(Exception exception){
            sErrMsg = exception.getMessage();
        }
        return null;
    }

    public int PortalLogin(String s, String s1, String s2, String s3)
    {
        try
        {
            String s4 = URLGet(ReadIniFile(filename, "WSSOportalPwdAuthURL") + "?pszID=" + s + "&pszPWD=" + s1 + "&pszURL=" + s3 + "&pszUserIP=" + s2);
            if(s4 == null)
            {
                sErrMsg = "連線至認證伺服器失敗";
                return 0;
            }
            StringTokenizer stringtokenizer = new StringTokenizer(s4, "&");
            String s5 = stringtokenizer.nextToken();
            sCode = s5.substring(s5.indexOf("=") + 1);
            if(!sCode.equals("300"))
            {
                sErrMsg = ReadIniFile(filename, sCode);
                return 0;
            }
            aTokenInfo = new String[5];
            s5 = stringtokenizer.nextToken();
            aTokenInfo[0] = s5.substring(s5.indexOf("=") + 1);
            s5 = stringtokenizer.nextToken();
            aTokenInfo[1] = s5.substring(s5.indexOf("=") + 1);
            s5 = stringtokenizer.nextToken();
            aTokenInfo[2] = s5.substring(s5.indexOf("=") + 1);
            s5 = stringtokenizer.nextToken();
            aTokenInfo[3] = s5.substring(s5.indexOf("=") + 1);
            s5 = stringtokenizer.nextToken();
            aTokenInfo[4] = s5.substring(s5.indexOf("=") + 1);
            s5 = stringtokenizer.nextToken();
            int i = Integer.parseInt(s5.substring(s5.indexOf("=") + 1));
            aAPInfo = new String[i * 2];
            for(int j = 0; j < aAPInfo.length; j += 2)
            {
                s5 = stringtokenizer.nextToken();
                aAPInfo[j] = s5.substring(0, s5.indexOf("="));
                aAPInfo[j + 1] = s5.substring(s5.indexOf("=") + 1);
            }

            s5 = stringtokenizer.nextToken();
            DepID = s5.substring(s5.indexOf("=") + 1);
            return 1;
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return 0;
    }

    public int APLogin(String s, String s1, String s2, String s3)
    {
        try
        {
            String s4 = URLGet(ReadIniFile(filename, "WSSOPasswordAuthenticationURL") + "?pszID=" + s + "&pszPWD=" + s1 + "&pszURL=" + s3 + "&pszUserIP=" + s2);
            if(s4 == null)
            {
                sErrMsg = "連線至認證伺服器失敗";
                return 0;
            }
            StringTokenizer stringtokenizer = new StringTokenizer(s4, "&");
            String s5 = stringtokenizer.nextToken();
            sCode = s5.substring(s5.indexOf("=") + 1);
            if(!sCode.equals("300"))
            {
                sErrMsg = ReadIniFile(filename, sCode);
                return 0;
            } else
            {
                aTokenInfo = new String[5];
                String s6 = stringtokenizer.nextToken();
                aTokenInfo[0] = s6.substring(s6.indexOf("=") + 1);
                aTokenInfo[0] = aTokenInfo[0].substring(0, aTokenInfo[0].length() - 1);
                s6 = stringtokenizer.nextToken();
                aTokenInfo[1] = s6.substring(s6.indexOf("=") + 1);
                aTokenInfo[1] = aTokenInfo[1].substring(0, aTokenInfo[1].length() - 1);
                s6 = stringtokenizer.nextToken();
                aTokenInfo[2] = s6.substring(s6.indexOf("=") + 1);
                aTokenInfo[2] = aTokenInfo[2].substring(0, aTokenInfo[2].length() - 1);
                s6 = stringtokenizer.nextToken();
                aTokenInfo[3] = s6.substring(s6.indexOf("=") + 1);
                s6 = stringtokenizer.nextToken();
                aTokenInfo[4] = s6.substring(s6.indexOf("=") + 1);
                aTokenInfo[4] = aTokenInfo[4].substring(0, aTokenInfo[4].length() - 1);
                return 1;
            }
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return 0;
    }

    public int URLAuthType(String s)
    {
    	System.out.println("method : URLAuthType");
    	System.out.println("s :"+s);
        try
        {
            String s1 = ReadIniFile(filename, "WSSOURLAuthTypeURL");
            System.out.println("s1 :"+s1);
            String s2 = URLGet(s1 + "?pszURL=" + s);
            System.out.println(s1 + "?pszURL=" + s);
            System.out.println("s2 :"+s2);
            if(s2 == null)
            {
                sErrMsg = "連線至認證伺服器失敗";
                return 0;
            }
            StringTokenizer stringtokenizer = new StringTokenizer(s2, "&");
            String s3 = stringtokenizer.nextToken();
            sCode = s3.substring(s3.indexOf("=") + 1);
            if(!sCode.equals("200") && !sCode.equals("205"))
            {
                sErrMsg = ReadIniFile(filename, sCode);
                return 0;
            } else
            {
                String s4 = stringtokenizer.nextToken();
                String s5 = s4.substring(s4.indexOf("=") + 1);
                LoginURL = ReadIniFile(filename, s5);
                return 1;
            }
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return 0;
    }

    public int VerifyCookies(String s, String s1, String s2, String s3)
    {
        try
        {
            String s4 = ReadIniFile(filename, "WSSOVerifyCookiesURL");
            String s5 = URLGet(s4 + "?pszWSSOToken=" + s + "&pszWSSOID=" + s1 + "&pszUserIP=" + s2 + "&pszURL=" + s3);
            if(s5 == null)
            {
                sErrMsg = "連線至認證伺服器失敗!";
                return 0;
            }
            StringTokenizer stringtokenizer = new StringTokenizer(s5, "&");
            String s6 = stringtokenizer.nextToken();
            sCode = s6.substring(s6.indexOf("=") + 1);
            if(!sCode.equals("100"))
            {
                sErrMsg = ReadIniFile(filename, sCode);
                return 0;
            }
            String s7 = stringtokenizer.nextToken();
            String s8 = stringtokenizer.nextToken();
            if(s7.substring(0, s7.indexOf("=")).equals("seamlessid") && s8.substring(0, s8.indexOf("=")).equals("seamlesspwd"))
            {
                aSeamlessInfo = new String[2];
                aSeamlessInfo[0] = s7.substring(s7.indexOf("=") + 1);
                aSeamlessInfo[1] = s8.substring(s8.indexOf("=") + 1);
            }
            s7 = stringtokenizer.nextToken();
            DepID = s7.substring(s7.indexOf("=") + 1);
            return 1;
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return 0;
    }

    public int RequestFromPortal(String s)
    {
        try
        {
            String s1 = ReadIniFile(filename, "RequestFromPortalURL");
            String s2 = URLGet(s1 + "?pszUserIP=" + s);
            if(s2 == null)
            {
                sErrMsg = "連線至認證伺服器失敗";
                return 2;
            } else
            {
                StringTokenizer stringtokenizer = new StringTokenizer(s2, "&");
                String s3 = stringtokenizer.nextToken();
                return Integer.parseInt(s3.substring(s3.indexOf("=") + 1));
            }
        }
        catch(Exception exception)
        {
            sErrMsg = exception.getMessage();
        }
        return 2;
    }

    String filename;
    String sErrMsg;
    String aAPInfo[];
    String aTokenInfo[];
    String LoginURL;
    String aSeamlessInfo[];
    String sCode;
    String DepID;
}
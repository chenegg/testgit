package com.cosmos.utility;

import com.ibm.tw.commons.util.time.DateUtils;

/**
 *<pre>
 * Author : Jay Young <br>
 * Function :  日期格式轉換  <br>
 *
 * <font size="3" color="red">使用範例</font>
 *
 * (一)日期格式轉換
 *
 * 1. DateUtil.getCYMD("-") --> 90-09-30     //民國曆 年月日
 *
 * 2. DateUtil.getYMD("/")  --> 2001/05/31   //西元曆 年月日
 *
 * 3. DateUtil.getMDY("")   --> 05312001     //西元曆 月日年
 *
 * 4. DateUtil.getDMY("-")  --> 31-05-2001   //西元曆 日月年
 *
 * 5. DateUtil.getTime(":") --> 23:56:28     //時分秒
 *
 * 6. DateUtil.getBeforeDate(-5,"-")  -->  90-09-25     //現在時間的前5 天 民國曆 年月日
 *</pre>
 */

public class DateUtil {

	/**
	 * 轉回該日期之前後幾天的日期
	 * @param date_late:某個日期
	 * @param days:前後幾天,+,-
	 * @return String
	 */
	@Deprecated
	public static String chkDate(String date_late, int days) {
		return DateUtils.chkDate(date_late, days);
	}

	/**
	 * function : 目前時間的民國曆 年月日
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的民國曆 年月日字串
	 */
	@Deprecated
	public static String getCYMD(String separtor) {
		return DateUtils.getCYMD(separtor);
	}

	/**
	 * function : 目前時間的西元曆 年月日
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的西元曆 年月日字串
	 */
	@Deprecated
	public static String getYMD(String separtor) {
		return DateUtils.getYMD(separtor);
	}

	/**
	 * function : 目前時間的西元曆 月日年
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的西元曆 月日年字串
	 */
	@Deprecated
	public static String getMDY(String separtor) {
		return DateUtils.getMDY(separtor);
	}

	/**
	 * function : 目前時間的西元曆 日月年
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的西元曆 日月年字串
	 */
	@Deprecated
	public static String getDMY(String separtor) {
		return DateUtils.getDMY(separtor);
	}

	/**
	 * function : 目前時間的時分秒
	 * @param separtor String , 時分秒的分隔符號 Ex: "-","\",".",":"
	 * @return 目前時間的西元曆 時分秒字串
	 */
	@Deprecated
	public static String getTime(String separtor) {
		return DateUtils.getTime(separtor);
	}

	/**
	 * function : 目前時間的前後X天的日期字串
	 * @param days int, 加減的天數
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 民國曆 年月日字串
	 */
	@Deprecated
	public static String getBeforeDate(int days, String separtor) {
		return DateUtils.getBeforeDate(days, separtor);
	}

	@Deprecated
	public static String getBeforeDate(String base, int days, String separtor) {
		return DateUtils.getBeforeDate(base, days, separtor);
	}

	/**
	 * 日期之加減
	 * @param field, 日期欄位【年 or 月 or 日】
	 * @param amount, 加減之數量
	 * @param date, 欲作加減之日期【YYYMMDD】
	 * @return String
	 */
	@Deprecated
	public static String add(int field, int amount, String date) {
		return DateUtils.add(field, amount, date);
	}

	@Deprecated
	public static String getDate(String date) {
		return DateUtils.getDate(date);
	}

	/**
	 * 取得從date 開始，並加上incMonth月的日期
	 * @param date
	 * @param month
	 * @return
	 */
	@Deprecated
	public static String getDate(String date, int incMonth) {
		return DateUtils.getDate(date, incMonth);
	}

	/**
	 * 輸入差異值(月份)
	 *     功式如下: 系統日期-差異值(月份)
	 *      情況1:今日為(930929) - 7 = 930229, 傳回 [0]=930229 , [1]=930231
	 *      情況2:今日為(920929) - 7 = 930228, 傳回 [0]=920228 , [1]=920231
	 *      情況3:今日為(920930) - 3 = 930630, 傳回 [0]=930630 , [1]=930631
	 * @param diffmonth int 差異值(月份)
	 * @return 傳回差異日期-開始日期[0],結束日期[1]
	 */
	@Deprecated
	public static String[] getDateOnRangeWithMonth(int diffmonth) {
		return DateUtils.getDateOnRangeWithMonth(diffmonth);
	}

	/**
	   * 輸入差異值(天數)
	   *     功式如下: 系統日期-差異值(天數)
	   *      情況1:今日為(930929) - 7 = 930229, 傳回 [0]=930229 , [1]=930231
	   *      情況2:今日為(920929) - 7 = 930228, 傳回 [0]=920228 , [1]=920231
	   *      情況3:今日為(920930) - 3 = 930630, 傳回 [0]=930630 , [1]=930631
	   * @param diffmonth int 差異值(天數)
	   * @return 傳回差異日期-開始日期[0],結束日期[1]
	   */

	@Deprecated
	public static String[] getDateOnRangeWithDay(int diffday) {
		return DateUtils.getDateOnRangeWithDay(diffday);
	}

	/**
	  * function : 求出兩日期的差距天數
	  * @param String first_date
	  * @param String end_date
	  * @return 差距天數 days
	  */

	@Deprecated
	public static int getBetweenDays(String first_date, String end_date) {
		return DateUtils.getBetweenDays(first_date, end_date);
	}

	// 取得每月的最一天的日期，如：940228，940430，940831.....
	public String getrptdate(String year, String month) {
		String day[] = { "31", "", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31" };
		String day2[] = { "28", "29", "28", "28", "28", "29", "28", "28", "28", "29", "28", "28", "28", "29" };
		String rptdate = "";
		if (year.length() < 3) {
			year = "0" + year;

		}
		rptdate = year;
		if (!month.equals("null")) {
			if (month.length() == 1) {
				rptdate += "0" + month;
			} else {
				rptdate += month;

			}
			if (!month.equals("2") && !month.equals("02")) {
				rptdate += day[Integer.parseInt(month) - 1];
			} else {
				rptdate += day2[Integer.parseInt(year) - 92];
			}
		}
		return rptdate;
	}

	// 傳回 年 與 月 的下拉式選單!
	public String[] getYear_Month() {
		DateUtil getYear = new DateUtil();
		String rpt_date = getYear.getCYMD("");
		String rpt_yy = rpt_date.substring(1, 3);
		String rpt_mm = rpt_date.substring(3, 5);
		String year = "<select size='1' name='year'>";
		for (int yy = 91; yy < 110; yy++) {
			year += "<option value='" + yy + "'";
			if (rpt_yy.equals(yy + "")) {
				year += " selected";
			}
			year += ">" + yy + "</option>";
		}
		year += "</select>";

		String month = "<select size='1' name='month'>";
		String m_m = "";
		for (int mm = 1; mm < 13; mm++) {
			m_m = mm > 10 ? mm + "" : "0" + mm;
			month += "<option value='" + m_m + "'";
			if (rpt_mm.equals(m_m)) {
				month += " selected";
			}
			month += ">" + mm + "</option>";
		}
		month += "</select>";
		String[] year_mon = new String[2];
		year_mon[0] = year;
		year_mon[1] = month;
		return year_mon;
	}

}

package com.cosmos.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class passwd {
	private static Logger fundLog = LoggerFactory.getLogger(passwd.class);
	private static java.text.DecimalFormat df = new java.text.DecimalFormat("0000");
	public static String changePasswdPrevious(String thePwd) {
		if (thePwd == null || thePwd.length() != 4)
			return thePwd;
		int p1 = Integer.parseInt(thePwd.substring(0, 1));
		int p2 = Integer.parseInt(thePwd.substring(1, 2));
		int p3 = Integer.parseInt(thePwd.substring(2, 3));
		int p4 = Integer.parseInt(thePwd.substring(3, 4));
		char p[] = new char[4];
		p[0] = (char) ((p1 * 3) % 10 + 0x30);
		p[1] = (char) ((p3 * 9) % 10 + 0x30);
		p[2] = (char) ((p2 * 7) % 10 + 0x30);
		p[3] = (char) ((p4 * 3) % 10 + 0x30);
		return (String.valueOf(p));
	}
	
	private static String changePasswdPrevious1(String str) {
        char c[]=new char[4];
        c[0]=str.charAt(0);
        c[2]=str.charAt(1);
        c[3]=str.charAt(2);
        c[1]=str.charAt(3);
        String s=changePasswdPrevious(String.valueOf(c));
        c[0]=s.charAt(0);
        c[2]=s.charAt(1);
        c[3]=s.charAt(2);
        c[1]=s.charAt(3);
        return String.valueOf(c);    
	}
	
	public static String changePasswd(String thePwd) {
		if(true) return thePwd; //for 基金改成登入就編碼
		if (thePwd == null || thePwd.length() < 4 || thePwd.length() > 8) {
			fundLog.info("長度有誤");
			return thePwd;
		}
		return changePasswdPrevious(thePwd.substring(0, 4)) + changePasswdPrevious1(fillstr(thePwd.substring(4, thePwd.length())));
	}
	public static String changePasswd1(String thePwd) { //for基金登入就call此method
		if (thePwd == null || thePwd.length() < 4 || thePwd.length() > 8) {
			fundLog.info("長度有誤");
			return thePwd;
		}
		return changePasswdPrevious(thePwd.substring(0, 4)) + changePasswdPrevious1(fillstr(thePwd.substring(4, thePwd.length())));
	}	
	public static String change(String str) {
		if (str.length() !=8 ) return str;
		StringBuffer sb=new StringBuffer(str);
		char c = sb.charAt(5);
		sb.setCharAt(5,sb.charAt(6));
		sb.setCharAt(6,c);
		return sb.toString();		
    }	
	private static String fillstr(String str) {
		switch (str.length()) {
			case 0 :
				str += "0";
			case 1 :
				str += "0";
			case 2 :
				str += "0";
			case 3 :
				str += "0";
		}
		return str;
	}
	public static String packPasswd(String s1, String s2, String s3) {
		if (s1 == null || s2 == null || s3 == null || s2.length() != 6 || s3.length() < 4 || s3.length() > 8) {
			fundLog.info("資料有誤");
			return "xxxxxxxxxxxxxxxx";
		}
		
		return "~H" + packPasswdx(s1, s2, s3.substring(0, 4)).substring(0, 8) + packPasswdx(s1, s2, fillstr(s3.substring(4, s3.length()))).substring(0, 8) + "~C";
	}
	public static String packPasswdPrevious(String s1, String s2, String s3) {
		if (s1 == null || s2 == null || s3 == null || s2.length() != 6 || s3.length() < 4 || s3.length() > 8) {
			fundLog.info("資料有誤");
			return "xxxxxxxxxxxxxxxx";
		}
		return "~H" + packPasswdx(s1, s2, s3) + "~C";
	}
	private static String packPasswdx(String s1, String s2, String s3) {
        final int  ebc[] = {
          0x00,0x01,0x02,0x03,0x9C,0x09,0x86,0x7F,0x97,0x8D,0x8E,0x0B,0x0C,0x0D,0x0E,0x0F,
          0x10,0x11,0x12,0x13,0x9D,0x0A,0x08,0x87,0x18,0x19,0x92,0x8F,0x1C,0x1D,0x1E,0x1F,
          0x80,0x81,0x82,0x83,0x84,0x85,0x17,0x1B,0x88,0x89,0x8A,0x8B,0x8C,0x05,0x06,0x07,
          0x90,0x91,0x16,0x93,0x94,0x95,0x96,0x04,0x98,0x99,0x9A,0x9B,0x14,0x15,0x9E,0x1A,
          0x20,0xA1,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,0xA9,0x5B,0x2E,0x3C,0x28,0x2B,0x5D,
          0x26,0xAA,0xAB,0xAC,0xAD,0xAE,0xAF,0x61,0xB0,0x62,0x21,0x24,0x2A,0x29,0x3B,0x5E,
          0x2D,0x2F,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6A,0x7C,0x2C,0x25,0x5F,0x3E,0x3F,
          0x6B,0x6C,0x6D,0x6E,0x6F,0x70,0x71,0x72,0x73,0x60,0x3A,0x23,0x40,0x27,0x3D,0x22,
          0x74,0xB1,0xB2,0xB3,0xB4,0xB5,0xB6,0xB7,0xB8,0xB9,0xBA,0x75,0xBB,0xBC,0xBD,0xBE,
          0xBF,0xC0,0xC1,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0x76,0x77,0xCA,0xCB,0xCC,
          0x78,0x7E,0xCD,0xCE,0xCF,0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0x79,0xD6,0xD7,0xD8,0xD9,
          0x7A,0xA0,0xE0,0xE1,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xDA,0xDB,0xDC,0xDD,0xDE,0xDF,
          0x7B,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0xE8,0xE9,0xEA,0xEB,0xEC,0xED,
          0x7D,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,0x50,0x51,0x52,0xEE,0xEF,0xF0,0xF1,0xF2,0xF3,
          0x5C,0x9F,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5A,0xF4,0xF5,0xF6,0xF7,0xF8,0xF9,
          0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF
        };
		final char tempChar[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
		String str;
		String pin;
		String timePin;
		String tempTime;
		String temp;
		String thes;
		String theStr;
		byte ebcdic[] = new byte[256];
		byte notpack[] = new byte[56];
		byte p1[] = new byte[28];
		byte p2[] = new byte[28];
		byte pack[] = new byte[28];
		byte xor[] = new byte[28];
		byte pass[] = new byte[28];
		int intpass[] = new int[8];
		theStr = "";
		try {
			str = "0000000000" + s1 + "1111111111" + s2 + "0000000000000000";
			pin = "00009999" + s3 + "99990000" + s3 + s3;
			tempTime = s2.substring(4, 6) + s2.substring(2, 4) + s2.substring(0, 2);
			timePin = "0000" + s2 + "00000000" + tempTime + "0000";
			for (int i = 0; i < ebc.length; i++) {
				ebcdic[ebc[i]] = (byte) i;
			}
			for (int i = 0; i < 56; i++)
				notpack[i] = ebcdic[(int) (str.charAt(i))];
			for (int i = 0; i < 28; i++)
				p1[i] = ebcdic[(int) (pin.charAt(i))];
			for (int i = 0; i < 28; i++)
				p2[i] = ebcdic[(int) (timePin.charAt(i))];
			for (int i = 0; i < 28; i++)
				pack[i] = (byte) ((notpack[i * 2] & 0x0f) * 0x10 + (notpack[i * 2 + 1] & 0x0f));
			for (int i = 0; i < 28; i++)
				xor[i] = (byte) (pack[i] ^ p1[i]);
			for (int i = 0; i < 28; i++)
				pass[i] = (byte) (xor[i] ^ p2[i]);
			for (int i = 0; i < 8; i++) {
				if (i < 4)
					intpass[i] = pass[8 + i];
				if (i >= 4)
					intpass[i] = pass[20 + i - 4];
				if (intpass[i] < 0)
					intpass[i] += 0xff + 0x01;
			}
			for (int i = 0; i < 8; i++) {
				try {
					theStr = theStr + tempChar[intpass[i] / 0x10];
					theStr = theStr + tempChar[intpass[i] % 0x10];
				} catch (Exception e) {}
			}
		} catch (StringIndexOutOfBoundsException e) {
			fundLog.info("參數長度有誤，請重新檢查");
			theStr = "xxxxxxxxxxxxxxxx";
		}
		return (theStr);
	}
	public static String Fund_packPasswdPrevious(String s1, String s2, String s3, String s4) {
		return ("~H" + packPasswdFund(s1, s2, s3, s4, "", "", "", "", "") + "~C");
	}
	public static String Fund_packPasswd(String s1, String s2, String s3, String s4) {
		return ("~H" + packPasswdFund(s1, s2.substring(0, 4), s3, s4, "", "", "", "", "").substring(0, 8) + packPasswdFund(s1, fillstr(s2.substring(4, s2.length())), s3, s4, "", "", "", "", "").substring(0, 8) + "~C");
	}
	public static String Fund_packPasswdPrevious(String s1, String s2, String s3, String s4, String s5, String s6, String s7) {
		return ("~H" + packPasswdFund(s1, s2, s3, s4, s5, s6, s7, "", "") + "~C");
	}
	public static String Fund_packPasswd(String s1, String s2, String s3, String s4, String s5, String s6, String s7) {
		return ("~H" + packPasswdFund(s1, s2.substring(0, 4), s3, s4, s5, s6, s7, "", "").substring(0, 8) + packPasswdFund(s1, fillstr(s2.substring(4, s2.length())), s3, s4, s5, s6, s7, "", "").substring(0, 8) + "~C");
	}
	public static String Fund_packPasswdPrevious(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8) {
		return ("~H" + packPasswdFund(s1, s2, s3, s4, s5, s6, s7, s8, "") + "~C");
	}
	public static String Fund_packPasswd(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8) {
		return ("~H" + packPasswdFund(s1, s2.substring(0, 4), s3, s4, s5, s6, s7, s8, "").substring(0, 8) + packPasswdFund(s1, fillstr(s2.substring(4, s2.length())), s3, s4, s5, s6, s7, s8, "").substring(0, 8) + "~C");
	}
	public static String Fund_packPasswdPrevious(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9) {
		return ("~H" + packPasswdFund(s1, s2, s3, s4, s5, s6, s7, s8, s9) + "~C");
	}
	public static String Fund_packPasswd(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9) {
		return ("~H" + packPasswdFund(s1, s2.substring(0, 4), s3, s4, s5, s6, s7, s8, s9).substring(0, 8) + packPasswdFund(s1, fillstr(s2.substring(4, s2.length())), s3, s4, s5, s6, s7, s8, s9).substring(0, 8) + "~C");
	}
	private static String packPasswdFund(String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9) {
        final int  ebc[] = {
          0x00,0x01,0x02,0x03,0x9C,0x09,0x86,0x7F,0x97,0x8D,0x8E,0x0B,0x0C,0x0D,0x0E,0x0F,
          0x10,0x11,0x12,0x13,0x9D,0x0A,0x08,0x87,0x18,0x19,0x92,0x8F,0x1C,0x1D,0x1E,0x1F,
          0x80,0x81,0x82,0x83,0x84,0x85,0x17,0x1B,0x88,0x89,0x8A,0x8B,0x8C,0x05,0x06,0x07,
          0x90,0x91,0x16,0x93,0x94,0x95,0x96,0x04,0x98,0x99,0x9A,0x9B,0x14,0x15,0x9E,0x1A,
          0x20,0xA1,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,0xA9,0x5B,0x2E,0x3C,0x28,0x2B,0x5D,
          0x26,0xAA,0xAB,0xAC,0xAD,0xAE,0xAF,0x61,0xB0,0x62,0x21,0x24,0x2A,0x29,0x3B,0x5E,
          0x2D,0x2F,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6A,0x7C,0x2C,0x25,0x5F,0x3E,0x3F,
          0x6B,0x6C,0x6D,0x6E,0x6F,0x70,0x71,0x72,0x73,0x60,0x3A,0x23,0x40,0x27,0x3D,0x22,
          0x74,0xB1,0xB2,0xB3,0xB4,0xB5,0xB6,0xB7,0xB8,0xB9,0xBA,0x75,0xBB,0xBC,0xBD,0xBE,
          0xBF,0xC0,0xC1,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0x76,0x77,0xCA,0xCB,0xCC,
          0x78,0x7E,0xCD,0xCE,0xCF,0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0x79,0xD6,0xD7,0xD8,0xD9,
          0x7A,0xA0,0xE0,0xE1,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xDA,0xDB,0xDC,0xDD,0xDE,0xDF,
          0x7B,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0xE8,0xE9,0xEA,0xEB,0xEC,0xED,
          0x7D,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,0x50,0x51,0x52,0xEE,0xEF,0xF0,0xF1,0xF2,0xF3,
          0x5C,0x9F,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5A,0xF4,0xF5,0xF6,0xF7,0xF8,0xF9,
          0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF
        };
		final char tempChar[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
		String str;
		String pin;
		String timePin;
		String tempTime;
		String temp;
		String thes;
		String theStr;
		byte ebcdic[] = new byte[256];
		byte notpack[] = new byte[56];
		byte p1[] = new byte[28];
		byte p2[] = new byte[28];
		byte pack[] = new byte[28];
		byte xor[] = new byte[28];
		byte pass[] = new byte[28];
		int intpass[] = new int[8];
		int n = 0;
		if ((s1.equals("VB71")))
			n = 71;
		else if ((s1.equals("VB73")))
			n = 73;
		else if ((s1.equals("V741")))
			n = 741;
		else if ((s1.equals("V742")))
			n = 742;
		else if ((s1.equals("V743")))
			n = 743;
		else if ((s1.equals("V761")))
			n = 761;
		else if ((s1.equals("V762")))
			n = 762;
		else if ((s1.equals("V763")))
			n = 763;
		else if ((s1.equals("VB77")))
			n = 77;
		str = "";
		pin = "";
		timePin = "";
		theStr = "";
		try {
			switch (n) {
				case 71 :
					str = s3.concat("0000").concat("00000000000000").concat("1111111111").concat(s4).concat("0000000000000000");
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s4.substring(4, 6) + s4.substring(2, 4) + s4.substring(0, 2);
					timePin = "0000" + s4 + "00000000" + tempTime + "0000";
					break;
				case 73 :
					str = s3.concat(s4).concat(s5).concat(s6).concat(s7).concat(s8);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s8.substring(4, 6) + s8.substring(2, 4) + s8.substring(0, 2);
					timePin = "0000" + s8 + "00000000" + tempTime + "0000";
					break;
				case 741 :
					str = s3.concat(s4).concat(s5).concat("00000000").concat(s6).concat(s7);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s7.substring(4, 6) + s7.substring(2, 4) + s7.substring(0, 2);
					timePin = "0000" + s7 + "00000000" + tempTime + "0000";
					break;
				case 742 :
					str = s3.concat(s4).concat(s5).concat(s6).concat("00").concat(s7).concat("000").concat(s8);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s8.substring(4, 6) + s8.substring(2, 4) + s8.substring(0, 2);
					timePin = "0000" + s8 + "00000000" + tempTime + "0000";
					break;
				case 743 :
					str = s3.concat(s4).concat(s5).concat("00000000").concat(s6).concat("000").concat(s7);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s7.substring(4, 6) + s7.substring(2, 4) + s7.substring(0, 2);
					timePin = "0000" + s7 + "00000000" + tempTime + "0000";
					break;
				case 761 :
					str = s3.concat(s4).concat(s5).concat("000000").concat(s6).concat(s7).concat(s8);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s8.substring(4, 6) + s8.substring(2, 4) + s8.substring(0, 2);
					timePin = "0000" + s8 + "00000000" + tempTime + "0000";
					break;
				case 762 :
					str = s3.concat(s4).concat(s5).concat(s6).concat("00").concat(s7).concat("000").concat(s8);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s8.substring(4, 6) + s8.substring(2, 4) + s8.substring(0, 2);
					timePin = "0000" + s8 + "00000000" + tempTime + "0000";
					break;
				case 763 :
					str = s3.concat(s4).concat(s5).concat(s6).concat("00").concat(s7).concat("000").concat(s8);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s8.substring(4, 6) + s8.substring(2, 4) + s8.substring(0, 2);
					timePin = "0000" + s8 + "00000000" + tempTime + "0000";
					break;
				case 77 :
					str = s3.concat(s4).concat(s5).concat(s6).concat(s7).concat(s8).concat(s9);
					pin = "00009999" + s2 + "99990000" + s2 + s2;
					tempTime = s9.substring(4, 6) + s9.substring(2, 4) + s9.substring(0, 2);
					timePin = "0000" + s9 + "00000000" + tempTime + "0000";
					break;
			}
			for (int i = 0; i < ebc.length; i++) {
				ebcdic[ebc[i]] = (byte) i;
			}
			for (int i = 0; i < 56; i++)
				notpack[i] = ebcdic[(int) (str.charAt(i))];
			for (int i = 0; i < 28; i++)
				p1[i] = ebcdic[(int) (pin.charAt(i))];
			for (int i = 0; i < 28; i++)
				p2[i] = ebcdic[(int) (timePin.charAt(i))];
			for (int i = 0; i < 28; i++)
				pack[i] = (byte) ((notpack[i * 2] & 0x0f) * 0x10 + (notpack[i * 2 + 1] & 0x0f));
			for (int i = 0; i < 28; i++)
				xor[i] = (byte) (pack[i] ^ p1[i]);
			for (int i = 0; i < 28; i++)
				pass[i] = (byte) (xor[i] ^ p2[i]);
			for (int i = 0; i < 8; i++) {
				if (i < 4)
					intpass[i] = pass[8 + i];
				if (i >= 4)
					intpass[i] = pass[20 + i - 4];
				if (intpass[i] < 0)
					intpass[i] += 0xff + + 0x01;
			}
			for (int i = 0; i < 8; i++) {
				try {
					theStr = theStr + tempChar[intpass[i] / 0x10];
					theStr = theStr + tempChar[intpass[i] % 0x10];
				} catch (Exception e) {}
			}
		} catch (StringIndexOutOfBoundsException e) {
			fundLog.info(s1 + ":參數長度有誤，請重新檢查");
			theStr = "xxxxxxxxxxxxxxxx";
		}
		return (theStr);
	}
}
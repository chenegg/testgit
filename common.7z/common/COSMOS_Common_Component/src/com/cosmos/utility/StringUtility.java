// Decompiled by DJ v2.6.6.51 Copyright 2000 Atanas Neshkov  Date: 2009/4/22 下午 05:07:18
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   StringUtility.java

/**
 * @(#)	1.00, 15/4/2013
 *
 * 功能名稱: deal with special String  
 *
 *modify:
 *   2013/04/15  add 半形轉全形 and mask function, OA203091-1011200684-網路銀行變更個人資訊需求 version 1
 *   
 *   Created by:  Wen
 */

package com.cosmos.utility;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import com.ibm.tw.commons.util.StringUtils;

public class StringUtility {

	private StringUtility() {
	}

	public static String doubleChar_Time(String s) {
		String s1 = s.trim();
		if (s1.length() == 1)
			s1 = "0".concat(String.valueOf(String.valueOf(s1)));
		return s1;
	}

	public static String addSpace(String s, String s1, int i, String s2) {
		int j = 0;
		if (!s2.equals("0"))
			s2 = " ";
		String s3 = "";
		if (!(s.equals("null") | s.equals("")))
			j = s.getBytes().length;
		else
			s = "";
		if (s.length() >= i)
			return s.substring(0, i);
		for (int k = 1; k <= i - j; k++)
			s3 = String.valueOf(s2) + String.valueOf(s3);

		if (s1.equals("left"))
			s3 = String.valueOf(s3) + String.valueOf(s);
		else
			s3 = String.valueOf(s) + String.valueOf(s3);
		return s3;
	}

	public static String parseStrByBig5(String s, int i, int j) {
		String s1 = new String(s.getBytes(), i, j - i);
		return s1;
	}

	public static int electricCode_Big5_length(String s) {
		int i = s.getBytes().length;
		return i;
	}

	public static String[] getAccountList(String s) {
		int i = s.length() / 12;
		String as[] = new String[i];
		for (int j = 0; j < i; j++)
			as[j] = s.substring(12 * j, 12 * (j + 1));

		return as;
	}

	public static String UidChartoNum(String s) {
		String s1 = s.toUpperCase();
		String s2 = s.toUpperCase();
		byte abyte0[] = new byte[1];
		String s3 = "";
		for (int i = 0; i < s.length(); i++) {
			byte abyte1[] = String.valueOf(s1.charAt(i)).getBytes();
			if ((abyte1[0] > 64) & (abyte1[0] < 91)) {
				String s4;
				if (abyte1[0] < 74)
					s4 = "0".concat(String.valueOf(String.valueOf(String.valueOf(abyte1[0] - 64))));
				else
					s4 = String.valueOf(abyte1[0] - 64);
				s2 = stringReplace(s2, String.valueOf(s.charAt(i)), s4);
			}
		}

		return s2;
	}

	public static String type_to_Chinese(String s) {
		String s1 = s.trim();
		if (s1.equals("1"))
			return "\u55AE\u7B46\u7533\u8CFC";
		if (s1.equals("2"))
			return "\u55AE\u7B46\u8F49\u63DB";
		if (s1.equals("3"))
			return "\u55AE\u7B46\u8D16\u56DE";
		if (s1.equals("4"))
			return "\u5B9A\u671F\u5B9A\u984D\u7533\u8CFC";
		if (s1.equals("5"))
			return "\u5B9A\u671F\u5B9A\u984D\u8F49\u63DB";
		if (s1.equals("6"))
			return "\u5B9A\u671F\u5B9A\u984D\u8D16\u56DE";
		if (s1.equals("7"))
			return "\u90E8\u5206\u8F49\u63DB\u55AE\u7B46";
		if (s1.equals("8"))
			return "\u90E8\u5206\u8D16\u56DE\u55AE\u7B46";
		if (s1.equals("9"))
			return "\u90E8\u5206\u8F49\u63DB\u5B9A\u984D";
		if (s1.equals("A"))
			return "\u90E8\u5206\u8D16\u56DE\u5B9A\u984D";
		if (s1.equals("B"))
			return "\u5B9A\u671F\u5B9A\u984D\u7570\u52D5";
		else
			return "\u578B\u614B\u932F\u8AA4\uFF01";
	}

	public static String stringReplace(String s, String s1, String s2) {
		if (s1 != s2) {
			StringBuffer stringbuffer = new StringBuffer();
			int i = s.length();
			int j = s1.length();
			int k = s2.length();
			for (int l = 0; l < i;) {
				int i1 = s.indexOf(s1, l);
				if (i1 >= l) {
					stringbuffer.append(s.substring(l, i1));
					stringbuffer.append(s2);
					l = i1 + j;
				} else {
					stringbuffer.append(s.substring(l));
					l = i;
				}
			}

			return stringbuffer.toString();
		} else {
			return s;
		}
	}

	public static String castMoney(String s, int i) {
		String s1 = "";
		NumberFormat numberformat = NumberFormat.getInstance();
		numberformat.setMaximumFractionDigits(i);
		if (!s.equals(""))
			s1 = numberformat.format(Integer.parseInt(s));
		return s1;
	}

	public static String castMoney(String s) {
		String s1 = "";
		NumberFormat numberformat = NumberFormat.getInstance();
		if (!s.equals(""))
			s1 = numberformat.format(Integer.parseInt(s));
		return s1;
	}

	public static String castMoney(int i) {
		String s = "";
		NumberFormat numberformat = NumberFormat.getInstance();
		s = numberformat.format(i);
		return s;
	}

	public static String DelLeftZero(String s) {
		String s1 = s;
		for (int i = 0; i < s.length(); i++) {
			if (s.substring(i, i + 1).equals("0"))
				continue;
			s1 = s.substring(i);
			break;
		}

		return s1;
	}

	public static List<String> splitStrByDelimiter(String str, String delimiter) {
		ArrayList<String> strList = new ArrayList<String>();
		// String strs = "";
		// string can be null and ""
		if (str != null && str.trim().length() > 1) {
			String[] strArray = str.split(",");
			for (int i = 0; i < strArray.length; i++) {
				if (str != null && str.trim().length() > 0) {
					strList.add(strArray[i].trim());
					// System.out.println("#########splitStrByDelimiter: i_"+
					// i+", acc_" +strArray[i].trim());
				}

			}
		}

		return strList;
	}

	public static String maskStr(String str, String mask, int startIndex, int len) {
		String rtnMask = "";
		if (str != null && str.length() >= (startIndex + len)) {
			rtnMask = str.substring(0, startIndex);
			// System.out.println("rtnMask0 : " +rtnMask);
			for (int i = startIndex; i < str.length() - 1; i++) {
				rtnMask += mask;
			}
			rtnMask += str.substring(str.length() - 1, str.length());

		} else {
			rtnMask = str;
		}

		// System.out.println("rtnMask1 : " +rtnMask);
		return rtnMask;
	}

	public static String maskStr1(String str, String mask, int startIndex) {
		String rtnMask = "";
		if (str != null && str.length() > startIndex) {
			rtnMask = str.substring(0, startIndex);
			// System.out.println("rtnMask0 : " +rtnMask);
			for (int i = startIndex; i < str.length(); i++) {
				rtnMask += mask;
			}
		} else {
			rtnMask = str;
		}

		// System.out.println("rtnMask1 : " +rtnMask);
		return rtnMask;
	}

	public static String maskStr2(String str, String mask, int startIndex, int len) {
		String rtnMask = "";

		if (str != null && str.length() > -1) {
			rtnMask = str.substring(0, startIndex);
			// System.out.println("rtnMask0 : " +rtnMask);
			for (int i = startIndex; i < len; i++) {
				rtnMask += mask;
			}
		} else {
			rtnMask = str;
		}

		// System.out.println("rtnMask1 : " +rtnMask);
		return rtnMask;
	}

	/**
	 * 行動電話
	 * 
	 * @param str
	 * @param mask
	 * @param startIndex
	 * @param len
	 * @return
	 */
	public static String maskMPhone(String str) {
		str = StringUtils.trim(str);
		if (StringUtils.isBlank(str)) {
			return "";
		}
		if (str.length() > 6) {
			return maskPhone(str, "*", 3, str.length() - 6);
		}
		return str;
	}

	/**
	 * 行動電話
	 * 
	 * @param str
	 * @param mask
	 * @param startIndex
	 * @param len
	 * @return
	 */
	public static String mask3MPhone(String str) {
		str = StringUtils.trim(str);
		if (StringUtils.isBlank(str)) {
			return "";
		}
		if (str.length() > 7) {
			return maskPhone(str, "*", 4, str.length() - 7);
		}
		return str;
	}

	/**
	 * 室內電話
	 * 
	 * @param phone
	 * @return
	 */
	public static String maskPhone(String phone) {
		phone = StringUtils.trim(phone);
		if (StringUtils.isBlank(phone)) {
			return "";
		}
		if (phone.length() > 5) {
			return StringUtility.maskPhone(phone, "*", 2, phone.length() - 5);
		} else {
			return phone;
		}
	}

	/**
	 * 傳真電話
	 * 
	 * @param phone
	 * @return
	 */
	public static String maskFax(String fax) {
		fax = StringUtils.trim(fax);
		if (StringUtils.isBlank(fax)) {
			return "";
		}
		if (fax.length() > 1) {
			return maskStr1(fax, "*", 4);
		} else {
			return fax;
		}
	}

	/**
	 * 電話
	 * 
	 * @param str
	 * @param mask
	 * @param startIndex
	 * @param len
	 * @return
	 */
	public static String maskPhone(String str, String mask, int startIndex, int len) {
		String rtnMask = "";
		if (str != null && str.length() >= (startIndex + len)) {
			rtnMask = str.substring(0, startIndex);
			// System.out.println("rtnMask0 : " +rtnMask);
			for (int i = startIndex; i < startIndex + len; i++) {
				rtnMask += mask;
			}
			rtnMask += str.substring(startIndex + len, str.length());

		} else {
			rtnMask = str;
		}

		// System.out.println("rtnMask1 : " +rtnMask);
		return rtnMask;
	}

	// 半形轉全形

	public static String toFullChar(String s) { // s="23154台北縣新店市安忠路99號";
		String[] asciiTable = { "!", "\"", "#", "$", "%", "&", "\'", "(", ")", "*", "+", ",", "-", ".", "/", "0", "1",
				"2", "3", "4", "5", "6", "7", "8", "9", ":", ";", "<", "=", ">", "?", "@", "A", "B", "C", "D", "E", "F",
				"G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "[",
				"\\", "]", "^", "_", "`", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
				"p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~", " " };
		String[] big5Table = { "！", "”", "＃", "＄", "％", "＆", "’", "（", "）", "＊", "＋", "，", "－", "。", "／", "０", "１", "２",
				"３", "４", "５", "６", "７", "８", "９", "：", "；", "＜", "＝", "＞", "？", "＠", "Ａ", "Ｂ", "Ｃ", "Ｄ", "Ｅ", "Ｆ", "Ｇ",
				"Ｈ", "Ｉ", "Ｊ", "Ｋ", "Ｌ", "Ｍ", "Ｎ", "Ｏ", "Ｐ", "Ｑ", "Ｒ", "Ｓ", "Ｔ", "Ｕ", "Ｖ", "Ｗ", "Ｘ", "Ｙ", "Ｚ", "〔", "＼",
				"〕", "︿", "﹍", "‵", "ａ", "ｂ", "ｃ", "ｄ", "ｅ", "ｆ", "ｇ", "ｈ", "ｉ", "ｊ", "ｋ", "ｌ", "ｍ", "ｎ", "ｏ", "ｐ", "ｑ",
				"ｒ", "ｓ", "ｔ", "ｕ", "ｖ", "ｗ", "ｘ", "ｙ", "ｚ", "｛", "｜", "｝", "～", "　" };

		if (s == null || "".equalsIgnoreCase(s)) {
			return "";
		}

		char[] ca = s.toCharArray();
		StringBuffer outStr = new StringBuffer();

		for (int a = 0; a < ca.length; a++) {
			String caStr = String.valueOf(ca[a]);
			for (int b = 0; b < asciiTable.length; b++) {
				if (caStr.equals(asciiTable[b])) {
					caStr = big5Table[b];
					break;
				}
			}

			outStr.append(caStr);
		}

		return outStr.toString();
	}

	/**
	 * add大寫' '
	 */
	public static String addBigSpace(String s, int len) {

		for (int i = s.length(); i < len; i++) {
			s += toFullChar(" ");
			// s +=" ";
		}

		return s;
	}

	/**
	 * maskEMail
	 */

	public static String maskEMail(String mail) throws Exception {

		String maskEMail = "";
		String email = "";

		try {
			if (mail != null && mail.trim().length() > 0) {
				email = mail.trim();
			}
			if (email.indexOf("@") > 0) {
				String mask = email.substring(0, email.indexOf("@"));
				if (mask.length() < 4) {
					maskEMail = email;
				} else if (mask.length() == 4) {
					maskEMail = (StringUtility.maskStr(mask, "*", 1, 2)
							+ email.substring(email.indexOf("@"), email.length()));
				} else {
					maskEMail = (StringUtility.maskStr(mask, "*", mask.length() - 4, 3)
							+ email.substring(email.indexOf("@"), email.length()));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return maskEMail;
	}

	/**
	 * 英文名字R
	 * 
	 * 顯示前三碼(英文名) >4 顯示第一~第三碼 T h o * * * * * * *
	 * 
	 * @param str
	 * @return
	 */
	public static String maskName(String s) {
		String str = StringUtils.trim(s);
		if (StringUtils.isBlank(str)) {
			return "";
		}

		/* 當包含有中文時僅顯示第一碼 */
		if (StringUtils.length(str) <= 3) {
			str = StringUtils.rightPad(str, 3, '*');
			return mask(str, 2, '*');
		} else if (StringUtils.length(str) <= 4) {
			return mask(StringUtils.trim(str), 3, '*');
		}

		if (isChinese(str)) {
			return mask(StringUtils.trim(str), 4, '*');
		} else {
			/* 當英文時僅顯示前三碼 */
			return mask(StringUtils.trim(str), 4, '*');
		}
	}

	public static String maskName(String str, int len) {
		str = maskName(str);
		return StringUtils.length(str) > len ? StringUtils.substring(str, 0, len) : str;
	}

	/**
	 * 帳號
	 * 
	 * 存款帳號欄位 遮後五碼 11 遮第七～第十碼 0 1 9 5 2 0 * * * * 5 3 放款批覆書號欄位 遮第五～第九碼 11 遮第七～第十碼 7
	 * 1 1 8 3 0 * * * * 3 放款帳號欄位 遮第五～第九碼 13 遮第七～第十碼 7 1 1 8 3 0 * * * * 3 0 4
	 * 外匯存款帳號 X 12 遮第七～第十碼 0 0 2 5 6 1 * * * * 0 3 外匯放款帳號 X 11 遮第七～第十碼 7 1 1 9 8 2 *
	 * * * * 1
	 * 
	 * @param str
	 * @return
	 */
	public static String maskAcno(String str) {
		if (StringUtils.isBlank(str)) {
			return "";
		}
		int iStartIdx = 7, iEndIndex = 10;
		// if (str.length() < 12) {
		// iStartIdx = 1;
		// iEndIndex = 4;
		// }
		return mask(str, iStartIdx, iEndIndex, '*');
	}

	public static String maskAccount(String str) {
		int iEndIndex = StringUtils.length(str) - 5;
		if (iEndIndex < 0) {
			iEndIndex = 0;
		}
		return mask(str, 0, iEndIndex, '*');
	}

	/**
	 * 共用
	 * 
	 * @param str
	 * @param startIndex
	 * @param mask
	 * @return
	 */
	private static String mask(String str, int startIndex, char mask) {
		if (StringUtils.isBlank(str)) {
			return str;
		}
		return mask(str, startIndex, str.length(), mask);
	}

	/**
	 * 共用
	 * 
	 * @param str
	 * @param startIndex
	 * @param endIndex
	 * @param mask
	 * @return
	 */
	private static String mask(String str, int startIndex, int endIndex, char mask) {
		if (StringUtils.isBlank(str)) {
			return str;
		}

		StringBuilder ab = new StringBuilder();
		for (int i = 1; i <= str.length(); i++) {
			if (i >= startIndex && i <= endIndex) {
				ab.append(mask);
			} else {
				ab.append(str.charAt(i - 1));
			}
		}

		return ab.toString();
	}

	// 完整的判斷中文漢字和符號
	public static boolean isChinese(String strName) {
		char[] ch = strName.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			char c = ch[i];
			if (isChinese(c)) {
				return true;
			}
		}
		return false;
	}

	// 根據Unicode編碼完美的判斷中文漢字和符號
	private static boolean isChinese(char c) {
		Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
		if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
				|| ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
				|| ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
				|| ub == Character.UnicodeBlock.GENERAL_PUNCTUATION) {
			return true;
		}
		return false;
	}

	/**
	 * 身份證字號或統編
	 * 
	 * @param idNo
	 * @return
	 */
	public static String maskIdNo(String idNo) {
		int len = StringUtils.length(idNo);
		if (len == 0) {
			return "";
		} else if (len >= 10) {
			return idNo.substring(0, 5) + "****" + idNo.substring(9);
		} else if (len > 5) {
			return StringUtils.rightPad(idNo.substring(0, 5), len, '*');
		} else {
			/** 不可能有下列狀況 **/
			return StringUtils.rightPad("", len, '*');
		}

	}

	public static String insertFixedSpecial(String str, char prefix, int pos) {
		if (StringUtils.isNotBlank(str)) {
			int len = str.length();
			StringBuilder sb = new StringBuilder();
			for (int i = 1; i <= len; i++) {
				if (i % pos == 0 && (i != len)) {
					sb.append(str.charAt(i - 1)).append(prefix);
				} else {
					sb.append(str.charAt(i - 1));
				}
			}
			return sb.toString();
		}
		return str;
	}

	public static String maskCreditCard(String str) {
		if (StringUtils.length(str) == 16) {
			String cardNo_1_4 = str.substring(0, 4);
			String cardNo_13_16 = str.substring(12, 16);
			return cardNo_1_4 + "-XXXX-XXXX-" + cardNo_13_16;
		}
		return str;
	}

	public static void main(String[] args) {
		// ****56789 123456****23456789
//		System.out.println(maskIdNo("A120548799"));
//		System.out.println(maskIdNo("A12054879"));
//		System.out.println(maskIdNo("A1205487"));
//		System.out.println(maskIdNo("A120548"));
//		System.out.println(maskIdNo("A12054"));
//		System.out.println(maskIdNo("A1205"));
//		System.out.println(maskIdNo("A120"));
//		System.out.println(maskIdNo(null));
//		System.out.println(maskIdNo(""));

		// System.out.println(insertFixedSpecial("1234567891235978", '-', 4));
		// System.out.println(maskIdNo("Y120548798"));
		System.out.println(maskName("凱"));
		System.out.println(maskName("凱凱"));
		System.out.println(maskName("凱凱凱"));
		System.out.println(maskName("凱凱凱凱"));
		System.out.println(maskName("凱凱凱凱凱"));

		System.out.println(maskName("a"));
		System.out.println(maskName("ab"));
		System.out.println(maskName("abc"));
		System.out.println(maskName("abcd"));
		System.out.println(maskName("abcde"));
		System.out.println(maskName("abcdef"));

		System.out.println(maskAccount(null));
		System.out.println(maskAccount(""));
		System.out.println(maskAccount("1234"));
		System.out.println(maskAccount("12345"));
		System.out.println(maskAccount("123456"));
		System.out.println(maskAccount("12345678"));
		System.out.println(maskAccount("123456789123456789"));
		// System.out.println(maskName("abcdefg"));

	}
}

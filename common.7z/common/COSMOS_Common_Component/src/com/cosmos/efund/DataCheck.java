/**
 * 
 */
package com.cosmos.efund;


/**
 * @author user
 *
 */
public class DataCheck {
	
	/** * 驗證輸入字串的格式
	* regPattern: 檢驗的格式 (Regular Expression)
	* strForTest: 要被檢驗的字串
	* @param String
	* @param String
	* */
	public boolean validateInput(String strPattern, String strForTest){
		boolean isMatch = strForTest.matches(strPattern);
		return isMatch;
	}

	/**
	* 檢查字串是否為數字
	* @param String
	* */
	public boolean validateNumber(String strForTest){
		return validateInput("^[0-9]*$" , strForTest);
	}

	/**
	* 檢查字串是否為 Email格式
	* @param String
	* */
	public boolean validateMail(String strForTest){
		return validateInput("^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$", strForTest);
	} 


}

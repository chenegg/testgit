//Title:        eFundClient
//Version:      ver91.05.08
//Copyright:    Copyright (c) 1999
//Author:       chuan
//Company:      KGI Bank,Taiwan
//Description:  connect to Ntech's AP SocketServer for filetransfer
//for  基金測試

package com.cosmos.efund;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.emis.invest.util.InitSystemInfo;

public class eFundClient {
	private static Logger logger = LoggerFactory.getLogger(eFundClient.class);
	private InitSystemInfo isi = new InitSystemInfo();
	private Socket connection = null;
	private SocketAddress sa;
	private DataInputStream br = null;
	private PrintStream ps = null;
	private int timeout = 0;

	/*
	 * 
	 */
	public eFundClient() {
		sa = new InetSocketAddress(isi.getEfundIp(), isi.getEfundPort());
	}

	/*
	 * 
	 */
	public void setFundTIA() {
		try {
			connection = new Socket();
			timeout = Integer.parseInt(isi.getInfo("efund.timeout"));
			// System.out.println("eFundClient setFundTIA timeout="+timeout);
			connection.setSoTimeout(timeout);
			connection.connect(sa, timeout);
			logger.info("connection efund server success.....");
			br = new DataInputStream(connection.getInputStream());
			ps = new PrintStream(connection.getOutputStream());
		} catch (IOException e) {
			System.err.println("Unable to connect efund server");
			logger.error(e.getMessage(), e);
		}
	}

	/*
	 * 
	 */
	public String session(String sendbuffer) {
		return this.session(sendbuffer, -1);
	}

	/*
	 * 
	 */
	public String session(String sendbuffer, int strlen) {
		StringBuffer recedata = new StringBuffer();
		try {
			logger.info(">>>> begin send string to efund host..." + sendbuffer);
			if (strlen == -1) {
				ps.print(sendbuffer);
			} else {
				byte sendbyte[] = sendbuffer.getBytes();
				ps.write(sendbyte, 0, strlen);
			}
			ps.flush();

			sendbuffer = null;
			logger.info("send ok....");
			/**取得長度**/
			final byte[] receiveSizeBytes = new byte[4];
			int readCount = br.read(receiveSizeBytes);
			recedata.append(new String(receiveSizeBytes, 0, receiveSizeBytes.length));
			/**長度減4**/
			final int receiveSize = Integer.parseInt(recedata.toString()) - receiveSizeBytes.length;

			int offset = 0;

			final byte[] buffer = new byte[receiveSize];
			int bytesRemaining = receiveSize;
			while (bytesRemaining > 0) {
				readCount = br.read(buffer, offset, bytesRemaining);
				offset += readCount;
				bytesRemaining -= readCount;
			}
			recedata.append(new String(buffer, 0, receiveSize));
			logger.info("readCount=" + receiveSize);
			logger.info("<<<< socketresponse:" + recedata);

			// } while (readCount == -1);
			ps.print("0008*END");
		} catch (IOException e) {
			logger.error(e.toString(), e);
			return "Timeout";// 錯誤訊息回1000

		} catch (Exception ex) {
			logger.error(ex.toString(), ex);
			return "Timeout";// 錯誤訊息回1000
		} finally {
			disConnection();
		}
		return recedata.toString();
	}

	/*
	 * 
	 */
	static final String HEXES = "0123456789ABCDEF";

	public static String getHex(byte[] raw) {
		if (raw == null) {
			return null;
		}
		final StringBuilder hex = new StringBuilder(2 * raw.length);
		for (final byte b : raw) {
			hex.append(HEXES.charAt((b & 0xF0) >> 4)).append(HEXES.charAt((b & 0x0F)));
		}
		return hex.toString();
	}

	private void disConnection() {
		if (ps != null)
			ps.close();
		if (br != null) {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (connection != null) {
			try {
				connection.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
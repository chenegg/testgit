/**
 * eFund 交易序號
 * N:網銀/C:CSR+毫秒3位+日期8位+時間6位
 * Simple Date formate = "SSSyyyyMMddHHmmss"
 */
package com.cosmos.efund;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.ibm.tw.commons.util.time.DateFormatUtils;
import com.ibm.tw.commons.util.time.DateUtils;

/**
 * @author Thomas Liu
 *
 */
public class eFundPid {
	private Calendar TimeNow;

	private String channel;

	private SimpleDateFormat sdfPid = new SimpleDateFormat("SSSyyyyMMddHHmmss");

	/**
	 * 
	 */
	public eFundPid(String channel) {
		this.channel = channel;
		TimeNow = Calendar.getInstance();

		// 因Windows 2008 Server + JDK1.5 所抓取的時間為格林威治時間，與本地時間差8小時
		if (TimeNow.getTimeZone().getID().equals("GMT")) {
			TimeNow.add(Calendar.HOUR, 8);
		}

	}

	/**
	 * @return the PID
	 */
	public String getPid() {
		String pid = channel + sdfPid.format(TimeNow.getTime());
		return pid;
	}

	/**
	 * @return the transTime
	 */
	public String getTransCYMD() {
		String ds = DateUtils.format(DateFormatUtils.SIMPLE_ISO_DATE_FORMAT, TimeNow.getTime());
		String yyyy = ds.substring(0, 4);
		int y = Integer.parseInt(yyyy);
		if (y > 1911) {
			y = y - 1911;
		}
		String yyy = new DecimalFormat("0000").format(y);
		String nds = yyy + ds.substring(4);
		return nds;
	}

	/**
	 * @return the transTime
	 */
	public String getTransTime() {
		String txnTime = DateUtils.format(DateFormatUtils.CLIENTDT_FORMAT, TimeNow.getTime());
		return txnTime;
	}

	public Date getTransDateTime() {
		return TimeNow.getTime();
	}

}

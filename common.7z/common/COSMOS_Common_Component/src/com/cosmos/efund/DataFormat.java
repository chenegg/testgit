/**
 * Modify :
 * 	20141216 1031000437-惠請資訊處協助將網銀基金部份贖回之最小單位，欄位調整至小數點後四位。
 */
package com.cosmos.efund;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author user
 *
 */
@Deprecated
public class DataFormat implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String DateFmt(String data, String ift, String oft) {
		String os = "";
		SimpleDateFormat sdfi = new SimpleDateFormat(ift);
		SimpleDateFormat sdfo = new SimpleDateFormat(oft);
		try {
			Date dd = sdfi.parse(data);
			os = sdfo.format(dd);
		} catch (ParseException e) {
			e.getMessage();
		}

		return os;
	}

	/*
	 * @param String s convert date string s format "yyyyMMdd" to "yyyy/MM/dd"
	 */
	public String dFmtYMD(String s) {
		String isdfp = "yyyyMMdd";
		String osdfp = "yyyy/MM/dd";
		String o = "";
		o = DateFmt(s, isdfp, osdfp);
		return o;
	}

	public String getCYMD() {
		Calendar TimeNow = Calendar.getInstance();
		;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String ds = sdf.format(TimeNow.getTime());
		String yyyy = ds.substring(0, 4);
		int y = Integer.parseInt(yyyy);
		if (y > 1911) {
			y = y - 1911;
		}
		String yyy = new DecimalFormat("0000").format(y);
		String nds = yyy + ds.substring(4);
		return nds;
	}

	// public String dFmtCYMD(String s){
	// String yyyy = s.substring(0,4);
	// int y = Integer.parseInt(yyyy);
	// if (y == 0){
	// return "";
	// }
	// if (y > 1911){
	// y = y - 1911;
	// }
	// String yyy = new DecimalFormat("0000").format(y);
	// String nds = yyy+s.substring(4);
	// String o="";
	// o = dFmtYMD(nds).substring(1);
	// return o;
	// }

	public String dFmtCYMD(String s) {
		if (s == null || s.length() < 4)
			return "";
		String yyyy = s.substring(0, 4);
		int y = Integer.parseInt(yyyy); // CMD
		if (y == 0)
			return "";
		return "" + y + "/" + s.substring(4, 6) + "/" + s.substring(6);
	}

	/*
	 * @param String s convert date string s format "yyyMMdd" to "yyyyMMdd"
	 * (民國年轉西元年)
	 */
	public String dFmtC2YMD(String s) {
		String o = "";
		o = String.valueOf(Integer.parseInt(s) + 19110000);
		return o;
	}

	/*
	 * @param String s convert date string s format "yyyyMMdd" to
	 * "民國 yyy 年 MM 月 dd 日" if(s == null || s.length() < 8) return ""
	 */
	public String dFmtChYMD(String s) {
		if (s == null || s.length() < 8) {
			return "";
		}
		String yyyy = s.substring(0, 4);
		int y = Integer.parseInt(yyyy);
		if (y > 1911) {
			y = y - 1911;
		}
		String yyy = new DecimalFormat("0000").format(y);
		String nds = yyy + s.substring(4);
		String o = "";
		// 20141230 由於 JDBC 不同版本會回傳不同結果所做的修改
		// o = "民國 "+nds.substring(1,4) +" 年 "+nds.substring(4,6)
		// +" 月 "+nds.substring(6) +" 日";
		if (nds.length() >= 8) {
			o = "民國 " + nds.substring(1, 4) + " 年 " + nds.substring(4, 6) + " 月 " + nds.substring(6, 8) + " 日";
		}
		return o;
	}

	/*
	 * @param String s convert date string s format "yyyyMMdd" to "民國年yyyyMMdd"
	 */
	public String dFmtCYMD1(String s) {
		String yyyy = s.substring(0, 4);
		int y = Integer.parseInt(yyyy);
		if (y > 1911) {
			y = y - 1911;
		}
		String yyy = new DecimalFormat("0000").format(y);
		String nds = yyy + s.substring(4);
		String o = "";
		o = nds;
		return o;
	}

	public String amtFmt(String s) {
		Double db = Double.parseDouble(s);

		NumberFormat n = NumberFormat.getInstance();
		String o = n.format(db);
		return o;
	}

	public String amtFmt(String s, int point) {
		String o;
		if (point > 0) {
			o = amtFmt(s, point, ' ');
		} else {
			o = amtFmt(s);
		}
		return o;
	}

	public String amtFmt(String s, int point, char percent) {
		String n1 = s.substring(0, s.length() - point);
		String n2 = s.substring(s.length() - point, s.length());
		Double db = Double.parseDouble(n1);
		String o;

		NumberFormat n = NumberFormat.getInstance();
		if (percent == '%') {
			if (n2.length() > 0) {
				o = n.format(db) + '.' + n2 + '%';
			} else {
				o = n.format(db) + '%';
			}
		} else {
			if (n2.length() > 0) {
				o = n.format(db) + '.' + n2;
			} else {
				o = n.format(db);
			}
		}
		return o;
	}

	public String amtPercent(String s, char percent) {
		String o;
		if (percent == '%') {
			o = amtNoPoint(s) + '%';
		} else {
			o = amtNoPoint(s);
		}
		return o;
	}

	public String amtNoPoint(String s) {
		int p = s.indexOf(".");
		String cs = s.substring(0, p);
		return amtFmt(cs);
	}

	public String clrAmtFmt(String s) {
		String cs = s.replaceAll("[,.%]", "");
		return cs;
	}

	public String clrAmtFmt(String s, int lenth) {
		String cs = clrAmtFmt(s);
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < lenth - cs.length(); i++) {
			sb.append('0');
		}
		sb.append(cs);
		return sb.toString();
	}

	public String padPoint(String s, int point) {
		String cs = "";
		int p = s.indexOf(".");
		if (p == -1) {
			cs = s + "." + padZeros(cs, point);
		} else {
			cs = s;
		}
		return cs;
	}

	public String padPoint1(String s, int point) {
		s = s.replaceAll(",", "");
		String cs = "";
		int p = s.indexOf(".");
		if (p == -1) {
			cs = s + "." + padZeros(cs, point);
		} else {
			cs = s;
		}
		return cs;
	}

	public String clrAmtFmt(String s, int lenth, int point) {
		String cs = padPoint(s, point);
		cs = clrAmtFmt(cs);
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < lenth - cs.length(); i++) {
			sb.append('0');
		}
		sb.append(cs);
		return sb.toString();
	}

	/**
	 * 右補空白
	 * @param s
	 * @param lenth
	 * @return
	 */
	public String padSpaces(String s, int lenth) {
		StringBuffer sb = new StringBuffer();
		sb.append(s);
		for (int i = 0; i < lenth - s.length(); i++) {
			sb.append(' ');
		}
		return sb.toString();
	}

	/**
	 * 左補空白
	 * @param s
	 * @param lenth
	 * @return
	 */
	public String addSpaces(String s, int lenth) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < lenth - s.length(); i++) {
			sb.append(' ');
		}
		sb.append(s);
		return sb.toString();
	}

	/**
	 * 右補0
	 * @param s
	 * @param lenth
	 * @return
	 */
	public String padZeros(String s, int lenth) {
		StringBuffer sb = new StringBuffer();
		sb.append(s);
		for (int i = 0; i < lenth - s.length(); i++) {
			sb.append('0');
		}
		return sb.toString();
	}

	/**
	 * 左補0
	 * @param s
	 * @param lenth
	 * @return
	 */
	public String addZeros(String s, int lenth) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < lenth - s.length(); i++) {
			sb.append('0');
		}
		sb.append(s);
		return sb.toString();
	}

	/**
	 * 給部分贖回單位數用，
	 * 最後會變成 12 位數 的 char，
	 * 比如, 8位整數，4位小數時 :
	 * 123.456 --> 000001234560，
	 * 1234567890123 --> 123456789012
	 * 123456789.012345 --> 123456789012
	 * 
	 * @param s		            原始單位數字串
	 * @param intLength   整數位數
	 * @param pointLength 小數點位數
	 * @return
	 */
	public String parseInputUnit(String s, int intLength, int pointLength) {
		if (s == null || "".equals(s.trim()))
			return s;
		s = s.replaceAll("[,%]", "");
		int p = s.indexOf(".");
		String rtString = null;
		if (p > 0) {
			rtString = addZeros(s.substring(0, p), intLength) + padZeros(s.substring(p + 1, s.length()), pointLength);
		} else {
			rtString = addZeros(s, intLength) + padZeros("", pointLength);
		}
		if (rtString.length() > (intLength + pointLength)) {
			return rtString.substring(0, intLength + pointLength);
		} else {
			return rtString;
		}
	}

	public static void main(String[] args) {
		String str = "123456789.012345";
		DataFormat df = new DataFormat();
		System.out.println(df.parseInputUnit(str, 8, 4));
	}
}

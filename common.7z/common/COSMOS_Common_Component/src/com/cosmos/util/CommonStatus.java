/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.cosmos.util;

import org.apache.commons.lang.StringUtils;

/**
 * 狀態資料
 * 
 * @author Kevin
 * @version 1.0, 2007/9/13
 * @see
 * @since
 */
public class CommonStatus {

	/** 系統代碼 */
	protected String systemId = "";

	/** 交易回應代碼，0：表示交易正確 */
	protected String statusCode = ICommonCode.UNKNOWN_STATUS_CODE;

	/** 狀態等級 ERROR/WARNING/INFO/TIMEOUT */
	protected String severity = "";

	/** 狀態描述 */
	protected String statusDesc = "";

	/**
	 * 
	 */
	public CommonStatus() {
		super();
	}

	/**
	 * @param sSystemID
	 * @param sStatusCode
	 * @param sSeverity
	 * @param sStatusDesc
	 */
	public CommonStatus(String systemId, String statusCode, String severity, String statusDesc) {
		this.systemId = systemId;
		this.statusCode = statusCode;
		this.severity = severity;
		this.statusDesc = statusDesc;
	}

	/**
	 * 系統代碼
	 * 
	 * @param systemId
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getSystemId() {
		return systemId;
	}

	/**
	 * 交易回應代碼，0：表示交易正確
	 * 
	 * @param statusCode
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * 狀態等級 ERROR/WARNING/INFO
	 * 
	 * @param severity
	 */
	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getSeverity() {
		return severity;
	}

	/**
	 * 狀態描述
	 * 
	 * @param statusDesc
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * 是否為成功的狀態
	 * 
	 * @return
	 */
	public boolean isSuccess() {
		if (StringUtils.isBlank(statusCode)) {
			return true;
		}
		else {
			return statusCode.equalsIgnoreCase(ICommonCode.SUCCESS_STATUS_CODE) || statusCode.equalsIgnoreCase(ICommonCode.SUCCESS_STATUS_CODE_CBFX01)
				|| statusCode.equalsIgnoreCase(ICommonCode.SUCCESS_STATUS_CODE_CBFX02) || statusCode.equalsIgnoreCase(ICommonCode.SUCCESS_STATUS_CODE_AR);
		}
	}

	/**
	 * 是否為未知的狀態
	 * 
	 * @return
	 */
	public boolean isUnknown() {
		return getStatusCode().equalsIgnoreCase(ICommonCode.UNKNOWN_STATUS_CODE);
	}

	/**
	 * 是否為Timeout
	 * 
	 * @return
	 */
	public boolean isTimeout() {

		return getSeverity().equalsIgnoreCase(ICommonCode.SEVERITY_TIMEOUT);
	}

	/**
	 * 傳回狀態結果
	 * <ul>
	 * <li>UNKNOWN</li>
	 * <li>SUCCESS</li>
	 * <li>FAIL</li>
	 * </ul>
	 * 
	 * @return
	 */
	public int getResult() {
		int iResult = ICommonCode.UNKNOWN;
		if (isSuccess()) {
			iResult = ICommonCode.SUCCESS;
		}
		else if (isUnknown()) {
			iResult = ICommonCode.FAIL;
		}
		else {
			iResult = ICommonCode.FAIL;
		}
		return iResult;
	}
}

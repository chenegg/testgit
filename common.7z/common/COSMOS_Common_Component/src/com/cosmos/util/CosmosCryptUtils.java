/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.util;
 
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.DigestUtils;


/**
 * <p>Cosmos Crypt Utils</p>
 *
 * @author  jeff
 * @version 1.0, 2011/4/11
 * @see	    
 * @since 
 */
public class CosmosCryptUtils {
	/**
	 * <p>ESB 安控密碼 加密</p>
	 * 
	 * 加密前端系統密碼
	 * <pre>
	 * ESB Database
	 * 
	 * Table: ESBCLIENT
	 * Field: ClientPwd
	 *  
	 * </pre>
	 * 
	 * @param clientPlainPwd
	 * @return
	 * @throws CryptException 
	 * @throws Exception 
	 */
	public static String encryptEsbPwd(String clientPlainPwd) throws CryptException  {
		return DESUtils.encrypt(clientPlainPwd);
	}
	
	/**
	 * <p>ESB 安控密碼 解密</p>
	 * 
	 * 解密前端系統密碼
	 * <pre>
	 * ESB Database
	 * 
	 * Table: ESBCLIENT
	 * Field: ClientPwd
	 *  
	 * </pre>
	 * @param clientEncrypedPwd
	 * @return
	 * @throws CryptException 
	 * @throws Exception 
	 */
	public static String decryptEsbPwd(String clientEncrypedPwd) throws CryptException  {
		return DESUtils.decrypt(clientEncrypedPwd);
	}

	/**
	 * ESB 安控密碼 加密 (電文用)
	 * 
	 * @param str
	 * @return
	 * @throws CryptException 
	 * @throws Exception 
	 */
	public static String encryptEsbPwd(String clientPassword, String clientDt) throws CryptException {
		
		byte[] data = ConvertUtils.str2Bytes(clientPassword + clientDt, "UTF8");
		
		//return DigestUtils.md5Hex(str + clientDt);
		
		return DigestUtils.md5Hex(data);
	}
	
	/**
	 * 使用者密碼 加密
	 * 
	 * @param str
	 * @return
	 * @throws CryptException 
	 * @throws Exception 
	 */
	public static String encryptUserPwd(String userPassword) throws CryptException   {
		byte[] data = ConvertUtils.str2Bytes(userPassword, "UTF8");
		
		//return DigestUtils.md5Hex(str + clientDt);
		
		return DigestUtils.md5Hex(data);
	}
	
	public static void main(String[] args) {

		try {
			// Encrypt Esb Pssword (DB)
			long start = System.currentTimeMillis();
			String encrypted = encryptEsbPwd("Don't tell anybody!");
			long end = System.currentTimeMillis();
			System.out.println("Execute Time: " + (end - start));
			System.out.println(encrypted);

			// Decrypt Esb Password (DB)
			start = System.currentTimeMillis();
			String decrypted = decryptEsbPwd(encrypted);
			end = System.currentTimeMillis();
			System.out.println("Execute Time: " + (end - start));
			System.out.println(decrypted);
			
			// Encrypt Esb Pssword (電文)
			String clientDt = "2011/03/29";
			start = System.currentTimeMillis();
			encrypted = encryptEsbPwd(decrypted, clientDt);
			end = System.currentTimeMillis();
			System.out.println("Execute Time: " + (end - start));
			System.out.println(encrypted);
			start = System.currentTimeMillis();
			encrypted = encryptEsbPwd(decrypted, clientDt);
			end = System.currentTimeMillis();
			System.out.println("Execute Time: " + (end - start));
			System.out.println(encrypted);
			
			// Encrypt User Password
			start = System.currentTimeMillis();
			encrypted = encryptUserPwd("HLe8shuxjg");
			end = System.currentTimeMillis();
			System.out.println("Execute Time: " + (end - start));
			System.out.println(encrypted);
		}
		catch (Exception e) {
			// TODO 自動產生 catch 區塊
			e.printStackTrace();
		}

	}
}



 
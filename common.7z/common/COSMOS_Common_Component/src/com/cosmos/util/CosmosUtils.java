/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cosmos.code.CibErrorCode;
import com.cosmos.code.CosmosSystemId;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.id.ICommonCode;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateFormatUtils;
import com.ibm.tw.commons.util.time.DateUtils;

/**
 * <p>
 * COSMOS 共用工具集
 * </p>
 * 
 * @author jeff
 * @version 1.0, 2011/4/11
 * @see
 * @since
 */
public class CosmosUtils {

	private static boolean SQL_NOT = true;

	private static boolean SQL_OK = false;

	private static Logger logger = LoggerFactory.getLogger(CosmosUtils.class);
	// protected static Log logger = LogFactory.getLog(CosmosUtils.class);

	private static String ESB_UNKNOWN_ERROR = "系統異常，請洽銀行客服人員";

	/**
	 * <p>
	 * 幣別常數
	 * </p>
	 * 
	 * @author Shaka
	 * @version Mar 29, 2013
	 * @see
	 * @since
	 */
	public enum CurrencyID {
		/** 台幣 */
		TWD("TWD"),
		/** 美金 */
		USD("USD");

		private final String currencyId;

		private CurrencyID(String currencyId) {
			this.currencyId = currencyId;
		}

		public String str() {
			return currencyId;
		}

		public String toString() {
			return currencyId;
		}
	}

	/**
	 * 105年06月27日
	 * @param d
	 * @return
	 */
	public static String getDisplayChineseDate(Date d) {
		if (d == null) {
			return null;
		}
		String dateStr = DateUtils.getROCDateStr(d, DateUtils.ROC_LINK);
		return (StringUtils.isBlank(dateStr)) ? dateStr : dateStr.replaceFirst("/", "年").replaceFirst("/", "月") + "日";
	}

	/**
	 * 105年06月27日 23:15
	 * @param d
	 * @return
	 */
	public static String getDisplayChineseDateTime(Date d) {
		if (d == null) {
			return null;
		}
		String sd = DateUtils.format(DateFormatUtils.SIMPLE_DATE_TIME_FORMAT, d);
		String cy = String.valueOf(Integer.parseInt(sd.substring(0, 4)) - 1911);
		String dateStr = cy + "年" + sd.substring(4, 6) + "月" + sd.substring(6, 8) + "日";
		return dateStr + " " + sd.substring(9, 11) + ":" + sd.substring(11, 13) + ":" + sd.substring(13, 15);
	}

	/**
	 * 取得顯示日期及時間
	 * 
	 * @param dt
	 * @param locale
	 * @return
	 */
	public static String getDisplayDateTime(Date dt, Locale locale) {
		return DateFormatUtils.format(dt, DateFormatUtils.CE_DATETIME_FORMAT);
	}

	/**
	 * 取得顯示日期
	 * 
	 * @param dt
	 * @param locale
	 * @return
	 */
	public static String getDisplayDate(Date dt, Locale locale) {
		return DateFormatUtils.format(dt, DateFormatUtils.CE_DATE_FORMAT.getPattern());
	}

	/**
	 * 取得顯示日期
	 * 
	 * @param dt
	 * @param locale
	 * @return
	 */
	public static Date getDisplayDate(String dt, Locale locale) {
		return DateUtils.getDateByDateFormat(dt, DateFormatUtils.CE_DATE_FORMAT.getPattern());
	}

	/**
	 * 依據電文之Date (yyyy-MM-dd) 與Time (HH:mm:ss)取得對應Date
	 * 
	 * @param date
	 * @param time
	 * @return
	 */
	public static Date getEsbDateTime(String date, String time) {
		return DateUtils.getDateByDateFormat(date + " " + time, "yyyy-MM-dd HH:mm:ss");
	}

	// /**
	// * 取得異常說明（銀行）
	// *
	// * @param systemId
	// * @param errorCode
	// * @param locale
	// * @return
	// */
	// public static String getInternalErrorDesc(String systemId, String
	// errorCode, Locale locale) {
	// StringBuffer sb = new StringBuffer();
	//
	// ErrorCodeEntity entity = getErrorCode(systemId, errorCode, locale);
	//
	// if (entity != null) {
	// sb.append(entity.getInternalDesc());
	// }
	//
	// sb.append(" [");
	// sb.append(systemId);
	// sb.append("-");
	// sb.append(errorCode);
	// sb.append("]");
	//
	// return sb.toString();
	//
	// }

	/**
	 * 統一格式, 取得顯示用的金額(含幣別) 輸出樣式 -> NTD12,234,555.03
	 * 
	 * <pre>
	 * formatMoney(null, null, null) = &quot;&quot; 
	 * formatMoney(&quot;&quot;, &quot;1234&quot;, &quot;&quot;) = 1,234  
	 * formatMoney(&quot;NTD&quot;, &quot;012345.0120&quot;, &quot; &quot;) = NTD 12,345.012
	 * </pre>
	 * 
	 * @param currencyId
	 * @param money
	 * @param delim
	 * @return
	 */
	public static String formatMoney(String currencyId, BigDecimal money, String delim) {

		String moneyStr = ConvertUtils.bigDecimal2Str(money);
		String sMoneyString = StringUtils.getMoneyStr(moneyStr);

		return currencyId + delim + sMoneyString;
	}

	/**
	 * 取得顯示用的金額(含幣別) 輸出樣式 -> NTD 12,234,555.03
	 * 
	 * <pre>
	 * formatMoney(null, null) = &quot;&quot; 
	 * formatMoney(&quot;&quot;, &quot;1234&quot;) = 1,234  
	 * formatMoney(&quot;NTD&quot;, &quot;012345.0120&quot;) = NTD 12,345.012
	 * </pre>
	 * 
	 * @param currencyId
	 * @param money
	 * @return
	 */
	public static String formatMoney(String currencyId, BigDecimal money) {
		return formatMoney(currencyId, money, " ");
	}

	/**
	 * 取得顯示用的金額 輸出樣式 -> 12,234,555.03
	 * 
	 * @param money
	 * @return
	 */
	public static String formatMoney(BigDecimal money) {
		return formatMoney("", money, " ");
	}

	/**
	 * 統一格式, 取得顯示用的金額(含幣別) 輸出樣式 -> NTD 12,234,555.03
	 * 
	 * <pre>
	 * formatAmount(null, null, 0, null) = &quot;&quot;  
	 * formatAmount( &quot;&quot;, 1234.123, 2 , &quot;&quot;) = 1,234.12  
	 * formatAmount(&quot;NTD&quot;, 012345.0120, 3, &quot; &quot;) = NTD 12,345.012
	 * </pre>
	 * 
	 * @param currencyId
	 * @param money
	 * @param iScale
	 * @param delim
	 * @return
	 */
	public static String formatMoney(String currencyId, BigDecimal money, int iScale, String delim) {

		String moneyStr = ConvertUtils.bigDecimal2Str(money);
		String sMoneyString = StringUtils.getMoneyStr(moneyStr, iScale);

		return currencyId + delim + sMoneyString;
	}

	/**
	 * 取得顯示用的金額輸出樣式 -> 12,234,555.03
	 * 
	 * <pre>
	 * formatAmount(null, 1) = &quot;&quot; 
	 * formatAmount(1234567.89, 2) = &quot;1,234,567.89&quot;
	 * formatAmount(1234567.00, 1) = &quot;1,234,567.0&quot;;
	 * formatAmount(1234567.0100, 2) = &quot;1,234,567.01&quot;;
	 * </pre>
	 * 
	 * @param money
	 * @param iScale
	 * @return
	 */
	public static String formatAmount(BigDecimal money, int iScale) {
		return formatMoney("", money, iScale, " ");
	}

	/**
	 * 取得統一的比率顯示名稱
	 * 
	 * <pre>
	 * getRateStr(&quot;000122.00100&quot;) = &quot;122.001%&quot;  
	 * getRateStr(&quot;00.12&quot;) = &quot;0.12%&quot;  
	 * getRateStr(&quot;00.00&quot;) = &quot;0.0%&quot;
	 * </pre>
	 * 
	 * @param rate
	 * @return
	 */
	public static String formatRate(String rate) {
		return StringUtils.getRateStr(rate) + "%";
	}

	/**
	 * 依據自行帳號取得分行代號
	 * 
	 * @param accountNo
	 * @return
	 */
	public static String getCosmosBranchId(String accountNo) {
		return StringUtils.substring(accountNo, 0, 3);
	}

	/**
	 * 取得 multi-language Bundle
	 * 
	 * @param sBaseName
	 * @param sKey
	 * @return
	 */
	public static String getBundleString(String sBaseName, String sKey, Locale locale) {
		try {
			ResourceBundle rb = ResourceBundle.getBundle(sBaseName, locale);
			String sBundleString = rb.getString(sKey);
			return sBundleString;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return "???" + sKey + "???";
		}
	}

	/**
	 * 取得DB查詢起日
	 * 
	 * 清除時分秒欄位
	 * 
	 * @param startDate
	 * @return
	 */
	public static Date getStartDate(Date startDate) {
		return DateUtils.getStartDate(startDate);
	}

	/**
	 * 取得DB查詢迄日
	 * 
	 * 設定為23:59:59.999
	 * 
	 * @param endDate
	 * @return
	 */
	public static Date getEndDate(Date endDate) {
		return DateUtils.getEndDate(endDate);
	}

	// /**
	// * <p>
	// * 取得子公司顯示名稱
	// * </p>
	// *
	// * (10碼ID)+(1空白)+(戶名別名or中文戶名)
	// *
	// * @param company
	// * @return
	// */
	// public static String getChildCompanyDisplayName(Company parent, Company
	// child, List<ParentChildEntity> parentChildList, Locale locale) {
	//
	// if (null == child) {
	//
	// return "";
	// }
	//
	// StringBuffer sb = new StringBuffer();
	//
	// // 統編 + 空白
	// sb.append(child.getUid()).append(" ");
	//
	// // 由ParentChild取得子公司別名
	// String alias = getChildAliasName(parent, child, parentChildList);
	//
	// // 有公司別名
	// if (StringUtils.isNotBlank(alias)) {
	// sb.append(alias);
	// }
	// // 取中文戶名
	// else {
	// sb.append(child.getCompanyName());
	// }
	//
	// return sb.toString();
	//
	// }
	//
	// /**
	// * 取得子公司別名
	// *
	// * @param parent
	// * @param child
	// * @return
	// */
	// private static String getChildAliasName(Company parent, Company child,
	// List<ParentChildEntity> parentChildList) {
	//
	// for (ParentChildEntity entity : parentChildList) {
	//
	// if (entity.getChildCompanyKey() == child.getCompanyKey()) {
	// return entity.getChildCompanyAlias();
	// }
	// }
	//
	// return "";
	// }

	/**
	 * 將字串leftPad至指定長度(以Byte計算)
	 * 
	 * @param str
	 * @param size
	 * @param pad
	 * @param encoding
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String leftPadByte(String str, int size, Character pad, String encoding)
			throws UnsupportedEncodingException {

		str = StringUtils.defaultString(str);

		// 取得字串Byte陣列
		byte[] strByte = str.getBytes(encoding);

		// 取得Pad Byte陣列
		byte[] padByte = pad.toString().getBytes(encoding);

		// Padding字串至指定長度
		while (strByte.length < size) {
			strByte = ArrayUtils.addAll(padByte, strByte);
		}

		// 轉回String
		String string = new String(strByte, encoding);
		return string;
	}

	/**
	 * 將字串rightPad至指定長度(以Byte計算)
	 * 
	 * @param str
	 * @param size
	 * @param pad
	 * @param encoding
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String rightPadByte(String str, int size, Character pad, String encoding)
			throws UnsupportedEncodingException {

		str = StringUtils.defaultString(str);

		// 取得字串Byte陣列
		byte[] strByte = str.getBytes(encoding);

		// 取得Pad Byte陣列
		byte[] padByte = pad.toString().getBytes(encoding);

		// Padding字串至指定長度
		while (strByte.length < size) {
			strByte = ArrayUtils.addAll(strByte, padByte);
		}

		// 轉回String
		String string = new String(strByte, encoding);
		return string;
	}

	public static String rightPadByte(String str, int size, Character pad) {

		str = StringUtils.defaultString(str);

		// 取得字串Byte陣列
		byte[] strByte = str.getBytes();

		// 取得Pad Byte陣列
		byte[] padByte = pad.toString().getBytes();

		// Padding字串至指定長度
		while (strByte.length < size) {
			strByte = ArrayUtils.addAll(strByte, padByte);
		}

		// 轉回String
		String string = new String(strByte);
		return string;
	}

	/**
	 * 依據ErrorCode判斷是否為失敗交易
	 * 
	 * 若ErrorCode為null, 空值, 或"0"則為成功 否則為失敗
	 * 
	 * @param errorCode
	 * @return
	 */
	public static boolean isError(String errorCode) {
		if (StringUtils.isBlank(errorCode)) {
			return false;
		} else if (StringUtils.equals(errorCode, ICommonCode.SUCCESS_STATUS_CODE)) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 依據ErrorCode判斷是否為成功交易
	 * <ul>
	 * <li>ErrorCode為null</li>
	 * <li>ErrorCode為空值</li>
	 * <li>ErrorCode為"0"</li>
	 * </ul>
	 * 
	 * @param errorCode
	 * @return
	 */
	public static boolean isSuccess(String errorCode) {
		return !isError(errorCode);
	}

	/**
	 * 取得電話號碼格式
	 * 
	 * <pre>
	 * 02-22661000#1234
	 * </pre>
	 * 
	 * @return
	 */
	public static String getTel(String tel1, String tel2, String tel3) {

		if (StringUtils.isBlank(tel2)) {
			return "";
		}

		StringBuffer sb = new StringBuffer();

		if (StringUtils.isNotBlank(tel1)) {
			sb.append(tel1).append("-");
		}

		sb.append(tel2);

		if (StringUtils.isNotBlank(tel3)) {
			sb.append("#").append(tel3);
		}
		return sb.toString();
	}

	/**
	 * 取得傳真號碼格式
	 * 
	 * <pre>
	 * 02-22661000&tilde;1234
	 * </pre>
	 * 
	 * @return
	 */
	public static String getFax(String tel1, String tel2) {

		if (StringUtils.isBlank(tel2)) {
			return "";
		}

		StringBuffer sb = new StringBuffer();

		if (StringUtils.isNotBlank(tel1)) {
			sb.append(tel1).append("-");
		}

		sb.append(tel2);

		return sb.toString();
	}

	/**
	 * 將變數資料加密
	 * 
	 * @param sParam
	 * @return
	 */
	public static String encryptParamValue(String sParamValue) {
		try {
			return DESUtils.getMaskEncrypt(DESUtils.encrypt(sParamValue));
		} catch (Exception e) {
			logger.warn("Encrypt param[" + sParamValue + "] failed", e);
		}
		return sParamValue;
	}

	/**
	 * 判斷EsbActionException是否為TimeOut之錯誤
	 * 
	 * @param e
	 * @return
	 * @throws DatabaseException
	 */
	public static boolean isTimeOut(ActionException exception) {

		if (null == exception) {
			return false;
		}

		String systemId = exception.getStatus().getSystemId();
		String errorCode = exception.getStatus().getStatusCode();

		// ESB TimeOut
		if (StringUtils.equals(CibErrorCode.ESB_TIMEOUT_EXCEPTION.getSystemId(), systemId)
				&& StringUtils.equals(CibErrorCode.ESB_TIMEOUT_EXCEPTION.getErrorCode(), errorCode)) {
			return true;
		}
		// 原先只判斷 MQ TimeOut (M1007)
		// 改為判斷MQ 所有錯誤 (Mxxxx)
		else if (StringUtils.equals(CosmosSystemId.ESB.getSystemId(), systemId)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * TODO:取得ENUM的描述
	 * 
	 * @param displayKey
	 * @param locale
	 * @return
	 */
	public static String getEnumDesc(String shortClassName, String messageKey, Locale locale) {

		// getBundleString("b2c.b2cConstants", displayKey, locale);

		return messageKey;

	}

	public static void main(String[] args) {
		try {
			// String format = "^[\\w-]+([\\.+][\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$";
			// // System.err.println(new BigDecimal("30000000").compareTo(new
			// BigDecimal("30000000")));
			// String mail = "123gmail.com;456@gmail.com";
			// if(StringUtils.isNotBlank(mail)) {
			// String array[] = StringUtils.split(mail, ";");
			// for(int i=0; i<array.length; i++) {
			// System.err.println(array[i]);
			// if (!array[i].matches(format)) {
			// System.err.println("error");
			// } else {
			// System.err.println("right");
			// }
			//
			// }
			// }
			// String test = "12345678";
			// System.err.println("result="+getMaskString(test,6,8));
			// System.err.println("result="+getNetMsgSeqno("NB","A1234567890"));

			String subject = "c4c6c8c1c3f2f0f0f140f0f861f0f761f2f0f1f240f1f17af4f07af1f040c3d6c3c9c3e2e340e3998195a28183a3899695407d7d4089a2409596a34099858396879589a985844b40c38885839240404040a38881a340a3888540a3998195a28183a389969540958194854089a240839699998583a34b";
			// subject = StringUtils.substring(subject, 0, 2);

			System.err.println(ConvertUtils.bytes2Str(ConvertUtils.hexString2ByteArray(subject), "cp937"));
			// int length = 0;
			//
			// for (int i = 0; i < subject.length(); i++) {
			// if (subject.codePointAt(i) > 255) {
			// length += 2;
			// }
			// else {
			// length++;
			// }
			// }
			// if (length == 6 || length < 6) {
			// subject = StringUtils.substring(subject, 0, 1) + "**";
			// }
			// if (length == 8 || (length > 6 && length < 8)) {
			// subject = StringUtils.substring(subject, 0, 2) + "**";
			// }
			// if (length > 8 && checkFullSpaceWord(subject)) {
			// subject = StringUtils.substring(subject, 0, 3) + "*********";
			// }
			//
			// if (length > 8 && !checkFullSpaceWord(subject)) {
			// subject = StringUtils.substring(subject, 0, 3) + "*******";
			// }

			System.err.println("subject=" + subject);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean checkFullSpaceWord(String checkStr) {

		for (int i = 0; i < checkStr.length(); i++) {
			if (checkStr.codePointAt(i) > 255) {

				return true;
			}
		}

		return false;

	}

	/**
	 * 依輸入字串取得對應遮罩字串
	 * 
	 * @param date
	 * @param time
	 * @return
	 */
	public static String getMaskString(String maskData, int startLen, int endLen) {
		if (StringUtils.isBlank(maskData)) {
			return "";
		}
		String maskDataFirst = StringUtils.substring(maskData, 0, startLen - 1);
		String maskDataEnd = StringUtils.substring(maskData, endLen, maskData.length());
		int starLength = endLen - startLen + 1;
		String startStr = StringUtils.leftPad("", starLength, "*");
		return maskDataFirst + startStr + maskDataEnd;

	}

	/**
	 * 依輸入帳號取得對應帳號字串
	 * 
	 * @param date
	 * @param time
	 * @return
	 */
	public static String getAccountMaskString(String account) {
		return getMaskString(account, 7, 10);

	}

	/**
	 * 依輸入統編取得對應遮罩字串
	 * 
	 * @param date
	 * @param time
	 * @return
	 */
	public static String getUidMaskString(String uid) {
		return getMaskString(uid, 6, 8);

	}

	/**
	 * 依輸入戶名取得對應遮罩字串
	 * 
	 * @param date
	 * @param time
	 * @return
	 */
	public static String getNameMaskString(String name) {
		if (StringUtils.isBlank(name)) {
			return "";
		}

		int length = 0;

		for (int i = 0; i < name.length(); i++) {
			if (name.codePointAt(i) > 255) {
				length += 2;
			} else {
				length++;
			}
		}
		if (length == 6 || length < 6) {
			name = StringUtils.substring(name, 0, 1) + "**";
		}
		if (length == 8 || (length > 6 && length < 8)) {
			name = StringUtils.substring(name, 0, 2) + "**";
		}
		if (length > 8 && checkFullSpaceWord(name)) {
			name = StringUtils.substring(name, 0, 3) + "*********";
		}

		if (length > 8 && !checkFullSpaceWord(name)) {
			name = StringUtils.substring(name, 0, 3) + "*******";
		}

		return name;

	}

	public static String getRateMessage(String rate) {
		int iRate = Integer.parseInt(rate);
		if (StringUtils.equals(rate, "") || iRate == 0) {
			return "不得隨時質借";
		} else {
			return "得隨時質借動用" + iRate + "成";
		}
	}

	/**
	 * 修改 OBU判斷前三碼為英文即為OBU
	 * 
	 * @return
	 */
	public static boolean isOBU(String uid) {

		// 2015/02/25 修改 OBU判斷前三碼為英文即為OBU
		return uid.matches("^[A-Za-z]{3}.*");

		// return getCompanyUid().startsWith("COBU");
	}

	/**
	 *檢查身份證字號/統編
	 * @param str
	 * @return
	 */
	public static boolean checksqlid(String str) {
		if (str == null)
			return SQL_NOT;
		if (!(str.length() == 8 || str.length() == 10 || str.length() == 11)) {
			return SQL_NOT;
		}
//		if (str.length() == 8) { // 統編
//			if (isOBU(str) == false) {
//				try {
//					Long.parseLong(str);
//				} catch (NumberFormatException e) {
//					return SQL_NOT;
//				}
//			} else {
//				/**為obu**/
//			}
//		}
//		if (str.length() == 10 || str.length() == 11) { // id
//			try {
//				Long.parseLong(str.substring(2, str.length()));
//			} catch (NumberFormatException e) {
//				return SQL_NOT;
//			}
//
//			if (!Character.isLetter(str.charAt(0)))
//				return SQL_NOT;
//
//			if (!(Character.isLetter(str.charAt(1)) || Character.isDigit(str.charAt(1))))
//				return SQL_NOT;

//		}
		return SQL_OK;

	}

}

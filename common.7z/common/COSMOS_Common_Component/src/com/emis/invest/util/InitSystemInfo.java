package com.emis.invest.util;

import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.InitialContext;

import com.ibm.tw.commons.util.ConvertUtils;

public class InitSystemInfo {
	private static ResourceBundle bundle;
	private Context ctx;

	public InitSystemInfo() {
		System.out.println("class:InitSystemInfo , method name: InitSystemInfo");
		try {
			if (bundle == null) {
				this.bundle = ResourceBundle.getBundle("ApplicationResources");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public InitSystemInfo(Context ctx) {
		try {
			if (ctx == null) {
				ctx = new InitialContext();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getInfo2(String key) {
		try {
			return this.ctx.lookup(key) != null ? this.ctx.lookup(key).toString() : "";
		} catch (Exception e) {
			return "";

		}
	}

	public String getInfo(String key) {
		if (this.bundle != null) {
			return this.bundle.getString(key);
		}
		return null;
	}

	/**
	 * NSockClient
	 * @return
	 */
	public String getSnaIp() {
		return getInfo("cosmos.socket.ip");
	}

	/**
	 * NSockClient
	 * @return
	 */
	public Integer getSnaPort() {
		return ConvertUtils.str2Int(getInfo("cosmos.socket.port"));
	}

	/**
	 * efund
	 * @return
	 */
	public String getEfundIp() {
		return getInfo("efund.ip");
	}

	/**
	 * efund
	 * @return
	 */
	public Integer getEfundPort() {
		return ConvertUtils.str2Int(getInfo("efund.port"));
	}
}

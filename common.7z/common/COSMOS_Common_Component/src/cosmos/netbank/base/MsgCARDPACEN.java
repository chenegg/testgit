package cosmos.netbank.base;

public class MsgCARDPACEN extends MessageCodeAbstr {
	public static final String systemId = "CARDPACEN";

	public MsgCARDPACEN() {
		super(systemId);
	}
}

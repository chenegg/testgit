package cosmos.netbank.base;

import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class Crypto {
	private static byte[] key = { (byte) 0x01, (byte) 0x23, (byte) 0x45, (byte) 0x67, (byte) 0x89, (byte) 0xAB,
			(byte) 0xCD, (byte) 0xEF, //
										//
			(byte) 0x23, (byte) 0x45, (byte) 0x67, (byte) 0x89, (byte) 0xab, (byte) 0xcd, (byte) 0xef, (byte) 0x01, //
			(byte) 0x01, (byte) 0x23, (byte) 0x45, (byte) 0x67, (byte) 0x89, (byte) 0xAB, (byte) 0xCD, (byte) 0xEF }; //

	public static byte[] en(String s) {
		try {
			java.security.MessageDigest alga = java.security.MessageDigest.getInstance("SHA-1");

			alga.update(s.getBytes());
			byte[] digesta = alga.digest();

			return digesta;
		} catch (Exception e) {
			return null;

		}

	}

	public static String en(String s, String userid) {
		String temp = s + "&" + userid;
		byte[] b = en(temp);

		temp = byte2hex(b);

		return temp;

	}

	public static String byte2hex(byte[] b) {
		String hs = "";
		String stmp = "";
		for (int n = 0; n < b.length; n++) {
			if (!(n == 1 || n == 5 || n == 8 || n == 13 || n == 16))
				continue;
			stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1)
				hs = hs + "0" + stmp;
			else
				hs = hs + stmp;
			// if (n<b.length-1)
			// if(n==1 || n==5 || n==8 || n==13 || n==16) hs+="";
		}
		return hs.toUpperCase();
	}

	public static String endes(String str, String str1) {
		try {
			str = String.valueOf(Integer.parseInt(str.substring(str.length() - 8, str.length()))
					+ Integer.parseInt(str1));

			// 配合基金使用jdk1.3改用成Sun
			// Security.addProvider(new com.sun.crypto.provider.SunJCE());
			Security.addProvider(new sun.security.provider.Sun());

			Cipher cipher = Cipher.getInstance("DESede");
			SecretKey secKey = new SecretKeySpec(key, "DESede");
			cipher.init(Cipher.ENCRYPT_MODE, secKey);
			byte[] clearText = str.getBytes();
			byte[] cipherText = cipher.doFinal(clearText);
			return bytesToHex(cipherText);
		} catch (Exception e) {
			System.out.println(e.toString());
			return "";
		}

	}

	public static String dedes(String string1, String str) {
		try {
			// 配合基金使用jdk1.3改用成Sun
			// Security.addProvider(new com.sun.crypto.provider.SunJCE());
			Security.addProvider(new sun.security.provider.Sun());
			Cipher cipher = Cipher.getInstance("DESede");
			SecretKey secKey = new SecretKeySpec(key, "DESede");
			cipher.init(Cipher.DECRYPT_MODE, secKey);
			byte cipherText[] = new byte[str.length() / 2];
			for (int i = 0; i < str.length() / 2; i++) {
				cipherText[i] = (byte) Integer.parseInt(str.substring(i * 2, 2 + i * 2), 16);
			}
			byte[] clearText = cipher.doFinal(cipherText);
			String temp = new String(clearText);
			temp = String.valueOf(Integer.parseInt(temp)
					- Integer.parseInt(string1.substring(string1.length() - 8, string1.length())));
			return new String(temp);
		} catch (Exception e) {
			System.out.println(e.toString());
			return "";
		}

	}

	public static String bytesToHex(byte[] data) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < data.length; i++) {
			buf.append(byteToHex(data[i]).toUpperCase());
		}
		return (buf.toString());
	}

	public static String byteToHex(byte data) {
		StringBuffer buf = new StringBuffer();
		buf.append(toHexChar((data >>> 4) & 0x0F));
		buf.append(toHexChar(data & 0x0F));
		return buf.toString();
	}

	public static char toHexChar(int i) {
		if ((0 <= i) && (i <= 9)) {
			return (char) ('0' + i);
		} else {
			return (char) ('a' + (i - 10));
		}
	}
}

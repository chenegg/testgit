/*
 * @(#)	1.00, 30/6/2005
 *
 * Copyright 2005 KGI Bank, Inc. All rights reserved.
 * 開發者：凱基銀行 資訊處 陳柄岐.
 */
package cosmos.netbank.base;

import java.util.HashMap;
import java.util.Map;

public class MessageCode extends MessageCodeAbstr implements Messageable {

	public Map<String, String> ht;

	public static String SHOW_MESSAGE_CONTENT = "9999";
	/**
	 * 
	 * 主機response error
	 * 3009
	 */
	public static String SYSTEM_FAIL = "3009";
	/**
	 * 主機  return 1000
	 * 
	 * 
	 */
	public static String SYSTEM_ERROR = "1000";

	private static MessageCode mc;

	public MessageCode() {
		super();
		// MessageCodeAbstr m = new MessageCode();
		this.new GetMessageCodeXml(MsgPB.class);
		ht = new HashMap<String, String>();
		ht.putAll(super.getHT());
	}

	/**
	 * 
	 *  error發生
	 */
	public static String FAIL = "3005";
	private final static String xhtml = "<div id='Layer1' style='position:absolute; left:25px; top:140px; width:450px; height:50px; z-index:3'>";
	private final static String xhtmlfirst = "<div id='Layer1' style='position:absolute; left:220px; top:40px; width:497px; height:50px; z-index:3'>";
	private final static String xhtml1 = "<div id='Layer1' style='position:absolute; left:10px; top:140px; width:450px; height:50px; z-index:3'>";
	private final static String xhtml2 = "<div id='Layer1' style='position:absolute; left:25px; top:100px; width:450px; height:50px; z-index:3'>";
	private final static String xhtml3 = "<div id='Layer1' style='position:absolute; left:25px; top:20px; width:450px; height:50px; z-index:3'>";

	public String messageShow(String theResponse) {
		int getCode = Integer.parseInt(theResponse.substring(17, 21));
		return (getMessage(getCode));
	}

	// 傳errorcode的值
	// 加入html語法
	public String showMessage(String getCode) {
		try {
			int testInt = Integer.parseInt(getCode);
		} catch (NumberFormatException e) {
			getCode = "3009";
		}
		Object obj[] = { xhtml, getMessage(Integer.parseInt(getCode)) };
		return (new java.text.MessageFormat("{0}<div align='center'><span class='bluebold15'>{1}</span><br>")
				.format(obj));
	}

	// 加入html語法,沒有div語法
	public String showMessage1(String getCode) {
		try {
			int testInt = Integer.parseInt(getCode);
		} catch (NumberFormatException e) {
			getCode = "3009";
		}
		return ("<div align='center'><span class='bluebold15'>" + getMessage(Integer.parseInt(getCode))
				+ "</span><br>");
	}

	public String messageShow1(String code) {
		if (code == null || code.length() != 4)
			return code;
		int getCode = 0;
		try {
			getCode = Integer.parseInt(code);
		} catch (NumberFormatException e) {
			return code;
		}
		return (getMessage(getCode));
	}

	// 加入html語法
	public String showMessageTA(String getCode) {
		try {
			int testInt = Integer.parseInt(getCode);
		} catch (NumberFormatException e) {
			getCode = "3009";
		}
		Object obj[] = { xhtml2, getMessage(Integer.parseInt(getCode)) };
		return (new java.text.MessageFormat("{0}<div align='center'><span class='bluebold15'>{1}</span><br>")
				.format(obj));
	}

	// 加入html語法
	public String showMessage_NoAccount(String getString) {
		Object obj[] = { xhtml, getString };
		return (new java.text.MessageFormat(
				"{0}<div align='center'><span class='bluebold15'>抱歉，您未開立{1}帳戶<BR>不提供此項功能</span><br>").format(obj));
	}

	// menu的訊息
	// 加入html語法
	public String showMessage_first(String getCode) {
		try {
			int testInt = Integer.parseInt(getCode);
		} catch (NumberFormatException e) {
			getCode = "3009";
		}
		Object obj[] = { xhtmlfirst, getMessage(Integer.parseInt(getCode)) };
		return (new java.text.MessageFormat("{0}<div align='center'><span class='bluebold15'>{1}</span><br>")
				.format(obj));
	}

	public String showMessage_first2(String str) {
		Object obj[] = { xhtmlfirst, str };
		return (new java.text.MessageFormat("{0}<div align='center'><span class='bluebold15'>{1}</span><br>")
				.format(obj));
	}

	public String showMessage_status(String message) {
		Object obj[] = { xhtml1, message };
		return (new java.text.MessageFormat("{0}<div align='center'><span class='bluebold15'>{1}</span><br>")
				.format(obj));
	}

	public String showMessage_turnAccount(String message) {
		message = message.equals("    ") ? "轉帳完成" : getMessage(Integer.parseInt(message));
		Object obj[] = { xhtml3, message };
		return (new java.text.MessageFormat("{0}<div align='center'><span class='bluebold15'>{1}</span><br>")
				.format(obj));
	}

	public String getMessage(int Code) {
		return getMessage1(Code);
	}

	private static String getMessage1(int Code) {
		return "";

	}

	public static Object getCodeMessage(String s) {
		if (mc == null) {
			mc = new MessageCode();
		}
		try {
			return mc.ht.get(s);
		} catch (NumberFormatException e) {
			logger.error(e.getMessage(), e);
			return mc.ht.get(MessageCode.SYSTEM_FAIL);
		}
//		return mc.ht.get(s);
	}

	public static Object getCodeMessage(int number) {
		if (mc == null)
			mc = new MessageCode();
		return mc.ht.get(String.valueOf(number));
	}

	public static void resetMessageCode() {
		mc = new MessageCode();
	}

}
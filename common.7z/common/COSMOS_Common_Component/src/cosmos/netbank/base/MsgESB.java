package cosmos.netbank.base;

public class MsgESB extends MessageCodeAbstr {
	public static final String systemId = "ESB";

	public MsgESB() {
		super(systemId);
	}
}

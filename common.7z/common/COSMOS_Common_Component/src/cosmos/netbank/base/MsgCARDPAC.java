package cosmos.netbank.base;

public class MsgCARDPAC extends MessageCodeAbstr {
	public static final String systemId = "CARDPAC";

	public MsgCARDPAC() {
		super(systemId);
	}
}

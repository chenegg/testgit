package cosmos.netbank.base;

public class MsgDMS extends MessageCodeAbstr {
	public static final String systemId = "DMS";

	public MsgDMS() {
		super(systemId);
	}
}

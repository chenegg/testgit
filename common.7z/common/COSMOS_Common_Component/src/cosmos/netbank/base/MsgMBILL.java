package cosmos.netbank.base;

public class MsgMBILL extends MessageCodeAbstr {
	public static final String systemId = "MBILL";

	public MsgMBILL() {
		super(systemId);
	}
}

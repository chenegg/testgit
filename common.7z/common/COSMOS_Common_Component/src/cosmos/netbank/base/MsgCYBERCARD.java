package cosmos.netbank.base;

public class MsgCYBERCARD extends MessageCodeAbstr {
	public static final String systemId = "CYBERCARD";

	public MsgCYBERCARD() {
		super(systemId);
	}
}

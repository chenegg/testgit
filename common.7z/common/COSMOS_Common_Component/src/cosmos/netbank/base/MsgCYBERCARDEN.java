package cosmos.netbank.base;

public class MsgCYBERCARDEN extends MessageCodeAbstr {
	public static final String systemId = "CYBERCARDEN";

	public MsgCYBERCARDEN() {
		super(systemId);
	}
}

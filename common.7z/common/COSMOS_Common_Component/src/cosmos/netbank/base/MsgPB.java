package cosmos.netbank.base;

public class MsgPB extends MessageCodeAbstr {
	public static final String systemId = "PB";

	public MsgPB() {
		super(systemId);
	}
}

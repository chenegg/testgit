package cosmos.netbank.base;

public class MsgFUNDAP extends MessageCodeAbstr { 
	public static final String systemId = "FUNDAP";

	public MsgFUNDAP() {
		super(systemId);
	}
}

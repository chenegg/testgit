package cosmos.netbank.base;

public class MsgWBF extends MessageCodeAbstr {
	public static final String systemId = "WBF";

	public MsgWBF() {
		super(systemId);
	}
}

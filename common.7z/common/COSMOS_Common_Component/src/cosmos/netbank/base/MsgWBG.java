package cosmos.netbank.base;

public class MsgWBG extends MessageCodeAbstr {
	public static final String systemId = "WBG";

	public MsgWBG() {
		super(systemId);
	}
}

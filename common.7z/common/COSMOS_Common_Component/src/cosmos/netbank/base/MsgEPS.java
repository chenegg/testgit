package cosmos.netbank.base;

public class MsgEPS extends MessageCodeAbstr {
	public static final String systemId = "EPS";

	public MsgEPS() {
		super(systemId);
	}
}

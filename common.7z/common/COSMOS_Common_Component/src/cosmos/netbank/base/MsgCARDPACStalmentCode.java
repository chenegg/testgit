package cosmos.netbank.base;

public class MsgCARDPACStalmentCode extends MessageCodeAbstr {
	public static final String systemId = "CARDPACSTALMENTCODE";

	public MsgCARDPACStalmentCode() {
		super(systemId);
	}
}

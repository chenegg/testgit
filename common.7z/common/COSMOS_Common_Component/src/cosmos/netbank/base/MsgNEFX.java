package cosmos.netbank.base;

public class MsgNEFX extends MessageCodeAbstr {
	public static final String systemId = "NEFX";

	public MsgNEFX() {
		super(systemId);
	}
}

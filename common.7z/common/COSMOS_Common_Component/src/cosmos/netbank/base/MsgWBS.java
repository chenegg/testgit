package cosmos.netbank.base;

public class MsgWBS extends MessageCodeAbstr {
	public static final String systemId = "WBS";

	public MsgWBS() {
		super(systemId);
	}
}

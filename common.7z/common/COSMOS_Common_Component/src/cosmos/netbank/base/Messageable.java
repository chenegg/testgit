/*
 * @(#)	1.00, 30/6/2005
 *
 * Copyright 2005 KGI Bank, Inc. All rights reserved.
 * 開發者：凱基銀行 資訊處 陳柄岐.
 */
package cosmos.netbank.base;

/** 
 *  
 * 定義messageCode和訊息
 *
 * @version 	1.00, 30/6/2005
 * @author	陳柄岐
 * @since	
 */
public interface Messageable {
	public String messageShow(String theResponse);

	public String showMessage(String getCode);

	public String showMessage1(String getCode);

	public String messageShow1(String code);

	public String showMessageTA(String getCode);

	public String showMessage_NoAccount(String getString);

	public String showMessage_first(String getCode);

	public String showMessage_first2(String getCode);

	public String showMessage_status(String message);

	public String showMessage_turnAccount(String message);

	public String getMessage(int Code);
}
package cosmos.netbank.base;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.ParserAdapter;

import com.ibm.tw.commons.util.StringUtils;

public abstract class MessageCodeAbstr {

	protected static Logger logger = LoggerFactory.getLogger(MessageCodeAbstr.class);

	/**
	 * 訊息檔
	 */
	private Map<String, String> ht;

	protected Map<String, String> getHT() {
		return ht;
	}

	public MessageCodeAbstr() {
		load();
	}

	/**
	 * Add By Egg
	 * 
	 * @param systemId
	 */
	public MessageCodeAbstr(String systemId) {
		// MessageCodeAbstr m = new MessageCode();
		/** 將xml載入 **/
		this.new GetMessageCodeXml(this.getClass().getSimpleName());
		load();
	}

	protected void load() {
	}

	/** 將xml載入 **/
	protected class GetMessageCodeXml extends DefaultHandler {
		protected GetMessageCodeXml(MessageCodeAbstr m) {
			this(m.getClass().getSimpleName());
		}

		protected GetMessageCodeXml(Class<?> clazz) {
			this(clazz.getSimpleName());
		}

		private GetMessageCodeXml(String filename) {
			try {
				String urlString = "config/" + filename + ".xml";
				ht = new HashMap<String, String>();
				this.processWithSAX(urlString);
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}

		public void startDocument() throws SAXException {
			// logger.debug("START MessageParkingCode XML DOCUMENT");
		}

		public void endDocument() throws SAXException {
			// logger.debug("END MessageParkingCode XML DOCUMENT");
		}

		public void startElement(String namespace, String localName, String qName, Attributes atts)
				throws SAXException {
			/** 實際放值的地方開始 **/
			if (localName != null && localName.equals("status")) {
				ht.put(atts.getValue("code"), atts.getValue("description"));
			}
		}

		public void characters(char[] ch, int start, int length) throws SAXException {
		}

		public void endElement(String namespace, String localName, String qname) {
		}

		public void processWithSAX(String urlString) throws Exception {

			try {
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				ParserAdapter pa = new ParserAdapter(sp.getParser());
				pa.setContentHandler(this);
				InputStream input = null;
				try {
					input = MessageCodeAbstr.class.getClassLoader().getResourceAsStream(urlString);
				} catch (Exception e) {
					 e.printStackTrace();
				}

				if (input == null) {
					urlString = "META-INF/" + urlString;
					/** 相容,不用每個專案都放 **/
					input = MessageCodeAbstr.class.getClassLoader().getResourceAsStream(urlString);
				}

				pa.parse(new InputSource(input));
			} catch (Exception e) {
				// logger.error(e.getMessage());
				e.printStackTrace();
				throw new Exception("請檢查XML格式\n" + e.getMessage() + "urlString=" + urlString);
			}
		}
	}

	private static Map<String, MessageCodeAbstr> messageList = new HashMap<String, MessageCodeAbstr>();

	static {
		/****/
		// synchronized (messageList) {
		register(MsgGM.systemId, new MsgGM());
		register(MsgESB.systemId, new MsgESB());
		register(MsgCICS.systemId, new MsgCICS());
		register(MsgPB.systemId, new MsgPB());
		register(MsgCARDPAC.systemId, new MsgCARDPAC());
		register(MsgCARDPACEN.systemId, new MsgCARDPACEN());
		// register(MsgCARDPAC.systemId, new MsgCARDPAC());
		register(MsgEPS.systemId, new MsgEPS());
		register(MsgBNS.systemId, new MsgBNS());
		register(MsgCARDPACStalmentCode.systemId, new MsgCARDPACStalmentCode());
		register(MsgNEFX.systemId, new MsgNEFX());
		register(MsgFEP.systemId, new MsgFEP());
		register(MsgSBS.systemId, new MsgSBS());
		register(MsgMBILL.systemId, new MsgMBILL());
		register(MsgWBS.systemId, new MsgWBS());
		register(MsgWBF.systemId, new MsgWBF());
		register(MsgWBG.systemId, new MsgWBG());
		register(MsgFUNDAP.systemId, new MsgFUNDAP());
		register(MsgDMS.systemId, new MsgDMS());
		register(MsgCYBERCARD.systemId, new MsgCYBERCARD());
		register(MsgCYBERCARDEN.systemId, new MsgCYBERCARDEN());
		// }
	}

	/**
	 * 註冊
	 * 
	 * @param systemId
	 * @param mca
	 */
	public static synchronized void register(String systemId, MessageCodeAbstr mca) {
		messageList.put(systemId, mca);
	}

	/**
	 * 移除
	 * 
	 * @param systemId
	 */
	public static synchronized void unregister(String systemId) {
		messageList.remove(systemId);
	}

	public static synchronized String getMessage(String systemId, String code) {
		MessageCodeAbstr messageCodeAbstr = messageList.get(StringUtils.upperCase(systemId));
		// System.out.println(messageCodeAbstr);
		if (messageCodeAbstr == null) {
			return "??" + systemId + "-" + code + "??";
		} else {
			if (messageCodeAbstr.ht == null) {
				return "??" + systemId + "-" + code + "??";
			}
			String result = messageCodeAbstr.ht.get(code);
			return StringUtils.defaultIfEmpty(result, "");
		}
	}
}

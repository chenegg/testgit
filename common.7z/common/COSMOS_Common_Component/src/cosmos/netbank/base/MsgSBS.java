package cosmos.netbank.base;

public class MsgSBS extends MessageCodeAbstr {
	public static final String systemId = "SBS";

	public MsgSBS() {
		super(systemId);
	}
}

package cosmos.netbank.base;

public class MsgBNS extends MessageCodeAbstr {
	public static final String systemId = "BNS";

	public MsgBNS() {
		super(systemId);
	}
}

package cosmos.netbank.base;

public class MsgGM extends MessageCodeAbstr {
	public static final String systemId = "GM";

	public MsgGM() {
		super(systemId);
	}
}

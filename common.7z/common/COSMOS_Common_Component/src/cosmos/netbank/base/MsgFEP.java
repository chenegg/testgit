package cosmos.netbank.base;

public class MsgFEP extends MessageCodeAbstr {
	public static final String systemId = "FEP";

	public MsgFEP() {
		super(systemId);
	}
}

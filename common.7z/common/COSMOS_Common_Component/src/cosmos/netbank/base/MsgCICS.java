package cosmos.netbank.base;

import java.util.Map;

public class MsgCICS extends MessageCodeAbstr {
	public static final String systemId = "CICS";
	public Map<String, String> ht;

	public MsgCICS() {
		super(systemId);
	}
}

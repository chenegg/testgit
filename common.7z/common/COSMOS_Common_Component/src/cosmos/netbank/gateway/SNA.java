package cosmos.netbank.gateway;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ibm.tw.commons.util.ConvertUtils;
import com.kgi.netbank.config.CacheManager;

/**
 * 
 * 目前設定完，要重新啟動service才會生效。暫不提供立即生效
 * 
 * @author bcchen
 *
 */
public class SNA extends CacheManager {
    // private static NetBankLog netbanklog = new
    // NetBankLog(SNA.class.getName());
    private static Logger logger = LoggerFactory.getLogger(SNA.class);
    public final static int CICSP3 = 1;
    public final static int CICSP7 = 2;
    public final static int CICSQ3 = 3;

    @Override
    public void load() throws Exception {
        if (properties == null) {
            synchronized (this) {
                /** 先抓config底下的,當預留找不到改抓tomcat下 **/
                if (properties == null) {
                    properties = loadFile(CONTEXT_REAL_CONFIG_PATH, "sna.xml");
                }
            }
        }
    }

    public SNA() throws Exception {
        load();
        SNA_CICSP1_IP = getString("SNA_CICSP1_IP");
        SNA_CICSP1_PORT = getString("SNA_CICSP1_PORT");
        SNA_CICSP1B_IP = getString("SNA_CICSP1B_IP");
        SNA_CICSP1B_PORT = getString("SNA_CICSP1B_PORT");
        SNA_CICSP3_IP = getString("SNA_CICSP3_IP");
        SNA_CICSP3_PORT = getString("SNA_CICSP3_PORT");
        SNA_CICSP7_IP = getString("SNA_CICSP7_IP");
        SNA_CICSP7_PORT = getString("SNA_CICSP7_PORT");
        SNA_CICSQ3_IP = getString("SNA_CICSQ3_IP");
        SNA_CICSQ3_PORT = getString("SNA_CICSQ3_PORT");

        SNA_CSR_IP = getString("SNA_CSR_IP");
        SNA_CSR_PORT = getString("SNA_CSR_PORT");

        if (StringUtils.isBlank(SNA_CICSP1_IP))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP1_IP】設定失敗1");
        if (StringUtils.isBlank(SNA_CICSP1_PORT))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP1_PORT】設定失敗2");
        if (StringUtils.isBlank(SNA_CICSP1B_IP))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP1B_IP】設定失敗1B");
        if (StringUtils.isBlank(SNA_CICSP1B_PORT))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP1B_PORT】設定失敗2B");
        if (StringUtils.isBlank(SNA_CICSP3_IP))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP3_IP】設定失敗3");
        if (StringUtils.isBlank(SNA_CICSP3_PORT))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP3_PORT】設定失敗4");
        if (StringUtils.isBlank(SNA_CICSP7_IP))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP7_IP】設定失敗5");
        if (StringUtils.isBlank(SNA_CICSP7_PORT))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSP7_PORT】設定失敗6");
        if (StringUtils.isBlank(SNA_CICSQ3_IP))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSQ3_IP】設定失敗7");
        if (StringUtils.isBlank(SNA_CICSQ3_PORT))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CICSQ3_PORT】設定失敗8");
        if (StringUtils.isBlank(SNA_CSR_IP))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CSR_IP】設定失敗9");
        if (StringUtils.isBlank(SNA_CSR_PORT))
            throw new cosmos.netbank.NetBankException("SNA【SNA_CSR_PORT】設定失敗10");

        // 檢查ip
        // 檢查port

        SNA_CICSP1_PORT_I = Integer.parseInt(SNA_CICSP1_PORT);
        SNA_CICSP1B_PORT_I = Integer.parseInt(SNA_CICSP1B_PORT);
        Integer.parseInt(SNA_CICSP3_PORT);
        Integer.parseInt(SNA_CICSP7_PORT);
        Integer.parseInt(SNA_CICSQ3_PORT);
        Integer.parseInt(SNA_CSR_PORT);

        logger.warn("網路銀行 SNA OK");
        // } catch (Exception e) {
        // e.printStackTrace();
        // logger.error("▼▼▼▼沒取得sna set", e);
        // }

    }

    // 設 default 存取
    private static String SNA_CICSP1_IP = "";

    private static Integer SNA_CICSP1_PORT_I = null;

    // 設 default
    static String SNA_CICSP1_PORT = "";

    static String SNA_CICSP1B_IP = "";
    // 設 default
    static String SNA_CICSP1B_PORT = "";
    static int SNA_CICSP1B_PORT_I;
    // 設 default
    static String SNA_CICSP3_IP = "";
    // 設 default
    static String SNA_CICSP3_PORT = "";
    // 設 default
    static String SNA_CICSP7_IP = "";
    // 設 default
    static String SNA_CICSP7_PORT = "";
    // 設 default
    static String SNA_CICSQ3_IP = "";
    // 設 default
    static String SNA_CICSQ3_PORT = "";

    private static String SNA_CSR_IP = "";
    private static String SNA_CSR_PORT = "";

    public static String get(String vb, int route) {
        String sna_ip = "";
        String sna_port = "";
        switch (route) {
            case CICSP3:
                sna_ip = SNA_CICSP3_IP;
                sna_port = SNA_CICSP3_PORT;
                break;
            case CICSP7:
                sna_ip = SNA_CICSP7_IP;
                sna_port = SNA_CICSP7_PORT;
                break;
            case CICSQ3:
                sna_ip = SNA_CICSQ3_IP;
                sna_port = SNA_CICSQ3_PORT;
                break;
        }

        String string = "";
        try {
            SNASocket ss = new SNASocket(sna_ip, sna_port);
            ss.setTIA(vb);
            string = ss.session();

            try {
                ss.close();
                ss = null;
            } catch (Exception e) {
                logger.error("ss1:" + e.toString(), e);
            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error("ss2:" + e.toString(), e);
        }

        return string;

    }

    public static String getSNA_CICSP1_IP() {
        if (StringUtils.isBlank(SNA_CICSP1_IP)) {
            SNA_CICSP1_IP = getSNA().getString("SNA_CICSP1_IP");
        }
        return SNA_CICSP1_IP;
    }

    public static String getSNA_CICSP1_PORT() {
        if (StringUtils.isBlank(SNA_CICSP1_PORT)) {
            SNA_CICSP1_PORT = getSNA().getString("SNA_CICSP1_PORT");
        }
        return SNA_CICSP1_PORT;
    }

    public static int getSNA_CICSP1_PORT_I() {
        if (SNA_CICSP1_PORT_I == null) {
            SNA_CICSP1_PORT_I = ConvertUtils.str2Int(getSNA_CICSP1_PORT());
        }
        return SNA_CICSP1_PORT_I;
    }

    public static String getSNA_CSR_IP() {
        return SNA_CSR_IP;
    }

    public static String getSNA_CSR_PORT() {
        return SNA_CSR_PORT;
    }

}

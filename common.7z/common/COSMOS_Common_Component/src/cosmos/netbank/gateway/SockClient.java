package cosmos.netbank.gateway;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SockClient {
	private static final String LOG_TITLE_1 = "#SNALOG_20141207002 ";
	private static final String LOG_TITLE_ERR = "#ERRLOG_20141207002 ";
	private static Logger logger = LoggerFactory.getLogger(SockClient.class);
	private static String url = SNA.getSNA_CICSP1_IP();
	private static int port = SNA.getSNA_CICSP1_PORT_I();
	private Socket connection;
	private BufferedReader br;
	private PrintStream ps;
	private String sendbuffer;
	private int pNum;
	public boolean status = true;

	public SockClient(int pNum) {
		this.pNum = pNum;
	}

	public synchronized void setTIA() {
		long begin = System.currentTimeMillis();
		try {
			initial();
			String msg = "【" + (System.currentTimeMillis() - begin) + " ms. " + "】" + LOG_TITLE_1 + "  " + "\n";
			logger.info("........" + msg);
		} catch (IOException e) {
			logger.error("Unable to connect server");
			String errmsg = LOG_TITLE_ERR + "  " + "\n";
			errmsg += "connection server failure. execute , setTIA( ) ... ";
			errmsg += (System.currentTimeMillis() - begin) + " ms. \n";
			errmsg += e.getMessage();
			logger.error(errmsg, e);
		}
	}

	private static boolean isChange = true;
	private boolean bool = true;
	// private int number = 0;
	// private static boolean isChangeServer = false;

	private void initial() throws IOException {
		SocketAddress sa = new InetSocketAddress(url, port);
		connection = new Socket();
		connection.setSoTimeout(30000);
		connection.connect(sa, 30000);
		br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		ps = new PrintStream(connection.getOutputStream());
	}

	public synchronized void setTIA(String str) {
		status = false;
		long begin = System.currentTimeMillis();
		// if (isChangeServer) { // for 切換到另一台
		// number++;
		// if (number >= 3) {
		// number = 0;
		// setTIA2(str, 0);
		// }
		// }
		try {
			sendbuffer = str + "~T12";
			initial();
			String msg = "【" + (System.currentTimeMillis() - begin) + " ms. " + "】" + LOG_TITLE_1 + "  " + "\n";
			logger.info("........" + msg);
		} catch (IOException e) {
			String errmsg = LOG_TITLE_ERR + str + "\n";
			errmsg += "connection server failure. execute , setTIA(String str) reconnect.... ";
			errmsg += (System.currentTimeMillis() - begin) + " ms. \n";
			errmsg += e.getMessage();
			logger.error(errmsg, e);
			/**Add by Egg 當連線失敗時,不管如何先結束連線在會重新連線**/
			closeConnection();
			int temp = (int) (Math.random() * 999999); // for trace
			if (isChange) {
				if (bool) {
					bool = false;
					setTIA1(str, temp);
				} else {
					bool = true;
					setTIA2(str, temp);
				}
			}
		}
	}

	private synchronized void setTIA1(String str, int temp) {
		status = false;
		long begin = System.currentTimeMillis();
		try {
			sendbuffer = str + "~T12";
			initial();
			String msg = LOG_TITLE_1 + str + "\n";
			msg += "connection server success. execute ";
			msg += (System.currentTimeMillis() - begin) + " ms. ";
			logger.info("........" + msg);
		} catch (IOException e) {
			String errmsg = LOG_TITLE_ERR + str + "\n";
			errmsg += "connection server failure. execute , reconnect.... ";
			errmsg += (System.currentTimeMillis() - begin) + " ms. \n";
			errmsg += e.getMessage();
			logger.error(errmsg, e);
			if (e.toString().indexOf("timed") >= 0) {
				/**Add by Egg 當連線失敗時,不管如何先結束連線在會重新連線**/
				closeConnection();
				setTIA2(str, temp);
			}
		}
	}

	private synchronized void setTIA2(String str, int temp) {
		status = false;
		long begin = System.currentTimeMillis();
		try {
			sendbuffer = str + "~T12";
			initial();
			String msg = LOG_TITLE_1 + str + "\n";
			msg += "connection server success. execute ";
			msg += (System.currentTimeMillis() - begin) + " ms. ";
			logger.info("........" + msg);
		} catch (IOException e) {
			String errmsg = LOG_TITLE_ERR + str + "\n";
			errmsg += "connection server failure. execute , setTIA2.... ";
			errmsg += (System.currentTimeMillis() - begin) + " ms. \n";
			errmsg += e.getMessage();
			logger.error(errmsg, e);
		}
	}

	public synchronized String setTIAlogin(String str) {
		status = false;
		String message = "";
		long begin = System.currentTimeMillis();
		try {
			sendbuffer = str;
			initial();
			String msg = LOG_TITLE_1 + str + "\n";
			msg += "connection server success. execute ";
			msg += (System.currentTimeMillis() - begin) + " ms. ";
			logger.info("........" + msg);
		} catch (IOException e) {
			int temp = (int) (Math.random() * 999999); // for trace
			String errmsg = LOG_TITLE_ERR + str + "\n";
			errmsg += "Unable to connect server4. execute , setTIAlogin reconnect setTIA2.... ";
			errmsg += (System.currentTimeMillis() - begin) + " ms. \n";
			errmsg += e.getMessage();
			logger.error(errmsg, e);
			message = "3009";
			setTIA2(str, temp);
		}
		return (message);
	}

	public synchronized String session() throws IOException {
		char charBuffer[] = new char[3000];
		int readCount = 0;
		String recedata = "";
		try {
			ps.print(sendbuffer);
			ps.flush();
			/**【★】**/
			try {
				Thread.sleep(1000L);
				/**防止封包不見,以後會改到ESB中**/
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
			}

			sendbuffer = null;
			while ((readCount = br.read(charBuffer, 0, 3000)) != -1) {
				recedata = new String(charBuffer, 0, readCount);
				if (recedata.length() != 0)
					break;
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			throw e;
		} finally {
			closeConnection();
		}
		status = true;
		return recedata;
	}

	public synchronized String session(String sendbuffer, int strlen) throws IOException {
		char charBuffer[] = new char[3000];
		int readCount;
		String recedata = "";
		try {
			byte sendbyte[] = sendbuffer.getBytes();
			ps.write(sendbyte, 0, strlen);
			ps.flush();
			/**【★】**/
			try {
				Thread.sleep(1000L);
				/**防止封包不見,以後會改到ESB中**/
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
			}
			sendbuffer = null;
			do {
				readCount = br.read(charBuffer, 0, 3000);
				recedata = new String(charBuffer, 0, readCount);
				logger.info("readCount=" + readCount);
				logger.info("socketresponse:" + recedata);
			} while (readCount == -1);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			throw e;
		} finally {
			closeConnection();
		}
		return recedata;
	}

	/**
	 * 關閉連線
	 */
	private void closeConnection() {
		if (ps != null) {
			ps.close();
		}
		if (br != null) {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (connection != null) {
			try {
				connection.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void set(int i) {
	}
}

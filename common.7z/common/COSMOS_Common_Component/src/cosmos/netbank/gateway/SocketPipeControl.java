/*
 * @(#)	1.00, 30/6/2005
 *
 * Copyright 2005 KGI Bank, Inc. All rights reserved.
 * 開發者：凱基銀行 資訊處 陳柄岐.
 */
package cosmos.netbank.gateway;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cosmos.ebank.util.CosmosException;

/**
 * 建立Socket的管道
 * 
 * @version 1.00, 30/6/2005
 * @author 陳柄岐
 * @since JDK1.2
 */
public class SocketPipeControl {
	protected String CONVERT_CHINESE_SITE = "~D22,40D";

	private static Logger logger = LoggerFactory.getLogger(SocketPipeControl.class);

	// private static NetBankLog netbanklog = new
	// NetBankLog(SocketPipeControl.class.getName());
	private final static int pn = 5; // 建立5條通道，對應his 的5條通道。

	private static SockClient theLUA[] = new SockClient[pn];

	private String errorCode = "";

	private String theResponse = "";

	private static boolean status = true;

	public SocketPipeControl() {
		setSocket();
	}

	public static java.util.ArrayList viewStatus() {
		java.util.ArrayList al = new java.util.ArrayList();
		for (int i = 0; i < pn; i++) {
			String msg = "" + i + ":" + theLUA[i].status;
			al.add(msg);
			logger.info(msg);
		}
		return al;
	}

	private static void setSocket() {
		if (!status)
			return;
		for (int i = 0; i < pn; i++)
			theLUA[i] = new SockClient(i);
		status = false;
	}

	public void setStatus(boolean bool) {
		for (int j = 0; j < theLUA.length; j++)
			theLUA[j].status = bool;
	}

	private static int point1[] = new int[pn];

	public String getVbString(String vbstring) {
		String theResponse = "";
		String txnId = StringUtils.EMPTY;
		if ("OA".equals(StringUtils.substring(vbstring, 0, 2)))
			txnId = vbstring.substring(0, 4);
		else if ("~D".equals(StringUtils.substring(vbstring, 0, 2))) {
			txnId = StringUtils.substring(vbstring, 21, 25);
		} else {
			txnId = StringUtils.substring(vbstring, 13, 17);
		}

		try {
			logger.info(">>>>>>【SYSTEMID=" + txnId + "】" + vbstring);
			SockClient sc = new SockClient(9); // 9數字，沒有特別用意
			sc.setTIA(vbstring);
			theResponse = sc.session();
			sc = null;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
		logger.info("<<<<<<【SYSTEMID=" + txnId + "】" + theResponse);
		return (theResponse);
	}

	private static int point2[] = new int[pn];

	/**
	 * OA02
	 * @param vbstring
	 * @return
	 * @throws CosmosException 
	 */
	public String getVblogin(String vbstring) throws CosmosException {

		String txnId = StringUtils.EMPTY;
		if ("OA".equals(StringUtils.substring(vbstring, 0, 2)))
			txnId = StringUtils.substring(vbstring, 0, 4);
		else if ("~D".equals(StringUtils.substring(vbstring, 0, 2))) {
			txnId = StringUtils.substring(vbstring, 21, 25);
		} else {
			txnId = StringUtils.substring(vbstring, 13, 17);
		}

		String theResponse = "";
		try {
			logger.info(">>>>>>【SYSTEMID=" + txnId + "】" + vbstring);
			SockClient sc = new SockClient(9); // 9數字，沒有特別用意
			sc.setTIA(vbstring);
			theResponse = sc.session();
			sc = null;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			throw new CosmosException(e.getMessage(), e);
		}
		logger.info("<<<<<<【SYSTEMID=" + txnId + "】" + theResponse);
		return (theResponse);
	}

	public String getError() {
		return (errorCode);
	}
}
package cosmos.netbank.gateway;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 *	Modify:
 *   OA301059-1021200655-修改信用卡主機與網銀對未出帳明細無法顯示問題new char[3000] --> new char[5000]
 * 
 * @version 1.00, 30/6/2005
 * @author 陳柄岐
 * @since JDK1.2
 * @see SNASocket
 */
class SNASocket {

	// private static NetBankLog netbanklog = new NetBankLog(SNASocket.class);
	private static Logger logger = LoggerFactory.getLogger(SNASocket.class);

	private static final String LOG_TITLE_1 = "#SNALOG_20141207001 ";
	private static final String LOG_TITLE_ERR = "#ERRLOG_20141207001 ";

	public String ip = "";

	public int port;

	private Socket socket;

	private BufferedReader br;

	private PrintStream ps;

	private String sendbuffer;

	SNASocket(String ip, int port) {
		this.ip = ip;
		this.port = port;
	}

	SNASocket(String ip, String port) {
		this.ip = ip;
		this.port = Integer.parseInt(port);
	}

	/**
	 * 
	 * send 電文
	 * 
	 * @return
	 */

	public void setTIA(String str) {
		// Date system = new Date();
		long begin = System.currentTimeMillis();
		try {
			sendbuffer = str;
			// socket = new Socket(ip, port);

			// new add
			SocketAddress sa = new InetSocketAddress(ip, port);
			socket = new Socket();
			socket.setSoTimeout(30000);
			socket.connect(sa, 30000);
			// new add end

			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			ps = new PrintStream(socket.getOutputStream());

			String msg = "ip=" + ip + "port=" + port + ">>>>>>>" + LOG_TITLE_1 + str + "\n";
			msg += "connection server success. execute ";
			msg += (System.currentTimeMillis() - begin) + " ms. ";
			logger.info(msg);
		} catch (IOException e) {
			String errmsg = LOG_TITLE_ERR + str + "\n";
			errmsg += "connection server failure. execute ";
			errmsg += (System.currentTimeMillis() - begin) + " ms. \n";
			errmsg += e.getMessage();
			logger.error(errmsg, e);
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * get下行電文
	 * 
	 * @return
	 */

	public String session() {
		char charBuffer[] = new char[5000];
		int readCount = 0;
		String recedata = "";
		String temp = "";
		try {
			if (sendbuffer.substring(0, 2).equals("OA"))
				temp = sendbuffer.substring(0, 4);
			else if (sendbuffer.substring(0, 2).equals("~D"))
				temp = sendbuffer.substring(21, 25);
			else
				temp = sendbuffer.substring(13, 17);
			logger.info("begin send string to host..........." + temp);
			ps.print(sendbuffer);
			ps.flush();
			
			try {
				Thread.sleep(1200L);
				/**防止封包不見,以後會改到ESB中**/
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
			}
			
			sendbuffer = null;
			while ((readCount = br.read(charBuffer, 0, 5000)) != -1) {
				recedata = new String(charBuffer, 0, readCount);
				if (recedata.length() != 0)
					break;
			}

		} catch (IOException e) {
			logger.error("sock error..." + e.toString(), e);
		} finally {
			if (ps != null) {
				ps.close();
			}

			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (socket != null) {
				try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		logger.info("<<<<<<<<<<<<<" + temp + "receive ok" + recedata);
		return recedata;
	}

	public void get() {

	}

	public void close() {
		try {
			if (ps != null)
				ps.close();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}
		try {
			if (br != null)
				br.close();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}
		try {
			if (socket != null)
				socket.close();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}

	public void destroy() {
		close();
	}

}

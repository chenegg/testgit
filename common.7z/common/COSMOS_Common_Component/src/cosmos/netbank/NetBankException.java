/*
 * @(#)	1.00, 30/6/2005
 *
 * Copyright 2005 KGI Bank, Inc. All rights reserved.
 * 開發者：凱基銀行 資訊處 陳柄岐.
 */

package cosmos.netbank;

/**
 * 
 * 
 * 
 * 
 * @version 1.00, 30/6/2005
 * @author 凱基銀行 資訊處 陳柄岐
 */

/*
 * 
 * 
 */
public class NetBankException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NetBankException() {
		super();
	}

	public NetBankException(String s) {
		super(s);

	}

}

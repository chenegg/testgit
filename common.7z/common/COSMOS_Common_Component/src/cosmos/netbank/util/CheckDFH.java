/**
 * 
 * 最前端檢查主機回傳電文
 * 對應出Message Code
 * 使頁面得以顯示正確的訊息
 * 
 * @(#)	1.00, 2013/06/20
 * @author Cris
 */
package cosmos.netbank.util;

import java.util.HashMap;
import java.util.Map;

public class CheckDFH {
	
	private static Map<String,String> codeMap = new HashMap<String,String>();
	
	static {
		codeMap.put("OA07","8888");
	}
	
	/**
	 * TODO:
	 * @param content
	 * @return
	 */
//	public static String getMessageCode(String content) {
//		if(content == null || content.length() < 4) return "";
//		if(content.startsWith("DFH")) {
//			if(content.indexOf("OA07") > 0) {
//				return "8888";
//			}
//		}
//		return "";
//	}

	/**
	 * 當下行電文含 DFH(比如主機正在重開時)
	 * 因為此時上行電文只到VTAM，沒有到主機，所以無法回應錯誤代碼
	 * 這裡根據「電文名稱」，回傳對應的「錯誤代碼」
	 * 「錯誤代碼」由 「codeMap」決定
	 * @param content
	 * @param transName
	 * @return
	 */
	public static String getMessageCode(String content,String transName) {
		if(content == null || content.length() < 4) return "";
		if(content.startsWith("DFH")) {
			return codeMap.get(transName);
		}
		return "";
	}

}

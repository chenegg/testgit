package cosmos.netbank.util;

import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

public class RegularExpressionUtil {
	
	//private final static Pattern NATURE_NUMBER_PATTERN = Pattern.compile("^(0|[1-9][0-9]*)$");
	private final static Pattern NATURE_NUMBER_PATTERN = Pattern.compile("^([0-9]*)$");
	
	public static boolean isNatureNumber(String vaule){		
		if(StringUtils.isNotBlank(vaule)){
			//驗證數值
			return NATURE_NUMBER_PATTERN.matcher(vaule).matches() ;
		}		
		return false ;
	}
	
	public static boolean isNatureNumber2(String vaule){
		
		return NATURE_NUMBER_PATTERN.matcher(vaule).matches() ;
	}

}

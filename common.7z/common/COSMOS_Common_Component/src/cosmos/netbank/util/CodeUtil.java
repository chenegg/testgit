package cosmos.netbank.util;

import org.apache.commons.lang.StringUtils;

public class CodeUtil {
	
//	public static String QUICK = "30" ;
//	public static String SLOW  = "18" ;
	
	private static int ACCOUNT_LENGTH = 6 ;
	
	/**
	 * 電文取出的中文需要轉碼
	 * @param str
	 * @return
	 * @throws Exception
	 */
	public static String fetchChinese(String str) throws Exception {
		String newStr = "";
		if (str != null) {
			str = new String(str.getBytes("8859_1"));
			for (int i = 0; i < str.length(); i++)
				if (!str.substring(i, i + 1).equals("　"))
					newStr += str.substring(i, i + 1);
			newStr = newStr.replaceAll("'", "").replaceAll("@", "")
					.replaceAll(" ", "");
		}
		return newStr;
	}
	
	/**
	 * 驗證帳號 是否為空或是 null 或是有非數值
	 * @param account
	 * @return
	 */
	public static boolean validAccount(String account){
		if(StringUtils.isNotBlank(account)){
			if(account.length() <= ACCOUNT_LENGTH){
				return false ;
			}
			return RegularExpressionUtil.isNatureNumber2(account) ;
		}
		return false ;
	}
	
	public static boolean checkType(String account,String type){
		
		return StringUtils.equals(account.substring(3,5), type) ;
		
	}

}

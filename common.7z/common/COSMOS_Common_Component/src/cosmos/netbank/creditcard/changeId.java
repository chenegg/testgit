package cosmos.netbank.creditcard;

public class changeId {

	public String Encode(String id) {
		if (id.length() != 10)
			return id;

		id = id.toUpperCase();
		if (Character.isLetter(id.charAt(9))) {
			String step0 = id.substring(0, 8) + getChar(id.charAt(8)) + getChar(id.charAt(9));
			String step1 = getHash(step0);
			String step2 = getComplement(step1) + step0.charAt(11);
			return step2;
		}

		if (Character.isLetter(id.charAt(1))) {
			String step0 = getChar(id.charAt(0)) + getChar(id.charAt(1)) + id.substring(2, 10);
			String step1 = getHash(step0);
			String step2 = getComplement(step1) + step0.charAt(11);
			return step2;
		}

		char c = id.charAt(0);
		int ii = (int) c - 64;
		String firstChar = "" + ii;
		if (firstChar.length() < 2) {
			firstChar = "0" + firstChar;
		}
		String parseId = firstChar + id.substring(1, id.length());
		String pid = parseId.substring(0, 11);
		String eid = parseId.length() > 11 ? parseId.substring(11, parseId.length()) : "";
		int[] hash = new int[] { 9, 6, 7, 10, 8, 1, 5, 3, 2, 11, 4 };
		String hid = "";
		for (int i = 0; i < hash.length; i++)
			hid += String.valueOf(9 - Integer.parseInt(pid.substring(hash[i] - 1, hash[i])));
		return hid + eid;
	}

	public static String getChar(char c) {
		int i = (int) c - 64;

		if (i < 10)
			return "0" + i;
		return "" + i;

	}

	public static String getHash(String s) {
		int[] hash = new int[] { 9, 6, 7, 10, 8, 1, 5, 3, 2, 11, 4 };
		String hid = "";
		for (int i = 0; i < hash.length; i++)
			hid += s.substring(hash[i] - 1, hash[i]);
		return hid;
	}

	public static String getComplement(String s) {
		String cc = "";
		char c[] = s.toCharArray();
		for (int i = 0; i < c.length; i++)
			cc += "" + (9 - (int) (s.charAt(i) - '0'));
		return new String(cc);
	}

}
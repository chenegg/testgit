/*
 * @(#) 1.00, 30/6/2005
 *
 * Copyright 2005 KGI Bank, Inc. All rights reserved. 開發者：凱基銀行 資訊處 陳柄岐.
 */
package cosmos.netbank.config;

import com.kgi.netbank.config.CacheManager;

// import cosmos.netbank.cc.NetBankConfig;
/**
 * 
 * 
 * @version 1.00, 30/6/2005
 * @author 凱基銀行 資訊處 陳柄岐
 */
public class EBankingConfig extends CacheManager {

    public EBankingConfig() throws Exception {
        load();
    }

    public static String get(int key) {
        return CacheManager.getEBankingConfig().getString(String.valueOf(key));
    }

    public static String get(String key) {
        return CacheManager.getEBankingConfig().getString(key);
    }

    /**
     * true ->p環境 false->t環境
     * 
     * @return
     */
    public static boolean check_envir() {
        String status = CacheManager.getEBankingConfig().getString("envir");
        if (status == null)
            return false;
        status = status.trim();
        if (status.equalsIgnoreCase("p"))
            return true;
        else
            return false;
    }

    @Override
    public void load() throws Exception {
        if (properties == null) {
            synchronized (this) {
                if (properties == null) {
                    properties = loadFile(CONTEXT_REAL_CONFIG_PATH, "e-Banking.properties");
                }
            }
        }
    }

}

/*
 * @(#)	1.00, 30/6/2005
 *
 * Copyright 2005 KGI Bank, Inc. All rights reserved.
 * 開發者：凱基銀行 資訊處 陳柄岐.
 */
package cosmos.netbank.config;

import com.kgi.netbank.config.CacheManager;

/**
 * 
 * 
 * @version 1.00, 30/6/2005
 * @author 凱基銀行 資訊處 陳柄岐
 */
public class GetVbFilePath extends CacheManager {

	public static String get(int key) {
		return CacheManager.getGetVbFilePath().getString(String.valueOf(key));
	}

	/**
	 * VB的xml的設定檔
	 * 
	 */
	public GetVbFilePath() throws Exception {
		load();
	}

	@Override
	public void load() throws Exception {
		if (properties == null) {
			synchronized (this) {
				/**先抓config底下的,當預留找不到改抓tomcat下**/
				if (properties == null) {
					properties = loadFile(CONTEXT_REAL_CONFIG_PATH, "VB_XML_FILE.properties");
				}
				// File f = new
				// File("C:\\work\\netbank2\\trunk\\Common\\COSMOS_ESB_Component\\src\\META-INF\\config");
				// File[] ff = f.listFiles();

				/**檔案**/
				// HashMap<String, File> ht = new HashMap<String, File>();
				// for (File file : ff) {
				// ht.put(file.getName(), file);
				// }
				// for (Object key : properties.values()) {
				// if ((ht.remove(key) != null)) {
				// System.out.println("...." + key + "=exist");
				// } else {
				// System.out.println("??????????" + key + "=not exist");
				// }
				// }
				//
				// /**不存在**/
				// for (File entry : ht.values()) {
				// System.out.println("有檔案但沒設定檔" + entry.getName());
				// }
			}
		}
	}

	public static void main(String[] args) {
		CacheManager.setCONTEXT_REAL_PATH("C:\\work\\netbank2\\trunk\\uat2\\WebContent\\");
		CacheManager.getGetVbFilePath();
	}
}

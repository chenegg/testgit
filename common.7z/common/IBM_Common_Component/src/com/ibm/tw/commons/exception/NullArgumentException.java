/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.exception;

  
 
/**
 * Null Argument Exception
 *
 * @author  Jeff Liu
 * @version 1.0, 2007/10/25
 * @see	    
 * @since 
 */
@SuppressWarnings("serial")
public class NullArgumentException extends Exception  {
 
	 
 
	public NullArgumentException() {
    		
	    super();
	}
    
	public NullArgumentException(String sMsg) {
    	
		super(sMsg);
	}
    
	 
    
	public NullArgumentException(String sMsg, Throwable cause) {
    	
		super(sMsg, cause);
		 
	 
	}
 
 
}

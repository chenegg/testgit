/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2012.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
//import com.fasterxml.jackson.annotation.JsonAutoDetect;
//import com.fasterxml.jackson.databind.DeserializationFeature;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.databind.SerializationFeature;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * Json Utils
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2012/11/30
 * @see
 * @since
 */
public class JsonUtils {

	// private static Log logger = LogFactory.getLog(JsonUtils.class);
	private static Logger logger = LoggerFactory.getLogger(JsonUtils.class);

	/**
	 * Json字串轉換為物件
	 * 
	 * @param <POJO>
	 * @param json
	 * @param clazz
	 * @return
	 */
	// public static <POJO> POJO getObject(String json, Class<POJO> clazz) {
	// ObjectMapper mapper = new ObjectMapper();
	// mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
	// false);
	// try {
	// return mapper.readValue(json, clazz);
	// }
	// catch (Exception e) {
	// logger.error("JsonReader Error", e);
	// return null;
	// }
	// }
	public static <POJO> POJO getObject(String json, final Class<POJO> clazz) {
		ObjectMapper mapper = new ObjectMapper();

		mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		try {
			mapper.setVisibilityChecker(mapper.getSerializationConfig().getDefaultVisibilityChecker()
					.withFieldVisibility(JsonAutoDetect.Visibility.ANY)
					.withGetterVisibility(JsonAutoDetect.Visibility.NONE)
					.withSetterVisibility(JsonAutoDetect.Visibility.NONE)
					.withCreatorVisibility(JsonAutoDetect.Visibility.NONE));
			return mapper.readValue(json, clazz);
		} catch (Exception e) {
			logger.error("JsonReader Error", e);
			return null;
		}
	}

	public static <POJO> String getJson(POJO object) {
		return getJson(object, false);
	}

	/**
	 * 物件轉換為Json字串
	 * 
	 * @param <POJO>
	 * @param object
	 * @return
	 */
	public static <POJO> String getJson(POJO object, boolean remove) {
		// ObjectMapper mapper = new ObjectMapper();
		// try {
		// return mapper.writeValueAsString(object);
		// }
		// catch (Exception e) {
		// logger.error("JsonWriter Error", e);
		// return null;
		// }
		ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);
			mapper.setVisibilityChecker(mapper.getSerializationConfig().getDefaultVisibilityChecker()
					.withFieldVisibility(JsonAutoDetect.Visibility.ANY)
					.withGetterVisibility(JsonAutoDetect.Visibility.NONE)
					.withSetterVisibility(JsonAutoDetect.Visibility.NONE)
					.withCreatorVisibility(JsonAutoDetect.Visibility.NONE));
			// mapper.getSerializationConfig().setSerializationInclusion(org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL);
			// mapper.setVisibilityChecker(mapper.getSerializationConfig().getDefaultVisibilityChecker().withFieldVisibility(JsonAutoDetect.Visibility.ANY).withGetterVisibility(JsonAutoDetect.Visibility.NONE)
			// .withSetterVisibility(JsonAutoDetect.Visibility.NONE).withCreatorVisibility(JsonAutoDetect.Visibility.NONE));
			// return

			// DefaultPrettyPrinter printer = new DefaultPrettyPrinter();
			// return
			// mapper.prettyPrintingWriter(printer).writeValueAsString(object);

			mapper.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);

			String toStr = mapper.writeValueAsString(object);
			if (remove) {
				toStr = StringUtils.remove(toStr, "\\r\\n");
			}
			return toStr;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("JsonWriter Error", e);
			return null;
		}
	}

	// public static <POJO> String getJson(POJO object) {
	// ObjectMapper mapper = new ObjectMapper();
	// try {
	// return mapper.writeValueAsString(object);
	// }
	// catch (Exception e) {
	// logger.error("JsonWriter Error", e);
	// return null;
	// }
	// }

	private static class Pojo {

		private String string;

		private Integer int1;

		private int int2;

		private Date date;

		private BigDecimal decimal;

		public String getString() {
			return string;
		}

		public void setString(String string) {
			this.string = string;
		}

		public Integer getInt1() {
			return int1;
		}

		public void setInt1(Integer int1) {
			this.int1 = int1;
		}

		public int getInt2() {
			return int2;
		}

		public void setInt2(int int2) {
			this.int2 = int2;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public BigDecimal getDecimal() {
			return decimal;
		}

		public void setDecimal(BigDecimal decimal) {
			this.decimal = decimal;
		}

	};

	private static class PojoLess {

		private String string;

		private Integer int1;

		private Date date;

		public String getString() {
			return string;
		}

		public void setString(String string) {
			this.string = string;
		}

		public Integer getInt1() {
			return int1;
		}

		public void setInt1(Integer int1) {
			this.int1 = int1;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

	};

	private static class PojoCollection {

		private List<Pojo> list = new ArrayList<Pojo>();

		private Set<Pojo> set = new HashSet<Pojo>();

		private Map<Integer, List<Pojo>> map1 = new HashMap<Integer, List<Pojo>>();

		private Map<String, Pojo> map2 = new LinkedHashMap<String, Pojo>();

		public List<Pojo> getList() {
			return list;
		}

		public void setList(List<Pojo> list) {
			this.list = list;
		}

		public Set<Pojo> getSet() {
			return set;
		}

		public void setSet(Set<Pojo> set) {
			this.set = set;
		}

		public Map<Integer, List<Pojo>> getMap1() {
			return map1;
		}

		public void setMap1(Map<Integer, List<Pojo>> map1) {
			this.map1 = map1;
		}

		public Map<String, Pojo> getMap2() {
			return map2;
		}

		public void setMap2(Map<String, Pojo> map2) {
			this.map2 = map2;
		}

	};

	private static class PojoCollectionLess {

		private Pojo singlePojo;

		private Set<Pojo> set = new HashSet<Pojo>();

		private Map<String, Pojo> map2 = new LinkedHashMap<String, Pojo>();

		public Set<Pojo> getSet() {
			return set;
		}

		public Pojo getSinglePojo() {
			return singlePojo;
		}

		public void setSinglePojo(Pojo singlePojo) {
			this.singlePojo = singlePojo;
		}

		public void setSet(Set<Pojo> set) {
			this.set = set;
		}

		public Map<String, Pojo> getMap2() {
			return map2;
		}

		public void setMap2(Map<String, Pojo> map2) {
			this.map2 = map2;
		}

	};

	public static void main(String[] args) {
		Pojo pojo1 = new JsonUtils.Pojo();
		pojo1.string = "String !@#123	中文一二三";
		pojo1.int1 = Integer.MIN_VALUE;
		pojo1.int2 = Integer.MAX_VALUE;
		pojo1.date = new Date();
		pojo1.decimal = new BigDecimal("9876543210123456789.9876543210123456789");

		PojoCollectionLess pl = new PojoCollectionLess();
		pl.setSinglePojo(pojo1);
		String json1 = JsonUtils.getJson(pl);
		System.out.println("PojoCollectionLess p1: " + json1);

		// Pojo w/ filled field
		String json = JsonUtils.getJson(pojo1);
		System.out.println(json);
		Pojo pojo1New = JsonUtils.getObject(json, Pojo.class);
		String jsonNew = JsonUtils.getJson(pojo1New);
		System.out.println(jsonNew);
		System.out.println("json == jsonNew ? " + StringUtils.equals(json, jsonNew));

		// Pojo w/ empty field
		Pojo pojo2 = new JsonUtils.Pojo();
		json = JsonUtils.getJson(pojo2);
		System.out.println(json);
		Pojo pojo2New = JsonUtils.getObject(json, Pojo.class);
		jsonNew = JsonUtils.getJson(pojo2New);
		System.out.println(jsonNew);
		System.out.println("json == jsonNew ? " + StringUtils.equals(json, jsonNew));

		// Pojo collection w/ filled field
		PojoCollection pojoCollection1 = new JsonUtils.PojoCollection();
		pojoCollection1.list.add(pojo1);
		pojoCollection1.list.add(pojo2);
		pojoCollection1.list.add(pojo1);
		pojoCollection1.list.add(pojo2);
		pojoCollection1.set.add(pojo1);
		pojoCollection1.set.add(pojo2);
		pojoCollection1.set.add(pojo1);
		pojoCollection1.set.add(pojo2);
		pojoCollection1.map1.put(1, pojoCollection1.list);
		pojoCollection1.map1.put(2, new ArrayList<Pojo>());
		pojoCollection1.map2.put(pojo1.toString(), pojo1);
		pojoCollection1.map2.put(pojo2.toString(), pojo2);
		pojoCollection1.map2.put("pojo1", pojo1);
		pojoCollection1.map2.put("pojo2", pojo2);
		json = JsonUtils.getJson(pojoCollection1);
		System.out.println(json);
		PojoCollection pojoCollection1New = JsonUtils.getObject(json, PojoCollection.class);
		jsonNew = JsonUtils.getJson(pojoCollection1New);
		System.out.println(jsonNew);
		System.out.println("json == jsonNew ? " + StringUtils.equals(json, jsonNew));

		// Pojo collection w/ empty field
		PojoCollection pojoCollection2 = new JsonUtils.PojoCollection();
		json = JsonUtils.getJson(pojoCollection2);
		System.out.println(json);
		PojoCollection pojoCollection2New = JsonUtils.getObject(json, PojoCollection.class);
		jsonNew = JsonUtils.getJson(pojoCollection2New);
		System.out.println(jsonNew);
		System.out.println("json == jsonNew ? " + StringUtils.equals(json, jsonNew));

		// Pojo more -> less
		json = JsonUtils.getJson(pojo1);
		System.out.println(json);
		PojoLess pojoLess = JsonUtils.getObject(json, PojoLess.class);
		jsonNew = JsonUtils.getJson(pojoLess);
		System.out.println(jsonNew);

		// Pojo less -> more
		json = JsonUtils.getJson(pojoLess);
		System.out.println(json);
		Pojo pojoMore = JsonUtils.getObject(json, Pojo.class);
		jsonNew = JsonUtils.getJson(pojoMore);
		System.out.println(jsonNew);

		// Pojo collection more -> less
		json = JsonUtils.getJson(pojoCollection1);
		System.out.println(json);
		PojoCollectionLess pojoCollectionLess = JsonUtils.getObject(json, PojoCollectionLess.class);
		jsonNew = JsonUtils.getJson(pojoCollectionLess);
		System.out.println(jsonNew);

		// Pojo collection less -> more
		json = JsonUtils.getJson(pojoCollectionLess);
		System.out.println(json);
		PojoCollection pojoCollectionMore = JsonUtils.getObject(json, PojoCollection.class);
		jsonNew = JsonUtils.getJson(pojoCollectionMore);
		System.out.println(jsonNew);

	}
}

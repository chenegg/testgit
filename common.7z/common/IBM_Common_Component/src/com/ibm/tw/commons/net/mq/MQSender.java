/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;

/**
 * MQ 傳送物件
 * 
 * @author jeff
 * @author jeff, 2006/02/09
 * @version 1.0, 2005/8/29
 * @see com.ibm.tw.commons.net.mq.MQBase
 * @since
 */
public class MQSender extends MQBase {

	/**
	 * 
	 */
	public MQSender() {

	}

	/**
	 * 連接MQ Server
	 * 
	 * @param sQueueManagerName
	 * @param sQueueName
	 * @throws MQException
	 */
	public void connect(String sQueueManagerName, String sQueueName) throws MQException {
		connect(sQueueManagerName, sQueueName, MQBase.MQ_WRITE);
	}

	/**
	 * send message to queue
	 * 
	 */
	public void send(CMQMessage message) throws MQException {
		 
		MQPutMessageOptions oPMO = new MQPutMessageOptions();
		
		MQMessage mqMessage = message.toMQMessage();
		m_queue.put(mqMessage, oPMO);
		
		message.setMessageId(mqMessage.messageId);
	}

}
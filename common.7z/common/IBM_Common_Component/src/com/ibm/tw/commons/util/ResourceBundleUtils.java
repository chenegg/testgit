package com.ibm.tw.commons.util;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;

import org.slf4j.LoggerFactory;

public abstract class ResourceBundleUtils {
	protected static org.slf4j.Logger logger = LoggerFactory.getLogger(ResourceBundleUtils.class);

	/* 預設的 */
	private static final String DEFAULT_BUNDLE = "msgApp";

	/**
	 * 系統預設
	 * 
	 * @param key
	 * @return
	 */
	public static String getDisplayDefaultName(String key) {
		return getDisplayName(DEFAULT_BUNDLE, key);
	}

	/**
	 * 系統預設
	 * 
	 * @param key
	 * @param param
	 * @return
	 */
	public static String getDisplayDefaultName(String key, Object... param) {
		return getBundleString(DEFAULT_BUNDLE, key, param);
	}

	public static String getDisplayName(String baseName, String key) {
		Locale local = null;
		FacesContext context = FacesContext.getCurrentInstance();
		if (context != null) {
			local = context.getViewRoot().getLocale();
		}

		/* 使用預設值 */
		if (local == null) {
			local = Locale.getDefault();
		}
		return getDisplayName(getResourceBundle(baseName, local), key);
	}

	public static String getDisplayName(String bundleName, Locale locale, String key) {
		return getDisplayName(getResourceBundle(bundleName, locale), key);
	}

	public static String getDisplayName(ResourceBundle bundle, String key) {
		return getBundleString(bundle, key);
	}

	public static String getBundleString(String baseName, String key, Object... param) {
		Locale locale = null;
		FacesContext context = FacesContext.getCurrentInstance();
		if (context != null) {
			locale = context.getViewRoot().getLocale();
		}

		/* 使用預設值 */
		if (locale == null) {
			locale = Locale.getDefault();
		}
		return getBundleString(baseName, locale, key, param);
	}

	public static String getBundleString(String baseName, Locale locale, String key, Object... param) {
		return getBundleString(getResourceBundle(baseName, locale), key, param);
	}

	public static String getBundleString(ResourceBundle rb, String key, Object... param) {
		try {
			if (rb == null || StringUtils.isBlank(key)) {
				logger.warn("??? [ResourceBundle= \" + rb + \"][Key=\" + key + \"] ???");
				return "??? [ResourceBundle= " + rb + "][Key=" + key + "] ???";
			} else {
				if (param == null || param.length == 0) {
					return rb.getString(key);
				} else {
					return MessageFormat.format(rb.getString(key), param);
				}
			}
		} catch (MissingResourceException e) {
			logger.warn("??? [ResourceBundle= " + rb + "][Key=" + key + "] ???");
			return "??? [ResourceBundle= " + rb + "][Key=" + key + "] ???";
		} catch (IllegalArgumentException e) {
			logger.warn("??? [ResourceBundle= " + rb + "][Key=" + key + "] [param="
					+ (param == null ? null : param.toString()) + "]???");
			return "??? [ResourceBundle= " + rb + "][Key=" + key + "] [param="
					+ (param == null ? null : param.toString()) + "]???";
		}
	}

	private static ResourceBundle getResourceBundle(String baseName, Locale locale) {
		try {
			return ResourceBundle.getBundle(baseName, locale, new UTF8Control());
		} catch (java.util.MissingResourceException e) {
			/* 因為找不到所以試著去預設抓 */
			logger.error("baseName=" + baseName + ",locale" + locale, e);
			return ResourceBundle.getBundle(baseName, new UTF8Control());
		}
	}

}

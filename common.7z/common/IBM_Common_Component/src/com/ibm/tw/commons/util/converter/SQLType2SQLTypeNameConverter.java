/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util.converter;

import java.sql.Types;
import java.util.Hashtable;
import java.util.Map;

import com.ibm.tw.commons.util.StringUtils;


/**
 * JDBC SQL Type -> SQL Type Name
 *
 * @author  Jeff Liu
 * @version 1.0, 2007/10/31
 * @see	    
 * @since 
 */
public class SQLType2SQLTypeNameConverter {
	
	/** 儲存SQL Type -> SQL Type Name 的轉換表 */
	private static Map<Integer, String> m_sqlTypes = new Hashtable<Integer, String>();
	
	static {

		register();

	}
	
	/**
	 * 取得SQL Type的名稱
	 * 
	 * @param iSQLType
	 * @return
	 */
	public static String getSQLTypeName(int iSQLType) {
		String sTypeName = (String) m_sqlTypes.get(new Integer(iSQLType));

		return StringUtils.defaultString(sTypeName);
	}
	
	/**
	 * 註冊轉換表
	 *
	 */
	private static void register() {
		m_sqlTypes.put(new Integer(Types.BIT), "BIT");
		m_sqlTypes.put(new Integer(Types.TINYINT), "TINYINT");
		m_sqlTypes.put(new Integer(Types.SMALLINT), "SMALLINT");
		m_sqlTypes.put(new Integer(Types.INTEGER), "INTEGER");
		m_sqlTypes.put(new Integer(Types.BIGINT), "BIGINT");
		m_sqlTypes.put(new Integer(Types.FLOAT), "FLOAT");
		m_sqlTypes.put(new Integer(Types.REAL), "REAL");
		m_sqlTypes.put(new Integer(Types.DOUBLE), "DOUBLE");
		m_sqlTypes.put(new Integer(Types.NUMERIC), "NUMERIC");
		m_sqlTypes.put(new Integer(Types.DECIMAL), "DECIMAL");
		m_sqlTypes.put(new Integer(Types.CHAR), "CHAR");
		m_sqlTypes.put(new Integer(Types.VARCHAR), "VARCHAR");
		m_sqlTypes.put(new Integer(Types.LONGVARCHAR), "LONGVARCHAR");
		m_sqlTypes.put(new Integer(Types.DATE), "DATE");
		m_sqlTypes.put(new Integer(Types.TIME), "TIME");
		m_sqlTypes.put(new Integer(Types.TIMESTAMP), "TIMESTAMP");
		m_sqlTypes.put(new Integer(Types.BINARY), "BINARY");
		m_sqlTypes.put(new Integer(Types.VARBINARY), "VARBINARY");
		m_sqlTypes.put(new Integer(Types.LONGVARBINARY), "LONGVARBINARY");
		m_sqlTypes.put(new Integer(Types.NULL), "NULL");
		m_sqlTypes.put(new Integer(Types.OTHER), "OTHER");
		m_sqlTypes.put(new Integer(Types.JAVA_OBJECT), "JAVA_OBJECT");
		m_sqlTypes.put(new Integer(Types.DISTINCT), "DISTINCT");
		m_sqlTypes.put(new Integer(Types.STRUCT), "STRUCT");
		m_sqlTypes.put(new Integer(Types.ARRAY), "ARRAY");
		m_sqlTypes.put(new Integer(Types.BLOB), "BLOB");
		m_sqlTypes.put(new Integer(Types.CLOB), "CLOB");
		m_sqlTypes.put(new Integer(Types.REF), "REF");
		m_sqlTypes.put(new Integer(Types.DATALINK), "DATALINK");
		m_sqlTypes.put(new Integer(Types.BOOLEAN), "BOOLEAN");
	}

}

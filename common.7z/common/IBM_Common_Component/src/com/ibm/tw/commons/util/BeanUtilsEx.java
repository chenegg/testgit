package com.ibm.tw.commons.util;

import java.lang.reflect.InvocationTargetException;

import com.emis.invest.util.DateConverter;
import org.apache.commons.beanutils.ConvertUtils;

public class BeanUtilsEx extends org.apache.commons.beanutils.BeanUtils {
	static {
		ConvertUtils.register(new DateConverter(), java.util.Date.class);
		ConvertUtils.register(new DateConverter(), java.sql.Date.class);
	}

	public static void copyProperties(Object dest, Object orig) {
		try {
			BeanUtils.copyProperties(dest, orig);
		} catch (IllegalAccessException ex) {
			ex.printStackTrace();
		} catch (InvocationTargetException ex) {
			ex.printStackTrace();
		}
	}
}

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * MQ查詢傳送物件
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;

/**
 * <p>MQ Browser</p>
 * 
 * @author  hank
 * @author jeff, 2006/02/09
 * @version 1.0, 2005/8/29
 * @see	    
 * @since 
 */
public class MQBrowser extends MQBase {

   
    
    public MQBrowser() {
        
    }
    
    public void connect(String sQueueManagerName, String sQueueName) throws MQException {
        connect(sQueueManagerName, sQueueName, MQBase.MQ_BROWSE);

    }
    
    public void connectByInquire(String sQueueManagerName, String sQueueName) throws MQException {
    	connect(sQueueManagerName, sQueueName, MQBase.MQ_INQUIRE);
    }
    
    
	/**
	 * browse message
	 * 
	 * 第一筆為0
	 * 
	 */
	public CMQMessage browse(int index) throws MQException {
		
		if (index < 0) {
			return null;
		}
		
		// 第一筆為0
		int count = index + 1;
		
		CMQMessage message = null;
		MQMessage mqMessage = null;
		
		MQGetMessageOptions oGMO = new MQGetMessageOptions();
		oGMO.options = MQC.MQGMO_BROWSE_FIRST ;
		
		for (int i = 0; i < count; i++) {
			mqMessage = new MQMessage();
			m_queue.get(mqMessage, oGMO);
			oGMO.options = MQC.MQGMO_BROWSE_NEXT;
		}
		 
		
		// RFH2 Message
		if (mqMessage.format.equals(MQC.MQFMT_RF_HEADER_2)) {

			message = new CMQRfh2Message(mqMessage);
		}
		else {
			message = new CMQStrMessage(mqMessage);
			
		}
		return message;
	}
	
	/**
	 * browse message putDateTime
	 * 
	 * Add by Clark 2009/07/09
	 * 
	 * @param iIndex
	 * @return
	 * @throws MQException
	 */
	public MQMessage browseMQMessage(int iIndex) throws MQException{
		if (iIndex < 0) {
			return null;
		}
		
		// 第一筆為0
		int iCount = iIndex + 1;
		
		MQMessage aMQMessage = null;
		
		MQGetMessageOptions oGMO = new MQGetMessageOptions();
		oGMO.options = MQC.MQGMO_BROWSE_FIRST ;
		
		for (int i = 0; i < iCount; i++) {
			aMQMessage = new MQMessage();
			m_queue.get(aMQMessage, oGMO);
			oGMO.options = MQC.MQGMO_BROWSE_NEXT;
		}
		
		return aMQMessage;
		
	}
    
	 
}
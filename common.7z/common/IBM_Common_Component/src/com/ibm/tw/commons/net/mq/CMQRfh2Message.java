/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
 

/**
 * MQ RFH2 訊息物件
 * 
 * @author jeff
 * @version 1.0, 2005/11/28
 * @see
 * @since
 * 
 */
public class CMQRfh2Message extends CMQMessage implements Cloneable {

	/** RFH2 Fix + NamedValueData */
	private CMQRfh2 m_rfh2 = null;

	/** common logger */
	protected static Log m_logger = LogFactory.getLog(CMQRfh2Message.class);

	public CMQRfh2Message() {

		// format
		setFormat(MQC.MQFMT_RF_HEADER_2);

		m_rfh2 = new CMQRfh2();

	}

	public CMQRfh2Message(MQMessage mqMessage) {

		// decode
		decode(mqMessage);

	}
	
 
	/**
	 * MQMessage -> CMQRfh2Message
	 * 
	 */
	private void decode(MQMessage mqMessage) {
		 
		if (!mqMessage.format.equals(MQC.MQFMT_RF_HEADER_2)) {
			getLogger().warn("CMQRFH2Message.parse(), WARNING: it is not RFH2 format!");
			return;
		}

		// MQMD
		m_mqmd = new CMQMD(mqMessage);

		// RFH2
		m_rfh2 = new CMQRfh2(mqMessage);

		// Message Data
		decodeMessageData(mqMessage);

	}
	 

 

	/**
	 * MQMessage -> CMQRfh2Message (Message Data)
	 * 
	 * @return
	 */
	private void decodeMessageData(MQMessage mqMessage) {
		byte[] messageData = null;
		try {


			// 訊息長度 ＝ MQ訊息總長度 - RFH2使用者自訂資料長度
			int iMsgLen = mqMessage.getMessageLength() - m_rfh2.getStructLen();
			
			// 略過RFH2變動資料區
			int offset = m_rfh2.getStructLen();
			mqMessage.seek(offset);

			messageData = new byte[iMsgLen];
			mqMessage.readFully(messageData, 0, iMsgLen);
		}
		catch (IOException e) {
			messageData = null;
			getLogger().error(e);
		}
		m_messageData = messageData;
	}



	/**
	 * set RFH2 Message
	 * 
	 * @param rfh2Data
	 * @param messageData
	 */
	public void setMessage(String rfh2Data, byte[] messageData) {
		m_rfh2.setRfh2Data(rfh2Data);
		m_messageData = messageData;
	}

	/**
	 * Set RFH2
	 * 
	 * @param rfh2Data
	 */
	public void setRfh2VariableData(String rfh2Data) {
		m_rfh2.setRfh2Data(rfh2Data);
	}
	
	/**
	 * Get Rfh2 Variable Data
	 * 
	 * @return
	 */
	public String getRfh2VariableData() {
		return m_rfh2.getRfh2Data();
	}

	/**
	 * CMQRfh2Message -> MQMessage
	 * 
	 * @param rfh2Data
	 * @param messageData
	 * @throws MQException 
	 */
	public MQMessage toMQMessage() throws MQException {

		MQMessage mqMessage = new MQMessage();

		try {

			// MQMD
			m_mqmd.encode(mqMessage);

			// RFH2
			m_rfh2.encode(mqMessage);
			
			// message data
			mqMessage.write(m_messageData, 0, m_messageData.length);
		}
		catch (IOException e) {
			mqMessage = null;
			getLogger().error(e);
		}
	 

		return mqMessage;

	}
 
	/**
	 * 設定 CCSID
	 * 
	 * TODO: 待確認
	 * 
	 * @param iCCSID
	 */
	public void setCCSID(int ccsid) {

		super.setCCSID(ccsid);
		
		m_rfh2.setCodedCharSetId(ccsid);
	}

	protected Log getLogger() {
		return m_logger;
	}
}
/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import com.ibm.mq.MQException;
import com.ibm.mq.constants.MQConstants;



/**
 * <p> MQ Queue 物件屬性設定 </p>
 *
 * @author  hank
 * @version 1.0, 2011/8/17
 * @see	    
 * @since 
 */
public class MQSetter  extends MQBase {

	/**
	 * Constructor
	 */
	public MQSetter(){
		
	}
	
	
	/**
	 * 連接 MQ Server
	 * 
	 * @param sQueueManagerName
	 * @param sQueueName
	 * @throws MQException
	 */
	public void connect(String sQueueManagerName, String sQueueName) throws MQException {
		connect(sQueueManagerName, sQueueName, MQBase.MQ_SET);
	}
	
	
	/**
	 * Disabled PUT
	 * 
	 * @throws MQException
	 */
	public void disablePut() throws MQException{
		
		getQueue().setInhibitPut(MQConstants.MQQA_PUT_INHIBITED);
	}
	
	
	/**
	 * Enable PUT
	 * 
	 * @throws MQException
	 */
	public void enablePut() throws MQException{
		
		getQueue().setInhibitPut(MQConstants.MQQA_PUT_ALLOWED);
	}
	
	
	/**
	 * Disabled GET
	 * 
	 * @throws MQException
	 */
	public void disableGet() throws MQException{
		
		getQueue().setInhibitGet(MQConstants.MQQA_GET_INHIBITED);
	}
	
	
	/**
	 * Enable PUT
	 * 
	 * @throws MQException
	 */
	public void enableGet() throws MQException{
		
		getQueue().setInhibitGet(MQConstants.MQQA_GET_ALLOWED);
	}
	
	
	
}



 
/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mb;

import com.ibm.broker.config.proxy.BrokerProxy;
import com.ibm.broker.config.proxy.ConfigManagerConnectionParameters;
import com.ibm.broker.config.proxy.ConfigManagerProxy;
import com.ibm.broker.config.proxy.ConfigManagerProxyLoggedException;
import com.ibm.broker.config.proxy.ConfigManagerProxyPropertyNotInitializedException;
import com.ibm.broker.config.proxy.ExecutionGroupProxy;
import com.ibm.broker.config.proxy.MQConfigManagerConnectionParameters;
import com.ibm.broker.config.proxy.MessageFlowProxy;
import com.ibm.broker.config.proxy.TopologyProxy;



/**
 * <p> Message Broker Manager </p>
 *
 * @author  hank
 * @version 1.0, 2011/8/17
 * @see	    
 * @since 
 */
public class BrokerManager {
	
	private String ip;
	
	private int port;
	
	private String queueManagerName;
	
	private ConfigManagerProxy cmp;
	
	private BrokerProxy broker;
	
	
	/**
	 * Constructor
	 */
	public BrokerManager(){
		
	}
	
	
	/**
	 * 設定 MQ 環境
	 * 
	 * @param ip
	 * @param port
	 * @param queueManagerName
	 */
	public void setEnvironment(String ip, int port, String queueManagerName){
		
		this.ip = ip;
		this.port = port;
		this.queueManagerName = queueManagerName;
	}
	
	
	/**
	 * Connect Broker
	 * 
	 * @param brokerName
	 * @throws CMBException
	 */
	public void connect(String brokerName) throws CMBException{
		
		ConfigManagerConnectionParameters cmcp = new MQConfigManagerConnectionParameters(ip, port, queueManagerName);
 		
		try {
			
			cmp = ConfigManagerProxy.getInstance(cmcp);
			
			if (cmp.hasBeenUpdatedByConfigManager(true)) {
	        	
	            TopologyProxy topology = cmp.getTopology();
	            broker = topology.getBrokerByName(brokerName);
	            
	            if (broker == null) {
	            	throw new CMBException(CMBException.WMB_BROKER_NOTFOUND, "BrokerName[" + brokerName + "], not found!");
	            }
	            
	        }

		}
		catch (ConfigManagerProxyLoggedException e) {

			throw new CMBException(e);
		}
		catch (ConfigManagerProxyPropertyNotInitializedException e) {

			throw new CMBException(e);
		}
		
	}
	
	
	/**
	 * 流程是否執行中
	 * 
	 * @param execGroupName
	 * @param flowName
	 * @return
	 * @throws CMBException
	 */
	public boolean flowIsRunning(String execGroupName, String flowName) throws CMBException{
		
		 
		try {
			
			ExecutionGroupProxy eg = broker.getExecutionGroupByName(execGroupName);

	        if (eg == null) {
	            throw new CMBException(CMBException.WMB_EXECGROUP_NOTFOUND, "ExecutionGroup[" + execGroupName + "], not found!");
	        }
	        	
	                     	
	        MessageFlowProxy messageFlow = eg.getMessageFlowByName(flowName);
	        	
	        if (messageFlow == null){
	        	throw new CMBException(CMBException.WMB_FLOW_NOTFOUND, "Flow[" + flowName + "], not found!");
	        }
	        
	        return messageFlow.isRunning();
	        			
		}
		catch (ConfigManagerProxyPropertyNotInitializedException e) {
			
			throw new CMBException(e);
		}
    			
	}
	
	
	/**
	 * 啟動流程
	 * 
	 * @param execGroupName
	 * @param flowName
	 * @throws CMBException
	 */
	public void startFlow(String execGroupName, String flowName) throws CMBException{
		
		try {
			
			ExecutionGroupProxy eg = broker.getExecutionGroupByName(execGroupName);
			
			if (eg == null) {
	            throw new CMBException(CMBException.WMB_EXECGROUP_NOTFOUND, "ExecutionGroup[" + execGroupName + "], not found!");
	        }
	    	
			
			MessageFlowProxy messageFlow = eg.getMessageFlowByName(flowName);
			
			if (messageFlow == null){
				throw new CMBException(CMBException.WMB_FLOW_NOTFOUND, "Flow[" + flowName + "], not found!");
			}
	        
	        messageFlow.start();
			
		}
		catch (ConfigManagerProxyPropertyNotInitializedException e) {
			throw new CMBException(e);
		}
		catch (ConfigManagerProxyLoggedException e) {
			throw new CMBException(e);
		}
				
	}
	
	
	/**
	 * 停止流程
	 * 
	 * @param execGroupName
	 * @param flowName
	 * @throws CMBException
	 */
	public void stopFlow(String execGroupName, String flowName) throws CMBException{
		
		try {
			
			ExecutionGroupProxy eg = broker.getExecutionGroupByName(execGroupName);
			
			if (eg == null) {
	            throw new CMBException(CMBException.WMB_EXECGROUP_NOTFOUND, "ExecutionGroup[" + execGroupName + "], not found!");
	        }
	    	
			
			MessageFlowProxy messageFlow = eg.getMessageFlowByName(flowName);
			
			if (messageFlow == null){
				throw new CMBException(CMBException.WMB_FLOW_NOTFOUND, "Flow[" + flowName + "], not found!");
			}
	        
	        messageFlow.stop();
			
		}
		catch (ConfigManagerProxyPropertyNotInitializedException e) {
			throw new CMBException(e);
		}
		catch (ConfigManagerProxyLoggedException e) {
			throw new CMBException(e);
		}
				
	}	
	
	
	
	/**
	 * 
	 */
	public void close(){
		
		if (broker != null) {
			broker.disconnect();
		}
		
		if (cmp != null) {
			cmp.disconnect();
		}
		
	}
	

}



 
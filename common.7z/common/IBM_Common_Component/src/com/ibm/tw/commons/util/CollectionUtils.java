package com.ibm.tw.commons.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author Egg.chen
 * 
 */
public class CollectionUtils extends org.apache.commons.collections.CollectionUtils {

	private CollectionUtils() {

	}

	public static <E> List<E> nullToEmpty(List<E> entitys) {
		return entitys == null ? new ArrayList<E>() : entitys;
	}

	public static boolean isEmpty(Map map) {
		return null == map || map.size() == 0;
	}
}

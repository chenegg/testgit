/*
 * ===========================================================================
 * IBM Confidential AIS Source Materials
 * 
 * XML Bean Base Class
 * 
 * (C) Copyright IBM Corp. 2010.
 * 
 * ===========================================================================
 */
package com.ibm.tw.commons.xml.ecs;


@SuppressWarnings("serial")
public class Xml extends org.apache.ecs.xml.XML {

	/**
	 * @param arg0
	 */
	public Xml(String arg0) {
		super(arg0, true, true);		 
	}
	
	@SuppressWarnings("unchecked")
	public Xml(Class clazz) {
		
		this(clazz.getName());	
	}


	public Xml(String sTagName, String sTagValue) {
		this(sTagName);
		
		addElement(sTagValue);	
	}
	
	public Xml(String sTagName, int iTagValue) {
		this(sTagName, String.valueOf(iTagValue));	
	}
	
	public Xml addChild(String sTagName) {
	    
	    Xml child = new Xml(sTagName);
	    
	    addElement(child);
	    
	    return child;
	}
	
	public Xml addChild(String sTagName, String sTagValue) {
	    
	    Xml child = new Xml(sTagName, sTagValue);
	    
		addElement(child);
		
		return child;
	}
	
	public Xml addChild(String sTagName, int iTagValue) {
	    return addChild(sTagName, String.valueOf(iTagValue));
	}
	
	public void addChild(Xml child) {
	    addElement(child);
	}
}

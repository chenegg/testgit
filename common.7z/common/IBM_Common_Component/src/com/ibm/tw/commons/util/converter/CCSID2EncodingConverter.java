/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util.converter;

import java.util.Hashtable;

/**
 * CCSID碼轉換Java字元編碼
 * 
 * @author Kevin
 * @version 1.0, 2007/10/19
 * @see
 * @since
 */
public class CCSID2EncodingConverter {

	/** 儲存IBM WebSphere MQ字元編碼代號（CCSID）轉換表 */
	private static Hashtable<String, String> m_encodingMap = new Hashtable<String, String>();

	static {
		deregister();
	}

	public static String getEncoding(int iCCSID) {
		return (String) m_encodingMap.get(String.valueOf(iCCSID));
	}

	/**
	 * 註冊IBM WebSphere MQ字元編碼代號（CCSID）轉換表
	 * 
	 */
	private static void deregister() {

		// TODO: unisys encoding
		m_encodingMap.put("72", "unisys");
		// big5
		m_encodingMap.put("950", "Cp950");
		// EBCDID
		m_encodingMap.put("937", "Cp937");
		// UCS2
		m_encodingMap.put("1200", "Unicode");
		// UTF8
		m_encodingMap.put("1208", "UTF-8");

		// TODO
		// new String => 使用 ISO2022CN
		// getBytes => 使用 ISO2022CN_CNS

		m_encodingMap.put("11643", "ISO2022CN");
	}
}

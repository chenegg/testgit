package com.ibm.tw.commons.util.time;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.StringUtils;


/**
 * 日期工具集
 * <p>
 * 日期工具集主要功能繼承自{@link org.apache.commons.lang.time.DateUtils}， 並增加下列功能：
 * <ul>
 * <li>簡易的日期物件產生方式</li>
 * <li>日期物件的各種字串表示方式</li>
 * </ul>
 * </p>
 * 
 * @author Jeff Liu
 * @version 1.0, 2004/10/20
 * @see {@link org.apache.commons.lang.time.DateUtils}
 * @since
 */
public class DateUtils extends org.apache.commons.lang.time.DateUtils {

	/** ISO日期格式的分隔子 */
	public final static String ISO_LINK = "-";

	/** 民國年預設之分隔子 */
	public final static String ROC_LINK = "/";

	/**
	 * @return
	 */
	public static Timestamp getCurrentTimestamp() {
		java.util.Date dt = new java.util.Date();

		return ConvertUtils.date2Timestamp(dt);
	}

	/**
	 * 取得現在之日期物件(<code>java.sql.Date</code>)
	 * 
	 * @return
	 */
	public static java.sql.Date getCurrentSQLDate() {
		java.util.Date dt = new java.util.Date();

		return new java.sql.Date(dt.getTime());
	}

	/**
	 * 清除<code>Calendar</code>物件中之各時間欄位值，僅保留日期欄位
	 * 
	 * @param calendar
	 * @return
	 */
	public static void clearTime(Calendar calendar) {
		if (null == calendar) {
			return;
		}

		int iYear = calendar.get(Calendar.YEAR);
		int iMonth = calendar.get(Calendar.MONTH);
		int iDay = calendar.get(Calendar.DAY_OF_MONTH);

		calendar.clear();

		calendar.set(Calendar.YEAR, iYear);
		calendar.set(Calendar.MONTH, iMonth);
		calendar.set(Calendar.DAY_OF_MONTH, iDay);
	}

	/**
	 * 清除 hour, min, sec, ms...
	 * 
	 * @param calendar
	 * @return
	 */
	public static void clearTime(java.util.Date dt) {
		if (dt == null) {
			return;
		}
		Calendar calendar = ConvertUtils.date2Calendar(dt);
		clearTime(calendar);

		dt.setTime(calendar.getTime().getTime());
	}

	public static java.util.Date getDate(String iYear, String iMonth, String iDay) {
		return getDate(ConvertUtils.str2Int(iYear, 0), ConvertUtils.str2Int(iMonth, 0), ConvertUtils.str2Int(iDay, 0));
	}

	/**
	 * 根據西元年/月/日取得<code>java.util.Date</code>物件
	 * 
	 * @param iYear  西元年
	 * @param iMonth 月
	 * @param iDay   日
	 * @return
	 * 
	 *         TODO:資料檢核
	 */
	public static java.util.Date getDate(int iYear, int iMonth, int iDay) {

		if (iYear <= 0 || iMonth <= 0 || iDay <= 0) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.YEAR, iYear);
		calendar.set(Calendar.MONTH, iMonth - 1);
		calendar.set(Calendar.DAY_OF_MONTH, iDay);
		return calendar.getTime();
	}

	/**
	 * 根據西元年/月/日 時/分/秒取得<code>java.util.Date</code>物件
	 * 
	 * @param iYear  西元年
	 * @param iMonth 月
	 * @param iDay   日
	 * @param iHour  時 (24小時制)
	 * @param iMin   分
	 * @param iSec   表
	 * @return
	 * 
	 *         TODO:資料檢核
	 */
	public static java.util.Date getDateTime(int iYear, int iMonth, int iDay, int iHour, int iMin, int iSec) {
		Calendar calendar = Calendar.getInstance();
		calendar.clear();

		calendar.set(Calendar.YEAR, iYear);
		calendar.set(Calendar.MONTH, iMonth - 1);
		calendar.set(Calendar.DAY_OF_MONTH, iDay);
		calendar.set(Calendar.HOUR_OF_DAY, iHour);
		calendar.set(Calendar.MINUTE, iMin);
		calendar.set(Calendar.SECOND, iSec);

		return calendar.getTime();
	}

	/**
	 * 取得簡易ISO格式的日期格式字串
	 * 
	 * <pre>
	 * DateUtils.getSimpleISODateStr(new Date()) = &quot;20071220&quot;
	 * </pre>
	 * 
	 * @param 日期物件
	 * @return 簡易的日期格式字串
	 * 
	 */
	public static String getSimpleISODateStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.SIMPLE_ISO_DATE_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 取得簡易ISO格式的日期格式字串
	 * 
	 * <pre>
	 * DateUtils.getSimpleISODateYYYYMMStr(new Date()) = &quot;202105&quot;
	 * </pre>
	 * 
	 * @param 日期物件
	 * @return 簡易的日期格式字串
	 * 
	 */
	public static String getSimpleISODateYYYYMMStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.yyyyMM.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}
	
	/**
	 * 取得簡易ISO格式的時間格式字串
	 * 
	 * <pre>
	 * DateUtils.getSimpleISOTimeStr(new Date()) = &quot;132001&quot;
	 * </pre>
	 * 
	 * @param HHmmss
	 * @return 簡易的ISO時間格式字串，日期錯誤時回傳空字串
	 * 
	 */
	public static String getSimpleISOTimeStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.SIMPLE_ISO_TIME_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 取得簡易ISO格式的日期和時間字串
	 * 
	 * <pre>
	 * DateUtils.getSimpleISODateTimeStr(new Date()) = &quot;yyyyMMddTHHmmss&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return
	 */
	public static String getSimpleISODateTimeStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.SIMPLE_ISO_DATETIME_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 取得ISO格式的日期字串
	 * 
	 * <pre>
	 * DateUtils.getISODateStr(new Date()) = &quot;yyyy-MM-dd&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return
	 */
	public static String getISODateStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.ISO_DATE_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 取得ISO日期格式字串，年、月、日之間以分隔子(<code>sLink</code>)連接
	 * 
	 * <pre>
	 * DateUtils.getISODateStr(null) = &quot;&quot;
	 * DateUtils.getISODateStr(new Date(), &quot;/&quot;) = &quot;yyyy/MM/dd&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @param sLink 分隔子
	 * @return 以分隔子的ISO格式字串，如果傳入日期為<code>null</code>，則回傳空字串
	 */
	public static String getISODateStr(java.util.Date dt, String sLink) {
		if (null == dt) {
			return "";
		}

		Calendar ctime = Calendar.getInstance();
		ctime.setTime(dt);

		StringBuffer sb = new StringBuffer();
		sb.append(ctime.get(Calendar.YEAR));
		sb.append(sLink);
		String sMonth = String.valueOf(ctime.get(Calendar.MONTH) + 1);
		sMonth = StringUtils.leftPad(sMonth, 2, "0");
		sb.append(sMonth);
		sb.append(sLink);
		String sDay = String.valueOf(ctime.get(Calendar.DAY_OF_MONTH));
		sDay = StringUtils.leftPad(sDay, 2, "0");
		sb.append(sDay);

		return sb.toString();
	}

	/**
	 * 取得ISO格式的時間字串
	 * 
	 * <pre>
	 * DateUtils.getISOTimeStr(null) = &quot;&quot;
	 * DateUtils.getISOTimeStr(new Date()) = &quot;HH:mm:ss&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return ISO格式的時間字串，如果傳入日期為<code>null</code>，則回傳空字串
	 */
	public static String getISOTimeStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		// String sFormat = DateFormatUtils.ISO_TIME_FORMAT.getPattern();
		String sFormat = DateFormatUtils.ISO_TIME_NO_T_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 取得ISO格式的日期時間字串
	 * 
	 * <pre>
	 * DateUtils.getISODateTimeStr(new Date()) = &quot;yyyy-MM-ddTHH:mm:ss&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return 如果傳入日期為<code>null</code>，則回傳空字串
	 */
	public static String getISODateTimeStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.ISO_DATETIME_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 取得SQL格式的日期時間字串
	 * 
	 * <pre>
	 * DateUtils.getSQLDateTimeStr(new Date()) = &quot;yyyy-MM-dd HH:mm:ss&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return 如果傳入日期為<code>null</code>，則回傳空字串
	 */
	public static String getSQLDateTimeStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.SQL_DATETIME_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 將ISO Date字串轉換成 java.util.Date
	 * 
	 * <pre>
	 * DateUtils.getISODate(&quot;2005-10-10&quot;, &quot;-&quot;) = Date(2005 - 10 - 10)
	 * </pre>
	 * 
	 * @param sISODate
	 * @param sLink
	 * @return
	 */
	public static java.util.Date getISODate(String sISODate, String sLink) {
		if (StringUtils.isBlank(sISODate)) {
			return null;
		}
		java.util.Date dt = null;
		// 有分隔符號
		if (StringUtils.isNotBlank(sLink)) {
			String[] tokens = sISODate.split(sLink);

			if (tokens.length == 3) {

				int iYear = ConvertUtils.str2Int(tokens[0]);
				int iMonth = ConvertUtils.str2Int(tokens[1]);
				int iDay = ConvertUtils.str2Int(tokens[2]);

				dt = DateUtils.getDate(iYear, iMonth, iDay);
			}
		}
		// 沒有分隔符號 YYYYMMDD
		else {

			if (sISODate.length() == 8) {
				int iYear = ConvertUtils.str2Int(sISODate.substring(0, 4));
				int iMonth = ConvertUtils.str2Int(sISODate.substring(4, 6));
				int iDay = ConvertUtils.str2Int(sISODate.substring(6, 8));
				dt = DateUtils.getDate(iYear, iMonth, iDay);
			}
		}
		return dt;
	}

	/**
	 * 將ISO DateTime字串轉換成 java.util.Date
	 * 
	 * <pre>
	 * DateUtils.getISODate(&quot;2005-10-10T12:34:56&quot;, &quot;-&quot;) = Date(2005-10-10T12:34:56)
	 * </pre>
	 * 
	 * @param sISODate
	 * @param sLink
	 * @return
	 */
	public static java.util.Date getISODateTime(String sISODateTime) {
		if (StringUtils.isBlank(sISODateTime)) {
			return null;
		}

		String sDateTimeLink = "T";
		String sDateLink = "-";
		String sTimeLink = ":";

		boolean isParseOK = true;

		java.util.Date dt = null;

		int iYear = 0;
		int iMonth = 0;
		int iDay = 0;
		int iHour = 0;
		int iMin = 0;
		int iSec = 0;

		String[] tokens = sISODateTime.split(sDateTimeLink);

		if (tokens.length == 2) {

			String sDate = tokens[0];
			String sTime = tokens[1];

			String[] dateTokens = sDate.split(sDateLink);

			if (dateTokens.length == 3) {
				iYear = ConvertUtils.str2Int(dateTokens[0]);
				iMonth = ConvertUtils.str2Int(dateTokens[1]);
				iDay = ConvertUtils.str2Int(dateTokens[2]);
			} else {
				isParseOK = false;
			}

			String[] timeTokens = sTime.split(sTimeLink);

			if (isParseOK && timeTokens.length == 3) {
				iHour = ConvertUtils.str2Int(timeTokens[0]);
				iMin = ConvertUtils.str2Int(timeTokens[1]);
				iSec = ConvertUtils.str2Int(timeTokens[2]);
			} else {
				isParseOK = false;
			}

		}

		if (isParseOK) {
			dt = DateUtils.getDateTime(iYear, iMonth, iDay, iHour, iMin, iSec);
		}

		return dt;
	}

	/**
	 * 將ISO Date字串轉換成 java.util.Date
	 * 
	 * <pre>
	 * DateUtils.getISODate(&quot;2005-10-10&quot;) = Date(2005 - 10 - 10)
	 * </pre>
	 * 
	 * @param sISODate
	 * @return
	 */
	public static java.util.Date getISODate(String sISODate) {
		return getISODate(sISODate, ISO_LINK);
	}

	/**
	 * 取得民國格式的日期字串
	 * 
	 * <pre>
	 * DateUtils.getROCDateStr(new Date()) = &quot;yyy-MM-dd&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return
	 */
	public static String getROCDateStr(java.util.Date dt) {
		return DateUtils.getROCDateStr(dt, DateUtils.ROC_LINK);
	}

	/**
	 * 取得民國格式的日期字串，以分隔子連接年、月、日
	 * 
	 * <pre>
	 * DateUtils.getROCDateStr(new Date(), &quot;-&quot;) = &quot;yyy-MM-dd&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @param sLink
	 * @return
	 */
	public static String getROCDateStr(java.util.Date dt, String sLink) {
		return getROCDateStr(dt, sLink, true);
	}

	/**
	 * 取得民國格式的日期字串，以分隔子連接年、月、日
	 * 
	 * <pre>
	 * DateUtils.getROCDateStr(new Date(), &quot;-&quot;) = &quot;yyy-MM-dd&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @param sLink
	 * @return
	 */
	public static String getROCDateStr(java.util.Date dt, String sLink, boolean isYearAppendZero) {
		if (dt == null) {
			return "";
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dt);

		// Date
		int iYear = calendar.get(Calendar.YEAR) - 1911;
		String sYear = String.valueOf(iYear);
		if (isYearAppendZero) {
			sYear = StringUtils.leftPad(sYear, 3, "0");
		}

		int iMonth = calendar.get(Calendar.MONTH) + 1;
		String sMonth = String.valueOf(iMonth);
		sMonth = StringUtils.leftPad(sMonth, 2, "0");

		int iDay = calendar.get(Calendar.DAY_OF_MONTH);
		String sDay = String.valueOf(iDay);
		sDay = StringUtils.leftPad(sDay, 2, "0");

		StringBuffer sb = new StringBuffer();
		sb.append(sYear).append(sLink).append(sMonth).append(sLink).append(sDay);

		return sb.toString();
	}

	/**
	 * 取得民國格式的日期時間字串
	 * 
	 * <pre>
	 * DateUtils.getROCDateTimeStr(new Date) = &quot;yyy/MM/dd HH:mm:ss&quot;;
	 * </pre>
	 * 
	 * @param dt
	 * @return
	 */
	public static String getROCDateTimeStr(java.util.Date dt) {
		return DateUtils.getROCDateTimeStr(dt, DateUtils.ROC_LINK);
	}

	/**
	 * 取得民國格式的日期時間字串，以分隔子連接年、月、日
	 * 
	 * <pre>
	 * DateUtils.getROCDateTimeStr(new Date(), &quot;/&quot;) = &quot;yyy/MM/dd HH:mm:ss&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @param sLink
	 * @return
	 */
	public static String getROCDateTimeStr(java.util.Date dt, String sLink) {
		String sDate = getROCDateStr(dt, sLink);
		String sTime = getISOTimeStr(dt);

		return sDate + " " + sTime;
	}

	/**
	 * 將民國年字串轉換成日期物件(code>java.util.Date</code>)
	 * 
	 * <pre>
	 * DateUtils.getROCDate(&quot;095/10/10&quot;, &quot;/&quot;) = Date(2005 - 10 - 10)
	 * </pre>
	 * 
	 * @param sRocDate
	 * @param sLink
	 * @return
	 */
	public static java.util.Date getROCDate(String sRocDate, String sLink) {
		if (StringUtils.isBlank(sRocDate)) {
			return null;
		}
		Date dt = null;
		// 有分隔符號
		if (StringUtils.isNotBlank(sLink)) {

			String[] tokens = sRocDate.split(sLink);

			if (tokens.length != 3) {
				return null;
			}

			int iYear = ConvertUtils.str2Int(tokens[0]) + 1911;
			int iMonth = ConvertUtils.str2Int(tokens[1]);
			int iDay = ConvertUtils.str2Int(tokens[2]);

			dt = DateUtils.getDate(iYear, iMonth, iDay);
		}
		// 沒有分隔符號
		else {
			int iLen = sRocDate.length();
			// cccMMdd / ccMMdd
			if (iLen == 7 || iLen == 6) {
				int iDay = ConvertUtils.str2Int(sRocDate.substring(iLen - 2));
				int iMonth = ConvertUtils.str2Int(sRocDate.substring(iLen - 4, iLen - 2));
				int iYear = ConvertUtils.str2Int(sRocDate.substring(0, iLen - 4));

				if (iYear > 0) {
					iYear += 1911;
					dt = DateUtils.getDate(iYear, iMonth, iDay);
				}
			}
		}
		return dt;
	}

	/**
	 * 將以民國格式的字串轉成日期物件(<code>java.util.Date</code>)
	 * 
	 * <pre>
	 * DateUtils.getROCDate(&quot;94/4/18&quot;) = Date(2005 - 4 - 18)
	 * </pre>
	 * 
	 * @param sRocDate
	 * @return
	 */
	public static java.util.Date getROCDate(String sRocDate) {
		return getROCDate(sRocDate, DateUtils.ROC_LINK);
	}

	/**
	 * 將DateTimeStr字串轉換成 java.util.Date
	 * 
	 * <pre>
	 * DateUtils.getDateByDateFormat(&quot;20051010123456789&quot;,&quot;yyyyMMddHHmmssSSS&quot;) = Date(2005-10-10 12:34:56789)
	 * </pre>
	 * 
	 * <p/>
	 * 異常ㄧ律回傳null
	 * 
	 * @param sSimpleDateTimeStr
	 * @return
	 */
	public static java.util.Date getDateByDateFormat(String sDateTimeStr, String sDateFormat) {
		try {
			SimpleDateFormat aDateFormat = new SimpleDateFormat(sDateFormat);
			return aDateFormat.parse(sDateTimeStr);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 將 Date物件轉換成String
	 * 
	 * <pre>
	 * DateUtils.getDateTimeStrByDateFormat(Date(2005-10-10 12:34:56789),&quot;yyyyMMddHHmmssSSS&quot;) = 20051010123456789
	 * </pre>
	 * 
	 * <p/>
	 * 異常ㄧ律回傳空字串
	 * 
	 * @param aDt
	 * @param sDateTimeFormat
	 * @return
	 */
	public static String getDateTimeStrByDateFormat(Date aDt, String sDateTimeFormat) {
		try {
			SimpleDateFormat aDateTimeFormat = new SimpleDateFormat(sDateTimeFormat);
			return aDateTimeFormat.format(aDt);
		} catch (Exception e) {
			return "";
		}
	}

	/**
	 * 取得簡易格式的日期時間字串
	 * 
	 * <pre>
	 * DateUtils.getSimpleDateTimeStr(new Date()) = &quot;yyyyMMddHHmmss&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return
	 */
	public static String getSimpleDateTimeStr(java.util.Date dt) {
		if (null == dt) {
			return "";
		}

		String sFormat = DateFormatUtils.SIMPLE_DATETIME_FORMAT.getPattern();
		return DateFormatUtils.format(dt, sFormat);
	}

	/**
	 * 取得現在時間
	 * 
	 * @return
	 */
	public static Date now() {
		return new Date();
	}

	/**
	 * 取得年份
	 * 
	 * @param dt
	 * @return
	 */
	public static int getYear(Date dt) {
		if (dt == null) {
			dt = now();
		}
		Calendar cal = ConvertUtils.date2Calendar(dt);
		return cal.get(Calendar.YEAR);
	}

	/**
	 * 取得年份
	 * 
	 * @param dt
	 * @return
	 */
	public static int getMonth(Date dt) {
		if (dt == null) {
			dt = now();
		}
		Calendar cal = ConvertUtils.date2Calendar(dt);
		return cal.get(Calendar.MONDAY) + 1;
	}

	public static int getDay(Date dt) {
		if (dt == null) {
			dt = now();
		}
		Calendar cal = ConvertUtils.date2Calendar(dt);
		return cal.get(Calendar.DAY_OF_MONTH);
	}

	/**
	 * 計算百年,此為先前算式並未更改邏輯,將yyyMMdd轉成yyy/MM/dd
	 * 
	 * @param count
	 * @return
	 */
	public static String formatRocDateString(String s) {
		return formatRocDateString(s, ROC_LINK);
	}

	public static String formatRocDateString(String s, String sLink) {
		if (StringUtils.isBlank(s)) {
			return "";
		}
		try { // 民國百年
			if (Integer.parseInt(s.substring(0, 2)) < 80)
				s = "1" + s;
		} catch (Exception ne) {
		}
		if (s.length() == 6)
			return s.substring(0, 2) + sLink + s.substring(2, 4) + sLink + s.substring(4, 6);
		if (s.length() == 7) // 民國百年
			return s.substring(0, 3) + sLink + s.substring(3, 5) + sLink + s.substring(5, 7);
		return s;
	}

	public static String format(org.apache.commons.lang.time.FastDateFormat pattern, Date dt) {
		try {
			if (dt == null) {
				return null;
			} else if (pattern == null) {
				dt.toString();
			}
			return DateFormatUtils.format(dt, pattern.getPattern());
		} catch (Exception e) {
			e.printStackTrace();
			return dt.toString();
		}
	}

	/**
	 * 設定每日的最(後)時分秒
	 * 
	 * @param date
	 * @return
	 */
	public static Date getDateEnd(Date date) {
		if (date == null) {
			return date;
		}
		Calendar cal = ConvertUtils.date2Calendar(date);
		cal = getDateEnd(cal);
		return cal.getTime();
	}

	public static Calendar getDateEnd(Calendar cal) {
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 999);
		return cal;
	}

	/**
	 * 設定每日的最(前)時分秒
	 * 
	 * @param date
	 * @return
	 */
	public static Date getDateStart(Date date) {
		if (date == null) {
			return date;
		}
		Calendar cal = ConvertUtils.date2Calendar(date);
		clearTime(cal);
		return cal.getTime();
	}

	/**
	 * 日期格式轉換,將文字字串轉成日期格式
	 * 
	 * @param pattern
	 * @param strDate
	 * @return
	 */
	public static Date parse(org.apache.commons.lang.time.FastDateFormat pattern, String strDate) {
		strDate = DateUtils.getEsbRsDate(strDate);
		if (StringUtils.isBlank(strDate)) {
			return null;
		}
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(pattern.getPattern());
			return dateFormat.parse(strDate);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 將yyyyMMdd轉成日期格式
	 * 
	 * @param dt
	 * @return
	 */
	public static Date getSimpleISODate(String simpleIsoDateStr) {
		return parse(DateFormatUtils.SIMPLE_ISO_DATE_FORMAT, DateUtils.getEsbRsDate(simpleIsoDateStr));
	}

	/**
	 * 將yyyyMM轉成日期格式
	 * 
	 * @param dt
	 * @return
	 */
	public static Date getSimpleISODateYYYYMM(String simpleIsoDateStr) {
		return parse(DateFormatUtils.yyyyMM, DateUtils.getEsbRsDate(simpleIsoDateStr));
	}
	
	/**
	 * 取得簡易格式的日期時間
	 * 
	 * <pre>
	 * DateUtils.getSimpleDateTime(new Date()) = &quot;yyyyMMddHHmmss&quot;
	 * </pre>
	 * 
	 * @param dt
	 * @return
	 */
	public static Date getSimpleDateTime(String simpleDateTime) {
		return parse(DateFormatUtils.SIMPLE_DATETIME_FORMAT, simpleDateTime);
	}

	/**
	 * 取得月份的列表
	 * 
	 * @return
	 */
	public static List<String> getMonthList() {
		List<String> result = new ArrayList<String>();
		for (int i = 1; i <= 12; i++) {
			result.add(StringUtils.leftPad("" + i, 2, '0'));
		}
		return result;
	}

	/**
	 * 取得日期的列表
	 * 
	 * @return
	 */
	public static List<String> getDateList() {
		List<String> result = new ArrayList<String>();
		for (int i = 1; i <= 31; i++) {
			result.add(StringUtils.leftPad("" + i, 2, '0'));
		}
		return result;
	}

	/**
	 * 取得指定月份的第一天
	 *
	 * @param date
	 * @return
	 */
	public static Date getMonthStart(Date date) {
		if (date == null) {
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		return cal.getTime();
	}

	/**
	 * 取得月的最後一天
	 *
	 * @param date
	 * @return
	 */
	public static Date getMonthEnd(Date date) {
		if (date == null) {
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}

	/**
	 * 取得DB查詢起日
	 * 
	 * 清除時分秒欄位
	 * 
	 * @param startDate
	 * @return
	 */
	public static Date getStartDate(Date startDate) {
		if (startDate == null) {
			return null;
		}
		Date date = (Date) startDate.clone();
		DateUtils.clearTime(date);
		return date;
	}

	/**
	 * 取得DB查詢迄日
	 * 
	 * 設定為23:59:59.999
	 * 
	 * @param endDate
	 * @return
	 */
	public static Date getEndDate(Date endDate) {
		if (endDate == null) {
			return null;
		}
		Calendar ca = ConvertUtils.date2Calendar(endDate);
		ca.set(Calendar.HOUR_OF_DAY, 23);
		ca.set(Calendar.MINUTE, 59);
		ca.set(Calendar.SECOND, 59);
		ca.set(Calendar.MILLISECOND, 999);
		Date date = ConvertUtils.calendar2Date(ca);
		return date;
	}

	/**
	 * 在某個區間中
	 * 
	 * @param date1
	 * @param date2
	 * @param num
	 * @return
	 */
	// public static boolean isDateInMonth(Date date1, Date date2, int num) {
	// int d1 = ConvertUtils.str2Int(DateUtils.getSimpleISODateStr(date1), -1);
	// int d2 = ConvertUtils.str2Int(DateUtils.getSimpleISODateStr(date2), -1);
	// if (d1 < 0 || d2 < 0) {
	// /* 轉型錯誤時會等於-1 */
	// return false;
	// } else {
	// if (d1 > d2) {
	// int tmp = d1;
	// d1 = d2;
	// d2 = tmp;
	// }
	// for (int i = 0; i < num; ++i) {
	// d1 += 100;
	// if ((d1 % 10000) / 100 > 12) {
	// d1 = d1 + 10000 - 1200;
	// }
	// }
	// return d2 <= d1;
	// }
	// }

	public static boolean isDateInMonth(Date date1, Date date2, int num) {
		int d1 = ConvertUtils.str2Int(DateUtils.getSimpleISODateStr(date1), -1);
		int d2 = ConvertUtils.str2Int(DateUtils.getSimpleISODateStr(date2), -1);
		if (d1 < 0 || d2 < 0) {
			/* 轉型錯誤時會等於-1 */
			return false;
		} else {
			if (d1 > d2) {
				int tmp = d1;
				d1 = d2;
				d2 = tmp;
			}
			if (isLastDay(date1)) {
				/** 取得最後一天 **/
				Date endDate = getMonthEnd(addMonths(date1, num));
				int endDateInt = ConvertUtils.str2Int(DateUtils.getSimpleISODateStr(endDate), -1);
				return d2 <= endDateInt && d2 >= d1;
			}
			for (int i = 0; i < num; ++i) {
				d1 += 100;
				if ((d1 % 10000) / 100 > 12) {
					d1 = d1 + 10000 - 1200;
				}
			}
			return d2 <= d1;
		}
	}

	public static boolean isLastDay(Date dt) {
		if (dt == null) {
			return false;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dt);
		int select = calendar.get(Calendar.DAY_OF_MONTH);
		int last = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		System.out.println(select + "," + last);
		return select == last;
	}

	public static String getYear(Calendar cal) {
		return String.valueOf(cal.get(Calendar.YEAR));
	}

	public static String getMonth(Calendar cal) {
		return check(String.valueOf(cal.get(Calendar.MONTH) + 1));
	}

	public static String getDay(Calendar cal) {
		return check(String.valueOf(cal.get(Calendar.DAY_OF_MONTH)));
	}

	public static String getHour(Calendar cal) {
		return check(String.valueOf(cal.get(Calendar.HOUR_OF_DAY)));
	}

	public static String getMinute(Calendar cal) {
		return check(String.valueOf(cal.get(Calendar.MINUTE)));
	}

	public static String getSecond(Calendar cal) {
		return check(String.valueOf(cal.get(Calendar.SECOND)));
	}

	public static String check(String value) {
		if (value.length() == 1) {
			value = "0" + value;
		} else if (value.length() == 0) {
			value = "00" + value;
		}
		return value;
	}

	/**
	 * 轉回該日期之前後幾天的日期
	 * 
	 * @param date_late:某個日期
	 * @param days:前後幾天,+,-
	 * @return String
	 */
	public static String chkDate(String date_late, int days) {
		// boolean isLate = false;
		Calendar cal = Calendar.getInstance();
		int d_year = Integer.parseInt(date_late.substring(0, 3));
		int d_mon = Integer.parseInt(date_late.substring(3, 5));
		int d_day = Integer.parseInt(date_late.substring(5));
		// if (d_year<100){
		d_year = d_year + 1911;
		// }
		cal.set(d_year, d_mon, d_day - 30);
		cal.add(Calendar.DATE, days);
		// int s_year=1911+Integer.parseInt(date_late.substring(0,2));
		// int s_month=Integer.parseInt(date_late.substring(2,4));
		// int s_day=Integer.parseInt(date_late.substring(4));
		int e_year = cal.get(1);
		int e_month = cal.get(2) + 1;
		int e_day = cal.get(5);

		String date_temp = String.valueOf(e_year - 1911) + check(String.valueOf(e_month))
				+ check(String.valueOf(e_day));
		if (date_temp.length() == 6) {
			date_temp = 0 + date_temp;
		}
		return date_temp;
	}

	/**
	 * function : 目前時間的民國曆 年月日
	 * 
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的民國曆 年月日字串
	 */
	public static String getCYMD(String separtor) {
		Calendar cal = Calendar.getInstance();
		int u_year = Integer.parseInt(getYear(cal)) - 1911;
		String tempY = (u_year > 99) ? String.valueOf(u_year) : "0" + String.valueOf(u_year);
		return tempY + separtor + getMonth(cal) + separtor + getDay(cal);
	}

	/**
	 * function : 目前時間的西元曆 年月日
	 * 
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的西元曆 年月日字串
	 */
	public static String getYMD(String separtor) {
		Calendar cal = Calendar.getInstance();
		return getYear(cal) + separtor + getMonth(cal) + separtor + getDay(cal);
	}

	/**
	 * function : 目前時間的西元曆 月日年
	 * 
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的西元曆 月日年字串
	 */
	public static String getMDY(String separtor) {
		Calendar cal = Calendar.getInstance();
		return getMonth(cal) + separtor + getDay(cal) + separtor + getYear(cal);
	}

	/**
	 * function : 目前時間的西元曆 日月年
	 * 
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 目前時間的西元曆 日月年字串
	 */
	public static String getDMY(String separtor) {
		Calendar cal = Calendar.getInstance();
		return getDay(cal) + separtor + getMonth(cal) + separtor + getYear(cal);
	}

	/**
	 * function : 目前時間的時分秒
	 * 
	 * @param separtor String , 時分秒的分隔符號 Ex: "-","\",".",":"
	 * @return 目前時間的西元曆 時分秒字串
	 */
	public static String getTime(String separtor) {
		Calendar cal = Calendar.getInstance();
		return getHour(cal) + separtor + getMinute(cal) + separtor + getSecond(cal);
	}

	/**
	 * function : 目前時間的前後X天的日期字串
	 * 
	 * @param days     int, 加減的天數
	 * @param separtor String , 年月日的分隔符號 Ex: "-","\","."
	 * @return 民國曆 年月日字串
	 */
	public static String getBeforeDate(int days, String separtor) {
		Calendar date = Calendar.getInstance();
		date.add(Calendar.DATE, days);
		String year = String.valueOf(date.get(date.YEAR));
		String month = check(String.valueOf(date.get(date.MONTH) + 1));
		String day = check(String.valueOf(date.get(date.DAY_OF_MONTH)));

		String temp = getCYMD("");
		date.add(GregorianCalendar.DATE, -days);
		year = String.valueOf(date.get(date.YEAR));
		month = check(String.valueOf(date.get(date.MONTH) + 1));
		day = check(String.valueOf(date.get(date.DAY_OF_MONTH)));
		return temp;
	}

	public static String getBeforeDate(String base, int days, String separtor) {
		int year1 = 0;
		int month1 = 0;
		int day1 = 0;

		if (base.length() == 7) {
			year1 = Integer.parseInt(base.substring(0, 3)) + 1911;
			month1 = Integer.parseInt(base.substring(3, 5));
			day1 = Integer.parseInt(base.substring(5, 7));
		} else if (base.length() == 8) {
			year1 = Integer.parseInt(base.substring(0, 4));
			month1 = Integer.parseInt(base.substring(4, 6));
			day1 = Integer.parseInt(base.substring(6, 8));
		}

		Calendar date = Calendar.getInstance();
		date.set(year1, month1 - 1, day1);
		date.add(Calendar.DATE, days);
		int year = date.get(Calendar.YEAR);
		String month = check(String.valueOf(date.get(Calendar.MONTH) + 1));
		String day = check(String.valueOf(date.get(Calendar.DAY_OF_MONTH)));

		int u_year = year - 1911;
		String tempY = (u_year > 99) ? String.valueOf(u_year) : "0" + String.valueOf(u_year);
		return tempY + separtor + month + separtor + day;
	}

	/**
	 * 日期之加減
	 * 
	 * @param field,  日期欄位【年 or 月 or 日】
	 * @param amount, 加減之數量
	 * @param date,   欲作加減之日期【YYYMMDD】
	 * @return String
	 */
	public static String add(int field, int amount, String date) {
		String year = "";
		String month = "";
		String day = "";
		year = date.substring(0, 3);
		month = date.substring(3, 5);
		day = date.substring(5, 7);
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, Integer.parseInt(year) + 1911);
		calendar.set(Calendar.MONTH, Integer.parseInt(month) - 1);
		calendar.set(Calendar.DATE, Integer.parseInt(day));
		calendar.add(field, amount);
		year = String.valueOf(calendar.get(Calendar.YEAR) - 1911);
		for (; year.length() < 3;) {
			year = "0" + year;
		}
		month = String.valueOf(calendar.get(Calendar.MONTH) + 1);
		for (; month.length() < 2;) {
			month = "0" + month;
		}
		day = String.valueOf(calendar.get(Calendar.DATE));
		for (; day.length() < 2;) {
			day = "0" + day;
		}
		return year + month + day;
	}

	public static String getDate(String date) {
		String year = "";
		String month = "";
		String day = "";
		year = date.substring(0, 3);
		month = date.substring(3, 5);
		day = date.substring(5, 7);
		return (Integer.parseInt(year) + 1911) + month + day;
	}

	/**
	 * 取得從date 開始，並加上incMonth月的日期
	 * 
	 * @param date
	 * @param month
	 * @return
	 */
	public static String getDate(String date, int incMonth) {
		boolean isLate = false;
		Calendar cal = Calendar.getInstance();
		int d_year = Integer.parseInt(date.substring(0, 3));
		int d_mon = Integer.parseInt(date.substring(3, 5));
		int d_day = Integer.parseInt(date.substring(5));
		d_year = d_year + 1911;
		cal.set(d_year, d_mon - 1, d_day);
		cal.set(cal.MONTH, cal.get(cal.MONTH) + incMonth);
		int e_year = cal.get(1);
		int e_month = cal.get(2) + 1;
		int e_day = cal.get(5);

		String date_temp = String.valueOf(e_year - 1911) + check(String.valueOf(e_month))
				+ check(String.valueOf(e_day));
		if (date_temp.length() == 6) {
			date_temp = 0 + date_temp;
		}
		return date_temp;

	}

	/**
	 * 輸入差異值(月份) 功式如下: 系統日期-差異值(月份) 情況1:今日為(930929) - 7 = 930229, 傳回 [0]=930229 ,
	 * [1]=930231 情況2:今日為(920929) - 7 = 930228, 傳回 [0]=920228 , [1]=920231
	 * 情況3:今日為(920930) - 3 = 930630, 傳回 [0]=930630 , [1]=930631
	 * 
	 * @param diffmonth int 差異值(月份)
	 * @return 傳回差異日期-開始日期[0],結束日期[1]
	 */

	public static String[] getDateOnRangeWithMonth(int diffmonth) {
		String[] sret = new String[2];
		try {

			if (diffmonth >= 1 && diffmonth <= 12) {
				String yyyymmdd_Today = getYMD("");
				Calendar cal = Calendar.getInstance();
				cal.add(cal.MONTH, 0 - diffmonth);

				// 取得當年月份的最大天數
				int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
				String smonth = String.valueOf(cal.get(Calendar.MONTH) + 1);
				for (; smonth.length() < 2;) {
					smonth = "0" + smonth;
				}
				String sday = String.valueOf(cal.get(Calendar.DATE));
				for (; sday.length() < 2;) {
					sday = "0" + sday;

				}
				String startDate = "";
				String endDate = "";
				if (Integer.parseInt(sday) > maxDay) {
					startDate = "" + (cal.get(Calendar.YEAR) - 1911) + "" + smonth + maxDay;
				}
				startDate = "" + (cal.get(Calendar.YEAR) - 1911) + "" + smonth + sday;
				endDate = "" + (cal.get(Calendar.YEAR) - 1911) + "" + smonth + "31";
				sret[0] = startDate;
				sret[1] = endDate;
				return sret;
			}
			return null;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	/**
	 * 輸入差異值(天數) 功式如下: 系統日期-差異值(天數) 情況1:今日為(930929) - 7 = 930229, 傳回 [0]=930229 ,
	 * [1]=930231 情況2:今日為(920929) - 7 = 930228, 傳回 [0]=920228 , [1]=920231
	 * 情況3:今日為(920930) - 3 = 930630, 傳回 [0]=930630 , [1]=930631
	 * 
	 * @param diffmonth int 差異值(天數)
	 * @return 傳回差異日期-開始日期[0],結束日期[1]
	 */

	public static String[] getDateOnRangeWithDay(int diffday) {
		String[] sret = new String[2];
		try {
			if (diffday >= 1 && diffday <= 365) {
				Calendar cal = Calendar.getInstance();
				cal.add(cal.DATE, 0 - diffday);

				// 取得當年月份的最大天數
				int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
				String smonth = String.valueOf(cal.get(Calendar.MONTH) + 1);
				for (; smonth.length() < 2;) {
					smonth = "0" + smonth;
				}
				String sday = String.valueOf(cal.get(Calendar.DATE));
				for (; sday.length() < 2;) {
					sday = "0" + sday;

				}
				String startDate = "";
				String endDate = "";
				if (Integer.parseInt(sday) > maxDay) {
					startDate = "" + (cal.get(Calendar.YEAR) - 1911) + "" + smonth + maxDay;
				}
				startDate = "" + (cal.get(Calendar.YEAR) - 1911) + "" + smonth + sday;
				endDate = "" + (cal.get(Calendar.YEAR) - 1911) + "" + smonth + "31";
				sret[0] = startDate;
				sret[1] = endDate;
				return sret;
			}
			return null;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	/**
	 * function : 求出兩日期的差距天數
	 * 
	 * @param String first_date
	 * @param String end_date
	 * @return 差距天數 days
	 */

	public static int getBetweenDays(String first_date, String end_date) {
		int days = 0;
		if (first_date.length() == 6) {
			first_date = "0" + first_date;
		}
		if (end_date.length() == 6) {
			end_date = "0" + end_date;
		}

		if (Integer.parseInt(end_date) > Integer.parseInt(first_date)) {
			while (true) {
				if (days > 20000) {
					break;
				}
				days++;
				if (end_date.equals(getBeforeDate(first_date, days, ""))) {
					break;
				}
			}
		}
		return days + 1;
	}

	public static String convertToRocDate() { // 傳回日期
		String sd = (new java.text.SimpleDateFormat("yyyyMMdd")).format(new java.util.Date());
		String cy = String.valueOf(Integer.parseInt(sd.substring(0, 4)) - 1911);
		return cy + "年" + sd.substring(4, 6) + "月" + sd.substring(6, 8) + "日";
	}

	public static String convertToRocTime() { // 傳回時間
		String sd = (new java.text.SimpleDateFormat("yyyyMMdd HHmmss")).format(new java.util.Date());
		return sd.substring(9, 11) + ":" + sd.substring(11, 13) + ":" + sd.substring(13, 15);
	}

	/**
	 * function : 日期比較，取出較新的日期
	 * 
	 * @param String 日期1
	 * @param String 日期2
	 * @return 較新的日期
	 */
	public static Date max(Date d1, Date d2) {
		if (d1 == null) {
			return d2;
		} else if (d2 == null) {
			return d1;
		}
		return d2.before(d1) ? d1 : d2;
	}

	/**
	 * function : 日期比較，取出較舊的日期
	 * 
	 * @param String 日期1
	 * @param String 日期2
	 * @return 較舊的日期
	 */
	public static Date min(Date d1, Date d2) {
		if (d1 == null) {
			return d2;
		} else if (d2 == null) {
			return d1;
		}
		return d2.after(d1) ? d1 : d2;
	}

	public static String transRocDate(String date) {
		if (date.length() == 6) { // 民國百年
			try {
				if (Integer.parseInt(date.substring(0, 2)) < 80) {
					return "1" + date;
				}
			} catch (Exception ne) {
			}
		}
		return date;
	}

	public static boolean isBetween(Date date, Date date1, Date date2) {
		if (date1.before(date2))
			return date1.compareTo(date) <= 0 && date2.compareTo(date) >= 0;
		else
			return date2.compareTo(date) <= 0 && date1.compareTo(date) >= 0;
	}

	/**
	 * 是否在時間內
	 * 
	 * @param sTime
	 * @param eTime
	 * @param dt
	 * @return
	 */
	public static int isTimeInRange(String sTimeStr, String eTimeStr, Date dt) {
		if (StringUtils.length(sTimeStr) != 6 || StringUtils.length(sTimeStr) != 6 || dt == null) {
			return 0;
		} else {
			int sTime = ConvertUtils.str2Int(sTimeStr, -1);
			int eTime = ConvertUtils.str2Int(eTimeStr, -1);
			if (sTime == -1 || eTime == -1) {
				return 0;
			} else {
				int startTime_Hour = ConvertUtils.str2Int(sTimeStr.substring(0, 2));
				int endTime_Hour = ConvertUtils.str2Int(eTimeStr.substring(0, 2));
				if (startTime_Hour > 24 || endTime_Hour > 24) {
					return 0;
				}
				int startTime_Minute = ConvertUtils.str2Int(sTimeStr.substring(2, 4));
				int endTime_Minute = ConvertUtils.str2Int(eTimeStr.substring(2, 4));
				if (startTime_Minute > 60 || endTime_Minute > 60) {
					return 0;
				}
				int startTime_Second = ConvertUtils.str2Int(sTimeStr.substring(4, 6));
				int endTime_Second = ConvertUtils.str2Int(eTimeStr.substring(4, 6));
				if (startTime_Second > 60 || endTime_Second > 60) {
					return 0;
				}
			}

			if (sTime > eTime) {
				int temp = eTime;
				sTime = eTime;
				eTime = temp;
			}
			int nowTtime = ConvertUtils.str2Int(getSimpleISOTimeStr(dt));

			if (nowTtime >= sTime && nowTtime <= eTime) {
				return nowTtime;
			}

			return 0;
		}

	}

	public static boolean isDateInRange(Date date, Date date1, int i, int j) throws IllegalArgumentException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date1);
		switch (i) {
		case 1: // '\001'
			calendar.add(1, j);
			break;

		case 2: // '\002'
			calendar.add(2, j);
			break;

		case 5: // '\005'
			calendar.add(5, j);
			break;

		case 11: // '\013'
			calendar.add(11, j);
			break;

		case 12: // '\f'
			calendar.add(12, j);
			break;

		case 13: // '\r'
			calendar.add(13, j);
			break;

		case 14: // '\016'
			calendar.add(14, j);
			break;

		case 3: // '\003'
		case 4: // '\004'
		case 6: // '\006'
		case 7: // '\007'
		case 8: // '\b'
		case 9: // '\t'
		case 10: // '\n'
		default:
			throw new IllegalArgumentException(
					"Incorrect field ID: ".concat(String.valueOf(String.valueOf(String.valueOf(i)))));
		}
		return isBetween(date, date1, calendar.getTime());
	}

	public static int[] timeSplitBetween(Date date, Date date1) {
		int ai[] = { 0, 0, 0, 0, 0 };
		int ai1[] = { 0x5265c00, 0x36ee80, 60000, 1000, 1 };
		long l;
		if (date1.after(date))
			l = date1.getTime() - date.getTime();
		else
			l = date.getTime() - date1.getTime();
		for (int i = 0; l > (long) 0; i++) {
			ai[i] = (int) l / ai1[i];
			l %= ai1[i];
		}

		return ai;
	}

	public static int daysBetween(Date date, Date date1) {
		int ai[] = timeSplitBetween(zeroOutTime(date), zeroOutTime(date1));
		return ai[0];
	}

	public static Date getTodaysDate() {
		GregorianCalendar gregoriancalendar = new GregorianCalendar();
		gregoriancalendar.set(11, 0);
		gregoriancalendar.set(12, 0);
		gregoriancalendar.set(13, 0);
		gregoriancalendar.set(14, 0);
		return gregoriancalendar.getTime();
	}

	public static Date parseDateString(String s, String s1) throws ClassCastException, ParseException {
		SimpleDateFormat simpledateformat = new SimpleDateFormat(s1);
		ParsePosition parseposition = new ParsePosition(0);
		Date date = simpledateformat.parse(s, parseposition);
		if (date == null) {
			int i = parseposition.getErrorIndex();
			throw new ParseException(
					String.valueOf(String.valueOf((new StringBuffer("Not a valid date: illegal char found \""))
							.append(s.substring(i, i + 1)).append("\"..."))),
					i);
		} else {
			return date;
		}
	}

	public static Date parseDateFields(int i, int j, int k, int l, int i1, int j1) throws ClassCastException {
		Calendar calendar = makeCalendar(i, j, k, l, i1, j1);
		if (calendar.get(1) != i || calendar.get(2) != j - 1 || calendar.get(5) != k || calendar.get(11) != l
				|| calendar.get(12) != i1 || calendar.get(13) != j1)
			throw new ClassCastException("Date is not valid...");
		else
			return calendar.getTime();
	}

	public static Date parseDateFields(String s, String s1, String s2, String s3, String s4, String s5)
			throws ClassCastException, NumberFormatException {
		return parseDateFields(Integer.parseInt(s), Integer.parseInt(s1), Integer.parseInt(s2), Integer.parseInt(s3),
				Integer.parseInt(s4), Integer.parseInt(s5));
	}

	public static Date parseDateFields(String s, String s1, String s2)
			throws ClassCastException, NumberFormatException {
		return parseDateFields(Integer.parseInt(s), Integer.parseInt(s1), Integer.parseInt(s2), 0, 0, 0);
	}

	public static Date parseROCDateFields(String s, String s1, String s2) throws ClassCastException, ParseException {
		return parseDateFields(Integer.parseInt(s) + 1911, Integer.parseInt(s1), Integer.parseInt(s2), 0, 0, 0);
	}

	public static int[] parseAndSplitDateString(String s, String s1) throws ClassCastException, ParseException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(parseDateString(s, s1));
		int ai[] = new int[7];
		ai[0] = calendar.get(1);
		ai[1] = calendar.get(2) + 1;
		ai[2] = calendar.get(5);
		ai[3] = calendar.get(11);
		ai[4] = calendar.get(12);
		ai[5] = calendar.get(13);
		ai[6] = calendar.get(14);
		return ai;
	}

	public static int[] parseAndSplitDateString(Date date) throws ClassCastException, ParseException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int ai[] = new int[7];
		ai[0] = calendar.get(1);
		ai[1] = calendar.get(2) + 1;
		ai[2] = calendar.get(5);
		ai[3] = calendar.get(11);
		ai[4] = calendar.get(12);
		ai[5] = calendar.get(13);
		ai[6] = calendar.get(14);
		return ai;
	}

	public static boolean isValid(int i, int j, int k) {
		boolean flag1;
		try {
			Date date = parseDateFields(i, j, k, 0, 0, 0);
			boolean flag = true;
			return flag;
		} catch (Exception exception) {
			flag1 = false;
		}
		return flag1;
	}

	public static boolean isValid(String s, String s1, String s2) {
		boolean flag1;
		try {
			Date date = parseDateFields(s, s1, s2);
			boolean flag = true;
			return flag;
		} catch (Exception exception) {
			flag1 = false;
		}
		return flag1;
	}

	public static boolean isValid(String s, String s1) {
		boolean flag1;
		try {
			Date date = parseDateString(s, s1);
			boolean flag = true;
			return flag;
		} catch (Exception exception) {
			flag1 = false;
		}
		return flag1;
	}

	private static Calendar makeCalendar(int i, int j, int k, int l, int i1, int j1) {
		j--;
		return new GregorianCalendar(i, j, k, l, i1, j1);
	}

	private static Date zeroOutTime(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(11, 0);
		calendar.set(12, 0);
		calendar.set(13, 0);
		calendar.set(14, 0);
		return calendar.getTime();
	}

	/**
	 * yyyy/MM/dd
	 * 
	 * @param date
	 * @return
	 */
	public static String getCeDateStr(Date date) {
		return format(DateFormatUtils.CE_DATE_FORMAT, date);
	}

	/**
	 * yyyy/MM/dd HH:mm:ss
	 * 
	 * @param date
	 * @return
	 */
	public static String getCeDateTimeStr(Date date) {
		return format(DateFormatUtils.CE_DATETIME_FORMAT2, date);
	}

	/**
	 * Date to yyyy年MM月dd日
	 * 
	 * @param date
	 * @return
	 */
	public static String getCnDateStr(Date date) {
		try{
			return new SimpleDateFormat("yyyy年MM月dd日").format(date);
		} catch (Exception e) {
			return "";
		}
		
	}
	
	// public static final String slashDateFormat = new String("yyyy/MM/dd");
	// public static final String SQLEscapeDateFormat = new
	// String("yyyy-MM-dd");
	// public static final String SQLEscapeTimeFormat = new String("HH:mm:ss");
	// public static final String standard12HourTimeFormat = new
	// String("hh:mm:ss");
	// public static final String expandedDateTimeFormat = new
	// String("yyyy/MM/dd HH:mm:ss.SSS");
	// public static final String SQLEscapeTimestampFormat = new
	// String("yyyy-MM-dd HH:mm:ss.SSS");
	public static final int numOfMillisInAMilli = 1;
	public static final int numOfMillisInASecond = 1000;
	public static final int numOfMillisInAMinute = 60000;
	public static final int numOfMillisInAnHour = 0x36ee80;
	public static final int numOfMillisInADay = 0x5265c00;

	/**
	 * 
	 * @param model
	 * @return
	 */
	public static Date[] getQueryRangeDate(ISelectDate model) {
		Date now = DateUtils.now();
		int item = ConvertUtils.str2Int(model.getSelectItem(), -1);
		Date[] date = new Date[2];

		switch (item) {
		case 1:
			/** 特定日期 西元 **/
			date[0] = DateUtils.getDateStart(
					DateUtils.getDate(model.getSelectYear(), model.getSelectMonth(), model.getSelectDay()));
			date[1] = DateUtils
					.getDateEnd(DateUtils.getDate(model.getSelectYear(), model.getSelectMonth(), model.getSelectDay()));
			break;
		case 2:
			/** 最近一週 **/
			date[0] = DateUtils.getDateStart(DateUtils.addDays(now, -7));
			date[1] = DateUtils.getDateEnd(now);
			break;
		case 3:
			/** 最近一個月 **/
			date[0] = DateUtils.getDateStart(DateUtils.addMonths(now, -1));
			date[1] = DateUtils.getDateEnd(now);
			break;
		case 4:
			/** 最近三個月 **/
			date[0] = DateUtils.getDateStart(DateUtils.addMonths(now, -3));
			date[1] = DateUtils.getDateEnd(now);
			break;
		case 5:
			/** 自行輸入 **/
			date[0] = DateUtils.getDateStart(DateUtils.getDate(model.getSelectStartYear(), model.getSelectStartMonth(),
					model.getSelectStartDay()));
			date[1] = DateUtils.getDateEnd(
					DateUtils.getDate(model.getSelectEndYear(), model.getSelectEndMonth(), model.getSelectEndDay()));
			break;
		}
		return date;
	}

	/**
	 * 當m1=m2時為0 當m1!=m2時 d1s,d2e時m2-m1+1 d1<=d2時m2-m1 d1>=d2時m2-m1-1 d2e時m2-m1
	 * 
	 * @param s1
	 * @param s2
	 * @return
	 */
	public static int calcDepositTerm(String s1, String s2) {
		if (StringUtils.isBlank(s1) || StringUtils.isBlank(s2)) {
			/** 異常 **/
			return -1;
		}

		Calendar dt1 = ConvertUtils.date2Calendar(DateUtils.getSimpleISODate(s1));
		Calendar dt2 = ConvertUtils.date2Calendar(DateUtils.getSimpleISODate(s2));
		if (dt1.getTimeInMillis() > dt2.getTimeInMillis()) {
			Calendar temp = dt2;
			dt1 = dt2;
			dt2 = temp;
		}
		int y1 = dt1.get(Calendar.YEAR);
		int m1 = dt1.get(Calendar.MONTH) + 1;
		int d1 = dt1.get(Calendar.DAY_OF_MONTH);
		int y2 = dt2.get(Calendar.YEAR);
		int m2 = dt2.get(Calendar.MONTH) + 1;
		int d2 = dt2.get(Calendar.DAY_OF_MONTH);

		int result = -1;
//		if (m1 == m2) {
//			result = (y2 - y1) * 12;
//		} else {
		Calendar edt2 = getLastMonthDay(dt2);
		int ed2 = edt2.get(Calendar.DAY_OF_MONTH);
		if (d1 == 1 && ed2 == d2) {
			/** d1s,d2e時m2-m1+1 **/
			result = ((y2 - y1) * 12) + m2 - m1 + 1;
		}
		if ((d1 <= d2) || (ed2 == d2)) {
			/** d1s,d2e時m2-m1+1 **/
			result = ((y2 - y1) * 12) + m2 - m1;
		} else {
			result = ((y2 - y1) * 12) + m2 - m1 - 1;
		}
//		}

		// System.out.println("開始日=" + s1 + ",止日=" + s2 + ",存期=" + result);
		return result;
	}

	/**
	 * 每個月的最後一天日期
	 * 
	 * @param calendar
	 * @return
	 */
	public static Calendar getLastMonthDay(Calendar calendar) {
		Calendar c = Calendar.getInstance();
		c.setTime(calendar.getTime());
		c.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
		return c;
	}

	public static String getEsbRsDate(String dt) {
		return getEsbRsDate(dt, null);
	}

	public static String getEsbRsDate(String dt, String defaultValue) {
		if (StringUtils.isNotBlank(dt)) {
			for (int i = 0; i < dt.length(); i++) {
				if (dt.charAt(i) != '0') {
					return dt;
				}
			}
		}
		return defaultValue;
	}

	public static String formatTimeString(String time) {
		return formatTimeString(time, ":");
	}

	/**
	 * 
	 * @param s
	 * @param sLink
	 * @return
	 */
	public static String formatTimeString(String s, String sLink) {
		if (StringUtils.isBlank(s)) {
			return "";
		}
		s = StringUtils.replace(s, ":", "");

		if (s.length() == 4) {
			return s.substring(0, 2) + sLink + s.substring(2, 4);
		} else if (s.length() >= 6) {
			return s.substring(0, 2) + sLink + s.substring(2, 4) + sLink + s.substring(4, 6);
		}
		// if (s.length() == 8) // 民國百年
		// return s.substring(0, 3) + sLink + s.substring(3, 5) + sLink +
		// s.substring(5, 7);
		return s;
	}

	public static void main(String[] args) {
		try {
			System.out.println(formatTimeString(null));
			System.out.println(formatTimeString("12:30:44"));
			System.out.println(formatTimeString("123044"));

			System.out.println(getEsbRsDate("01203"));

			System.out.println(isTimeInRange("080000", "090000", DateUtils.now()));
			System.out.println(isTimeInRange("080000", "100000", DateUtils.now()));
			System.out.println(isTimeInRange("093500", "230000", DateUtils.now()));

			// String dateStr = "310201";
			//
			// SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
			//
			// Date dt = format.parse(dateStr);
			//
			// System.out.println("date = " + dt);
			// System.out.println(isDateInMonth(getDate(2016, 2, 29),
			// getDate(2016, 8, 31), 6));
			// Date dt = getDateByDateFormat("310201", "yyMMdd");
			// System.out.println("date = " + dt);
			// dt = getDateByDateFormat("320101", "yyMMdd");
			// System.out.println("date = " + dt);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 取得年齡
	 * 
	 * @param d
	 * @return
	 */
	public static int getAge(Date d) {
		if (d == null) {
			return 0;
		}
		Calendar nowCal = Calendar.getInstance();
		Calendar birthdayCal = Calendar.getInstance();
		birthdayCal.setTime(d);
		int age = nowCal.get(Calendar.YEAR) - birthdayCal.get(Calendar.YEAR);
		birthdayCal.set(Calendar.YEAR, nowCal.get(Calendar.YEAR));
		if (nowCal.getTime().getTime() < birthdayCal.getTime().getTime()) {
			age--;
		}
		return age;
	}

	/**
	 * 將民國年/西元年轉換成日期物件(code>java.util.Date</code>)
	 * 
	 * <pre>
	 * DateUtils.getROCDate(&quot;095/10/10&quot;, &quot;/&quot;) = Date(2005 - 10 - 10)
	 * </pre>
	 * 
	 * @param sRocDate
	 * @param sLink
	 * @return
	 */
	public static java.util.Date getROCDate2(String sRocDate, String sLink) {
		if (StringUtils.isBlank(sRocDate)) {
			return null;
		}
		Date dt = null;
		// 有分隔符號
		if (StringUtils.isNotBlank(sLink)) {
			String[] tokens = sRocDate.split(sLink);
			if (tokens.length != 3) {
				return null;
			}
			int iYear = ConvertUtils.str2Int(tokens[0]);
			if (StringUtils.length(tokens[0]) < 4) {
				/** 轉成西元年 **/
				iYear = iYear + 1911;
			}
			int iMonth = ConvertUtils.str2Int(tokens[1]);
			int iDay = ConvertUtils.str2Int(tokens[2]);
			dt = DateUtils.getDate(iYear, iMonth, iDay);
		} else {
			// 沒有分隔符號
			int iLen = StringUtils.length(sRocDate);
			// cccMMdd / ccMMdd
			if (iLen == 7 || iLen == 6) {
				int iDay = ConvertUtils.str2Int(sRocDate.substring(iLen - 2));
				int iMonth = ConvertUtils.str2Int(sRocDate.substring(iLen - 4, iLen - 2));
				int iYear = ConvertUtils.str2Int(sRocDate.substring(0, iLen - 4));

				if (iYear > 0) {
					iYear += 1911;
					dt = DateUtils.getDate(iYear, iMonth, iDay);
				}
			} else if (iLen == 8) {
				/** yyyyMMdd **/
				int iDay = ConvertUtils.str2Int(sRocDate.substring(iLen - 2));
				int iMonth = ConvertUtils.str2Int(sRocDate.substring(iLen - 4, iLen - 2));
				int iYear = ConvertUtils.str2Int(sRocDate.substring(0, iLen - 4));

				if (iYear > 0) {
					// iYear += 1911;
					dt = DateUtils.getDate(iYear, iMonth, iDay);
				}
			}
		}
		return dt;
	}

	public static Date parseDate(String dt) {
		Date d = null;
		try {
			d = org.apache.commons.lang3.time.DateUtils.parseDate(dt,
					new String[] { "yyyyMMdd", "yyyy-MM-dd", "yyyy/MM/dd" });
		} catch (Throwable cause) {

		}
		return d;
	}

}

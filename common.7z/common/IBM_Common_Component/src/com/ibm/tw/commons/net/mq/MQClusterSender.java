/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * The MQ Sender for Cluster Queue
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import com.ibm.mq.MQException;

/**
 * @author jeff
 * @version 1.0, 2006/2/9
 * @see
 * @since
 */
public class MQClusterSender extends MQBase {

	/**
	 * connect to mq cluster queue
	 * 
	 * TODO:待測試
	 * 
	 */
	public void connect(String sQueueManagerName, String sQueueName) throws MQException {

		connect(sQueueManagerName, sQueueName, MQBase.MQ_CLWRITE);

	}

}

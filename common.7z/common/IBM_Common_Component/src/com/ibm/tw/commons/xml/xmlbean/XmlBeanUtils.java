
package com.ibm.tw.commons.xml.xmlbean;

import java.util.ArrayList;
import java.util.List;

import org.apache.xmlbeans.XmlError;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;

import com.ibm.tw.commons.util.StringUtils;

public class XmlBeanUtils {

	public final static String XMLBEAN_START_TAG = "<xml-fragment";
	public final static String XMLBEAN_END_TAG = "</xml-fragment>";

	/**
	 * <p>
	 * Validates the XML, printing error messages when the XML is invalid. Note
	 * that this method will properly validate any instance of a compiled schema
	 * type because all of these types extend XmlObject.
	 * </p>
	 * 
	 * <p>
	 * Note that in actual practice, you'll probably want to use an assertion
	 * when validating if you want to ensure that your code doesn't pass along
	 * invalid XML. This sample prints the generated XML whether or not it's
	 * valid so that you can see the result in both cases.
	 * </p>
	 * 
	 * @param xml
	 *            The XML to validate.
	 */
	public static void validate(XmlObject xml) throws XmlBeanException {

		if (null == xml) {
			return;
		}

		boolean isXmlValid = false;

		// A collection instance to hold validation error messages.
		List<XmlError> validationMessages = new ArrayList<XmlError>();

		// Validate the XML, collecting messages.
		isXmlValid = xml.validate(new XmlOptions().setErrorListener(validationMessages));

		// If the XML isn't valid, print the messages.

		if (!isXmlValid) {
			/*
			 * StringBuffer sb = new StringBuffer("XML isn't valid:\n\n"); for
			 * (int i = 0; i < validationMessages.size(); i++) { XmlError error
			 * = (XmlError) validationMessages.get(i);
			 * 
			 * sb.append("Error[" + i + "]: "); sb.append(error.toString());
			 * 
			 * System.out.println("error " + i + ": " + error.toString()); }
			 */
			XmlBeanException ex = new XmlBeanException("XML is not valid");

			ex.setValidationMessages(validationMessages);

			throw ex;
		}

	}

	public static String toXml(XmlObject doc) {

		if (null == doc) {
			return "";
		}
		String sXml = doc.xmlText(getXmlOptions());

		return sXml;
	}

	public static XmlOptions getXmlOptions() {
		XmlOptions xmlOptions = new XmlOptions();

		// Requests use of whitespace for easier reading
		xmlOptions.setSavePrettyPrint();

		// Requests that nested levels of the xml
		// document to be indented by multiple of 4
		// whitespace characters
		xmlOptions.setSavePrettyPrintIndent(4);
		xmlOptions.setSaveCDataLengthThreshold(1);
		xmlOptions.setUseCDataBookmarks();
		// xmlOptions.setLoadStripWhitespace();

		return xmlOptions;

	}

	/**
	 * XmlBean 會自動加上 <<xml-fragment> and </xml-fragment>
	 * 所以必須過濾此TAG
	 * 
	 * @return
	 */
	public static String filter(String sXML) {

		String sValue = "";

		int iStartPos = sXML.indexOf(XmlBeanUtils.XMLBEAN_START_TAG);

		// 未發現 <xml-fragment
		if (iStartPos < 0) {
			return sXML;
		}
		try {

			// filter <xml-fragment ...>
			// sXML = StringUtils.replace(sXML, XMLBEAN_START_TAG, "");

			int iEndPos = -1;
			if (iStartPos >= 0) {
				iEndPos = sXML.indexOf(">", iStartPos);
			}

			StringBuffer sb = new StringBuffer();

			if (iStartPos > 0) {
				sb.append(sXML.substring(0, iStartPos));
			}

			if (iEndPos > iStartPos) {
				sb.append(sXML.substring(iEndPos + 1, sXML.length()));
			}

			// filter </xml-fragment>
			sValue = StringUtils.replace(sb.toString(), XMLBEAN_END_TAG, "");

		} catch (Exception e) {

		}

		return sValue;
	}

}

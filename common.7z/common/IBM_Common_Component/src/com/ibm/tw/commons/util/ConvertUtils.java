/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.tw.commons.util.converter.CCSID2EncodingConverter;
import com.ibm.tw.commons.util.converter.JavaClass2SQLTypeConverter;
import com.ibm.tw.commons.util.converter.SQLType2SQLTypeNameConverter;
import com.ibm.tw.commons.util.converter.SQLTypeName2JavaClassConverter;

/**
 * 型別轉換工具集
 * <p>
 * 型別轉換工具集主要功能繼承自{@link org.apache.commons.beanutils.ConvertUtils}， 並增加下列功能：
 * <ul>
 * <li>根據JDBC Type Name 轉換字串值</li>
 * <li>MQ CCSID -> Encoding之轉換</li>
 * <li>各種日期物件間的轉換</li>
 * <li>十六進位字串和Bye Array資料間的轉換</li>
 * <li>字串和數字間的轉換(<code>null</code> safe)</li>
 * <li>字串和BigDecimal間的轉換(<code>null</code> safe)</li>
 * </ul>
 * </p>
 * 
 * @author Jeff Liu
 * @version 1.0, 2007/10/19
 * @see {@link org.apache.commons.beanutils.ConvertUtils}
 * @since
 */
public class ConvertUtils extends org.apache.commons.beanutils.ConvertUtils {

	/** common logger */
	// protected static Log m_logger = LogFactory.getLog(ConvertUtils.class);
	private static Logger m_logger = LoggerFactory.getLogger(ConvertUtils.class);

	private static Pattern AMOUNT_PATTERN = Pattern.compile("^-?[0-9]+(\\.[0-9]+)?$");

	private static DecimalFormat TWD_AMT_FORMAT = new DecimalFormat("#,###,###,###,##0");

	/**
	 * 註冊使用者定義之Converter
	 */
	static {
		registerUserDefinedConverters();
	}

	/*
	 * public static void main(String[] args) { try {
	 * 
	 * System.out.println("encoding = " + ConvertUtils.ccsid2Encoding(1200)); }
	 * catch (Exception e) { e.printStackTrace(); } }
	 */

	/**
	 * 根據JDBC Type Name將字串值轉換為相對應的物件
	 * <ul>
	 * <li>根據JDBC Type Name取得對應的Java Class</li>
	 * <li>將字串值轉換為Java Class的物件</li>
	 * </ul>
	 * 
	 * <pre>
	 * ConvertUtils.getJDBCValue(null, &quot;INTEGER&quot;) = null;
	 * ConvertUtils.getJDBCValue(&quot;12&quot;, &quot;&quot;) = null;
	 * ConvertUtils.getJDBCValue(&quot;12&quot;, &quot;INTEGER2&quot;) = null
	 * ConvertUtils.getJDBCValue(&quot;12&quot;, &quot;INTEGER&quot;) = Integer(12)
	 * ConvertUtils.getJDBCValue(&quot;12a&quot;, &quot;INTEGER&quot;) = Integer(0)
	 * </pre>
	 * 
	 * @param sValue
	 *            待轉換的字串值
	 * @param sJDBCTypeName
	 *            欲轉換成的JDBC Type Name
	 * @return 根據JDBC Type Name轉換後的物件，轉換錯誤回傳null
	 */
	@SuppressWarnings("unchecked")
	public static Object getJDBCValue(String sValue, String sJdbcTypeName) {

		if (null == sValue || StringUtils.isBlank(sJdbcTypeName)) {
			return null;
		}
		Object value = null;
		try {

			// 根據JDBC Type Name取得對應的Java Class
			Class javaClass = SQLTypeName2JavaClassConverter.getJavaClass(sJdbcTypeName);

			if (javaClass != null) {
				value = ConvertUtils.convert(sValue, javaClass);
			}

		} catch (Exception e) {
			m_logger.error(e.getMessage(), e);
			value = null;
		}

		return value;

	}

	/**
	 * 取得SQL Type的顯示名稱
	 * 
	 * @param iSQLType
	 * @return
	 */
	public static String getSQLTypeName(int iSQLType) {
		return SQLType2SQLTypeNameConverter.getSQLTypeName(iSQLType);
	}

	/**
	 * 根據Java Class取得SQL Type
	 * 
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static int javaClass2SQLType(Class clazz) {
		return JavaClass2SQLTypeConverter.getSQLType(clazz);
	}

	/**
	 * 根據MQ CCSID取得對應的Encoding，轉換失敗則產生UnsupportedEncodingException
	 * 
	 * <pre>
	 * ConvertUtils.ccsid2Encoding(1209) = &quot;&quot;;
	 * ConvertUtils.ccsid2Encoding(1208) = &quot;UTF-8&quot;;
	 * ConvertUtils.ccsid2Encoding(1200) = &quot;Unicode&quot;;
	 * ConvertUtils.ccsid2Encoding(950) = &quot;Cp950&quot;;
	 * ConvertUtils.ccsid2Encoding(937) = &quot;Cp937&quot;;
	 * </pre>
	 * 
	 * @param iCCSID
	 *            MQ CCSID
	 * @return MQ CCSID對應的Encoding
	 * @throws UnsupportedEncodingException
	 */
	public static String ccsid2Encoding(int iCCSID) throws UnsupportedEncodingException {
		String sEncoding = "";
		try {

			sEncoding = CCSID2EncodingConverter.getEncoding(iCCSID);
		} catch (Exception e) {
			throw new UnsupportedEncodingException("ccsid [" + iCCSID + "] is unsupported!");

		}
		return sEncoding;
	}

	/**
	 * 將byte array資料轉為十六進位字串
	 * 
	 * <pre>
	 * ConvertUtils.byteArrayToHexString([0x01, 0x02]) = &quot;0102&quot;
	 * </pre>
	 * 
	 * @param raw
	 *            待轉換之bye array
	 * @return 十六進位字串
	 */
	public static String byteArray2HexString(byte[] raw) {
		StringBuffer sHex = new StringBuffer("");

		for (int i = 0; i < raw.length; i++) {

			sHex.append(byte2HexString(raw[i]));
		}
		return sHex.toString();
	}

	/**
	 * 將Byte資料轉換為十六進位字串
	 * 
	 * <pre>
	 * ConvertUtils.byte2Hex(0xab) = &quot;ab&quot;
	 * ConvertUtils.byte2Hex(0x01) = &quot;01&quot;
	 * </pre>
	 * 
	 * @param raw
	 * @return
	 */
	public static String byte2HexString(byte raw) {

		StringBuffer sHex = new StringBuffer("");
		int iByte = (raw & 0xF0) >> 4;
		// sHex.append(getHexChar(iByte));
		sHex.append(Character.forDigit(iByte, 16));
		iByte = (raw & 0x0F);
		sHex.append(Character.forDigit(iByte, 16));
		return sHex.toString();

		// String sHex = Integer.toHexString(raw).toUpperCase();

		// return StringUtils.leftPad(sHex, 2, "0");
	}

	/**
	 * 將long value轉成 十六進位字串
	 * 
	 * <pre>
	 * ConvertUtils.longToHexString(1234) = &quot;04D2&quot;
	 * ConvertUtils.longToHexString(1) = &quot;01&quot;
	 * </pre>
	 * 
	 * @param lValue
	 * @return
	 */
	public static String long2HexString(long lValue) {
		StringBuffer sBytes = new StringBuffer(Long.toHexString(lValue));
		if ((sBytes.length() % 2) != 0) {
			sBytes.insert(0, '0');
		}
		return sBytes.toString().toUpperCase();
	}

	/**
	 * 十六進位字串轉成 byte array
	 * 
	 * <pre>
	 * ConvertUtils.hexStringToByteArray(&quot;1234&quot;) = [0x12, 0x34]
	 * ConvertUtils.hexStringToByteArray(&quot;0x2e) = [0x2E]
	 * ConvertUtils.hexStringToByteArray(&quot;x'2e') = [0x2E]
	 * ConvertUtils.hexStringToByteArray(&quot;&quot;) = []
	 * ConvertUtils.hexStringToByteArray(&quot;1&quot;) = null
	 * ConvertUtils.hexStringToByteArray(&quot;gg&quot;) = null
	 * </pre>
	 * 
	 * @param sData
	 *            十六進位字串
	 * @return 十六進位所代表的Bye Array
	 */
	public static byte[] hexString2ByteArray(String sData) {

		if (StringUtils.isBlank(sData)) {
			return new byte[0];
		}

		// TODO: 待確認
		// x'2E' format => 2E
		if (sData.startsWith("x") || sData.startsWith("X")) {
			int start = sData.indexOf("'");
			int end = sData.lastIndexOf("'");
			sData = sData.substring(start + 1, end);
		}
		// delete leading "0x" or "0X"
		// "0x2f" => "2f
		else if (sData.startsWith("0x") || sData.startsWith("0X")) {
			sData = sData.substring(2);
		}

		if (sData.length() % 2 != 0) {
			return ArrayUtils.EMPTY_BYTE_ARRAY;
		}

		byte[] raw = new byte[sData.length() / 2];

		try {
			for (int i = 0; i < sData.length() / 2; i++) {

				raw[i] = (byte) Integer.parseInt(sData.substring(i * 2, i * 2 + 2), 16);

			}
		} catch (Exception e) {

			raw = null;
		}
		return raw;
	}

	/**
	 * get HEX value
	 * 
	 * <pre>
	 * ConvertUtils.getHexValue('9') = 9
	 * ConvertUtils.getHexValue('A') = 10
	 * ConvertUtils.getHexValue('G')= Exception
	 * </pre>
	 * 
	 * @param c
	 * @return HEX Character所表示的數值
	 * @throws Exception
	 *             非HEX的字元
	 */
	public static int getHexValue(char c) throws Exception {

		if (c >= '0' && c <= '9')
			return (c - '0');
		if (c >= 'A' && c <= 'F')
			return (c - 'A' + 10);

		if (c >= 'a' && c <= 'f')
			return (c - 'a' + 10);

		throw new Exception("char '" + String.valueOf(c) + "' is not valid hex character!");
	}

	/**
	 * convert java.util.Date to java.sql.Date
	 * 
	 * @param dt
	 * @return
	 */
	public static java.sql.Date date2SQLDate(java.util.Date dt) {

		if (dt == null) {
			return null;
		}

		return new java.sql.Date(dt.getTime());
	}

	/**
	 * convert java.sql.Date to java.util.Date
	 * 
	 * @param sdt
	 * @return
	 */
	public static java.util.Date sqlDate2Date(java.sql.Date sdt) {

		if (sdt == null) {
			return null;
		}

		return new java.util.Date(sdt.getTime());
	}

	/**
	 * convert java.util.Date to java.sql.Timestamp
	 * 
	 * @param dt
	 * @return
	 */
	public static java.sql.Timestamp date2Timestamp(java.util.Date dt) {
		if (dt == null) {
			return null;
		}

		return new Timestamp(dt.getTime());
	}

	/**
	 * Convert java.sql.Timestamp to java.util.Date
	 * 
	 * @param time
	 * @return
	 */
	public static java.util.Date timestamp2Date(java.sql.Timestamp time) {

		if (time == null) {
			return null;
		}

		return new java.util.Date(time.getTime());

	}

	/**
	 * Convert java.util.Calendar to java.sql.Timestamp
	 * 
	 * @param calendar
	 * @return
	 */
	public static java.sql.Timestamp calendar2Timestamp(Calendar calendar) {
		if (calendar == null) {
			return null;
		}

		java.util.Date dt = calendar.getTime();
		Timestamp time = new Timestamp(dt.getTime());
		return time;
	}

	/**
	 * Convert java.util.Calendar to java.sql.Timestamp
	 * 
	 * @param time
	 * @return
	 */
	public static Calendar timestamp2Calendar(Timestamp time) {

		if (time == null) {
			return null;
		}

		Calendar calendar = new GregorianCalendar();
		calendar.setTime(time);
		return calendar;
	}

	/**
	 * Convert java.util.Canlendar to java.util.Date
	 * 
	 * @param calendar
	 * @return
	 */
	public static java.util.Date calendar2Date(Calendar calendar) {
		if (calendar != null) {
			return calendar.getTime();
		} else {
			return null;
		}
	}

	/**
	 * Convert java.util.Calendar to java.sql.Date
	 * 
	 * @param calendar
	 * @return
	 */
	public static java.sql.Date calendar2SQLDate(Calendar calendar) {

		if (calendar == null) {
			return null;
		}

		java.util.Date dt = calendar2Date(calendar);

		if (dt != null) {
			return new java.sql.Date(dt.getTime());
		} else {
			return null;
		}
	}

	/**
	 * Convert java.util.Date to java.util.Calendar
	 * 
	 * @param dt
	 * @return
	 */
	public static Calendar date2Calendar(java.util.Date dt) {
		if (null == dt) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dt);

		return calendar;
	}

	/**
	 * 將字串轉換為數字，如果轉換失敗則回傳預設值
	 * <ul>
	 * <li>ConvertUtils.str2Int(null) = 0</li>
	 * <li>ConvertUtils.str2Int("abc") = 0</li>
	 * <li>ConvertUtils.str2Int("1") = 1</li>
	 * </ul>
	 * 
	 * @param sValue
	 *            待轉換之字串
	 * @param iDefaultValue
	 *            轉換失敗時之預設值
	 * @return 轉換後之數字，失敗則傳回iDefaultValue
	 * 
	 */
	public static int str2Int(String sValue, int iDefaultValue) {

		sValue = StringUtils.trim(sValue);

		int iValue = iDefaultValue;
		try {
			iValue = Integer.parseInt(sValue);
		} catch (Exception e) {
			iValue = iDefaultValue;
		}

		return iValue;
	}

	/**
	 * 將字串轉成Integer
	 * 
	 * @param sValue
	 *            待轉換的字串
	 * @return 轉換後的數字，如果無法轉換時回傳0
	 */
	public static int str2Int(String sValue) {
		return ConvertUtils.str2Int(sValue, 0);
	}

	/**
	 * 將字串轉成Long
	 * 
	 * @param value
	 * @return
	 */
	public static Long str2Long(String value) {
		value = StringUtils.trim(StringUtils.defaultString(value));

		Long retValue = Long.valueOf(0);
		try {
			retValue = Long.parseLong(value);
		} catch (Exception e) {
			m_logger.error("cannot parse long value = " + value);
		}

		return retValue;
	}

	/**
	 * convert big decimal to string，四捨五入
	 * 
	 * <pre>
	 * bigDecimal2Str(null, 2, &quot;2&quot;) = &quot;2&quot;
	 * bigDecimal2Str(2.12, 1, &quot;&quot;) = &quot;2.1&quot;
	 * bigDecimal2Str(2.15, 1, &quot;&quot;) = &quot;2.2&quot;
	 * </pre>
	 * 
	 * @param value
	 *            待設定之BigDecimal Value
	 * @param iScale
	 *            小數有效位數
	 * @param sDefaultValue
	 *            預設值
	 * @return 採用四捨五入制，發生異常時回傳預設值sDefaultValue, never null
	 */
	public static String bigDecimal2Str(BigDecimal value, int iScale, String sDefaultValue) {
		if (null == value) {

			return (sDefaultValue != null) ? sDefaultValue : "";
		}

		BigDecimal amount = null;
		if (iScale >= 0) {
			amount = NumericUtils.setScale(value, iScale);
		} else {
			amount = value;
		}

		return amount.toString();
	}

	/**
	 * convert big decimal to string
	 * 
	 * <pre>
	 * bigDecimal2Str(null, 2) = &quot;&quot;
	 * bigDecimal2Str(2.12, 1) = &quot;2.1&quot;
	 * bigDecimal2Str(2.15, 1) = &quot;2.2&quot;
	 * </pre>
	 * 
	 * @param value
	 *            待設定之BigDecimal Value
	 * @param iScale
	 *            小數有效位數
	 * 
	 * @return 採用四捨五入制，發生異常時回傳預設值""
	 */
	public static String bigDecimal2Str(BigDecimal value, int iScale) {
		return bigDecimal2Str(value, iScale, "");
	}

	/**
	 * convert big decimal to string
	 * <ul>
	 * <li>bigDecimal2Str(null) = ""</li>
	 * <li>bigDecimal2Str(2.12) = "2.12"</li>
	 * <li>bigDecimal2Str(2.15) = "2.15"</li>
	 * </ul>
	 * 
	 * @param value
	 * @return
	 */
	public static String bigDecimal2Str(BigDecimal value) {
		return bigDecimal2Str(value, -1, "");
	}

	/**
	 * convert string to big decimal
	 * 
	 * <pre>
	 *  
	 * str2BigDecimal(null, 1, 0) = 0
	 * str2BigDecimal(&quot;AA&quot;, 1, 0) = 0
	 * str2BigDecimal(&quot;2.12&quot;, 1, 0) = 2.1
	 * str2BigDecimal(&quot;2.15&quot;, 1, 0) = 2.2
	 * </pre>
	 * 
	 * @param sValue
	 * @param iScale
	 * @param defaultValue
	 * @return
	 */
	public static BigDecimal str2BigDecimal(String sValue, int iScale, BigDecimal defaultValue) {

		BigDecimal value = null;
		try {
			sValue = StringUtils.trim(sValue);
			// Leo: 去除","
			sValue = StringUtils.remove(sValue, ",");

			value = new BigDecimal(sValue);

			if (iScale >= 0) {

				value = value.setScale(iScale, BigDecimal.ROUND_HALF_UP);
			}
		} catch (Exception e) {
			value = defaultValue;
		}
		return value;
	}

	/**
	 * convert string to big decimal
	 * <ul>
	 * <li>str2BigDecimal(null) = 0</li>
	 * <li>str2BigDecimal("AA") = 0</li>
	 * <li>str2BigDecimal("2.12") = 2.12</li>
	 * </ul>
	 * 
	 * @param sValue
	 * @return
	 */
	public static BigDecimal str2BigDecimal(String sValue) {
		return str2BigDecimal(sValue, -1, new BigDecimal(0));
	}

	/**
	 * convert string to big decimal
	 * <ul>
	 * <li>str2BigDecimal(null, 2) = 0</li>
	 * <li>str2BigDecimal("AA", 2) = 0</li>
	 * <li>str2BigDecimal("2.12", 1) = 2.1</li>
	 * <li>str2BigDecimal("2.15", 1) = 2.2</li>
	 * </ul>
	 * 
	 * @param sValue
	 * @return
	 */
	public static BigDecimal str2BigDecimal(String sValue, int iScale) {
		return str2BigDecimal(sValue, iScale, new BigDecimal(0));
	}

	/**
	 * convert REsourceBundle to Preperties
	 * 
	 * @param rb
	 * @return
	 */
	public static Properties resouceBundle2Properties(ResourceBundle rb) {

		Properties prop = new Properties();

		Enumeration<String> keys = rb.getKeys();

		while (keys.hasMoreElements()) {

			String sKey = (String) keys.nextElement();

			String sValue = rb.getString(sKey);

			prop.put(sKey, sValue);
		}

		return prop;
	}

	/**
	 * 註冊使用者定義之Converter
	 * <ul>
	 * <li>JDBC Type Name -> JDBC Class Converter</li>
	 * <li>MQ CCSID -> Encoding Converter</li>
	 * </ul>
	 */
	private static void registerUserDefinedConverters() {
		// // JDBC Type Name -> JDBC Class Converter
		// ConvertUtils.register(new JDBCTypeConverter(), JDBCType.class);
		//
		// // MQ CCSID -> Encoding Converter
		// ConvertUtils.register(new CCSIDTypeConverter(), CCSIDType.class);
		// ConvertUtils.register(new DateConvert(), java.util.Date.class);
		// ConvertUtils.register(new DateConvert(), java.sql.Date.class);
	}

	/**
	 * 將Clob轉換為字串值
	 * <p>
	 * 此功能應該移往com.ibm.tw.common.utils.ConvertUtils
	 * </p>
	 * 
	 * TODO:當Clob長度大於 integer時此function會產生Runtime Exception
	 * 
	 * @throws SQLException
	 */
	public static String clob2Str(Clob value) throws SQLException {
		if (null == value) {
			return null;
		}
		String sData = "";

		long lLen = value.length();

		// clob length > integer max value
		if (lLen > Integer.MAX_VALUE) {
			String sMsg = "clob length [" + lLen + "] is greater than integer max value [" + Integer.MAX_VALUE + "]";
			throw new RuntimeException(sMsg);
		}

		sData = value.getSubString(1, (int) lLen);

		return sData;
	}

	/**
	 * 將blob轉換為byte array
	 * <p>
	 * 此功能應該移往com.ibm.tw.common.utils.ConvertUtils
	 * </p>
	 * 
	 * TODO：當 Blob長度大於 integer時此function會產生Runtime Exception
	 * 
	 * @param value
	 * @return
	 * @throws SQLException
	 * @throws IOException 
	 */
	public static byte[] blob2Bytes(Blob value) throws SQLException, IOException {
		if (null == value) {
			return null;
		}

		byte[] data = null;

		InputStream is = null;
		try {
			long lLen = value.length();
			// blob length > integer max value
			if (lLen > Integer.MAX_VALUE) {
				String sMsg = "blob length [" + lLen + "] is greater than integer max value [" + Integer.MAX_VALUE
						+ "]";
				throw new RuntimeException(sMsg);
			}
			is = value.getBinaryStream();
			data = new byte[(int) lLen];
			is.read(data);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e1) {
					// quietly
				}
			}
		}

		return data;
	}

	/**
	 *  convert bytes 2 str (不產生exception)
	 *  
	 * @param data
	 * @param encoding
	 * @return
	 */
	public static String bytes2Str(byte[] data, String encoding) {
		String str = "";

		try {
			str = new String(data, encoding);
		} catch (UnsupportedEncodingException e) {
			m_logger.error(e.getMessage(), e);
		}
		return str;
	}

	/**
	 * convert str to bytes (不產生exception)
	 * 
	 * @param str
	 * @param encoding
	 * @return
	 */
	public static byte[] str2Bytes(String str, String encoding) {
		byte[] data = null;

		try {
			data = str.getBytes(encoding);
		} catch (UnsupportedEncodingException e) {
			m_logger.error(e.getMessage(), e);
		}
		return data;
	}

	/**
	 * 將字串轉換為Locale，轉換失敗則傳回Locale.TAIWAN
	 * 
	 * @param str
	 * @return
	 */
	public static Locale str2Locale(String str) {
		Locale locale = null;
		try {

			String[] tokens = StringUtils.getTokens(str, "_");

			locale = new Locale(tokens[0], tokens[1]);
		} catch (Exception e) {
			m_logger.error("cannot convert str to locale, str = " + str);
		}

		return (locale != null) ? locale : Locale.TAIWAN;
	}

	public static String formatAmount(BigDecimal amt) {
		if (amt == null) {
			return "";
		}
		return formatAmount(Locale.TAIWAN, amt.doubleValue());
	}

	/**
	 * 當日幣及台幣時為整數,其餘小數點二位
	 * @param currencyType幣別
	 * @return
	 */
	public static String formatAmount(String currencyType, String amt) {
		if (StringUtils.isBlank(amt))
			return amt;
		// Leo: 去除","
		amt = StringUtils.remove(amt, ",");
		Double d = Double.valueOf(amt);
		return formatAmount(currencyType, d);
	}

	public static String formatAmount(Locale locale, double amt) {
		if (locale == Locale.JAPAN || locale == Locale.TAIWAN) {
			NumberFormat specialNumberFormat = new DecimalFormat("###,###,###,##0");
			return specialNumberFormat.format(amt);
		} else {
			NumberFormat numberFormat = new DecimalFormat("###,###,###,##0.00");
			return numberFormat.format(amt);
		}
	}

	public static String formatAmount(String currencyType, BigDecimal amt) {
		if (amt == null) {
			return null;
		}
		return formatAmount(currencyType, amt.doubleValue());
	}

	public static String formatRate(String rate) {
		if (StringUtils.isBlank(rate)) {
			return "-";
		}
		NumberFormat numberFormat = new DecimalFormat("###,###,###,##0.000");
		return numberFormat.format(Double.valueOf(rate));
		// return formatAmount(Locale.ENGLISH, Double.valueOf(rate));
	}

	public static String formatAmount(String currencyType, double amt) {
		if ("JPY".equals(currencyType) || "TWD".equals(currencyType)) {
			NumberFormat specialNumberFormat = new DecimalFormat("###,###,###,##0");
			return specialNumberFormat.format(amt);
		} else {
			NumberFormat numberFormat = new DecimalFormat("###,###,###,##0.00");
			return numberFormat.format(amt);
		}
	}

	public static String formatAmount(String str) {
		if (StringUtils.isBlank(str))
			return str;
		return formatAmount(Double.valueOf(str));
	}

	public static String formatAmount(Double d) {
		if (d == null)
			return null;
		NumberFormat numberFormat = new DecimalFormat("###,###,###,##0.0000");
		return numberFormat.format(d);
	}

	/**
	 * 格式化台幣金額 先去掉千分位，再加上千分位 比如 : for VB53 用 如果格式化有問題，回傳原字串， Exception 記錄進 Log 中
	 * 
	 * @param str
	 * @return
	 */
	public static String formatAmountTWD(String str) {
		if (str == null || "".equals(str.trim()))
			return str;
		String rtString = null;
		try {
			if (StringUtils.startsWith(str, "$")) {
				str = str.substring(1);
			}
			String sAmount = StringUtils.replaceAllComma(str);
			if (isValidAmount(sAmount)) {
				BigDecimal amount = new BigDecimal(sAmount);
				amount.setScale(0);
				rtString = TWD_AMT_FORMAT.format(amount);
			} else {
				rtString = str;
			}
		} catch (Exception e) {
			rtString = str;
			m_logger.error(e.getMessage(), e);
		}
		return rtString;
	}

	/**
	 * 將台幣的小數點移除
	 * 
	 * @param str
	 * @return
	 */
	public static final String formatAmountTWD2(String amount) {
		amount = StringUtils.trimAll(amount);
		if (amount == null || amount.equals(".00")) {
			return "";
		}
		return formatAmountTWD(amount);
	}
	
	/**
	 * 針對有幾位小數位，特別處理(目前最多四位)
	 */
	public static final String formatAmountScale(BigDecimal amount) {
		int scale = 0;
		if (null == amount) {
			return "";
		}
		NumberFormat numberFormat = null;
		scale = amount.scale();
		
		switch(scale) {
			case 0:
				numberFormat = new DecimalFormat("###,###,###,##0.####");
				break;
			case 1:
				numberFormat = new DecimalFormat("###,###,###,##0.0###");
				break;
			case 2:
				numberFormat = new DecimalFormat("###,###,###,##0.00##");
				break;
			case 3:
				numberFormat = new DecimalFormat("###,###,###,##0.000#");
				break;
			case 4:
				numberFormat = new DecimalFormat("###,###,###,##0.0000");
				break;
			default:
				String pattern = "###,###,###,##0." + StringUtils.leftPad("", scale, "0");
				numberFormat = new DecimalFormat(pattern);
		}
		
		return numberFormat.format(amount);
	}

	/**
	 * 驗證是否為有效的金額字串
	 * 
	 * @param amount
	 * @return
	 */
	public static boolean isValidAmount(String amount) {
		if (amount == null)
			return false;
		return AMOUNT_PATTERN.matcher(amount).find();
	}

	public static String letterToNum(String idNo) {
		if (StringUtils.isBlank(idNo)) {
			return idNo;
		}

		idNo = StringUtils.upperCase(idNo);
		char[] chars = idNo.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < chars.length; i++) {
			if (chars[i] >= 'A' && chars[i] <= 'Z') {
				sb.append(StringUtils.leftPad("" + (chars[i] - 64), 2, '0'));
			} else {
				sb.append(chars[i]);
			}
		}
		return sb.toString();
	}

	public static String getEsbRsAmount(String s) {
		s = StringUtils.trim(s);
		if (StringUtils.isBlank(s)) {
			return s;
		}
		int pos = StringUtils.indexOf(s, ".");
		if (pos >= 0) {
			for (int i = 0; i < pos; i++) {
				if (s.charAt(i) != '0') {
					s = s.substring(i);
					break;
				}
			}
		}
		Pattern AMOUNT_PATTERN = Pattern.compile("^[0-9]+[0-9,]*(\\.[0-9]+)?[+-]+$");
		if (AMOUNT_PATTERN.matcher(s).find()) {
			s = s.substring(s.length() - 1, s.length()) + s.substring(0, s.length() - 1);
		}
		return s;
	}

	/**U0移植過來**/
	public static String numFormat0(String num, int dot) {
		if (num == null || num.trim().equals(""))
			return null;
		String number = num.trim().replaceAll("\\$", "");
		NumberFormat nf = NumberFormat.getInstance();
		try {
			String fmtS = "###,###,###,###,###,###,###,###,##0";
			if (dot > 0)
				for (fmtS = fmtS + "."; dot-- > 0; fmtS = fmtS + "0")
					;
			((DecimalFormat) nf).applyPattern(fmtS);
			number = number.replaceAll(",", "");
			number = nf.format(new Double(number));
			if (num.indexOf("$") >= 0) {
				return "$" + number;
			} else {
				return number;
			}
		} catch (Exception ex) {
			m_logger.error("error  == : ", ex);
			return "0";

		}
	}

	/****/
	public static String addComma(String s) {
		if (StringUtils.isBlank(s)) {
			return s;
		}
		String[] sAmount = s.split("\\.");
		StringBuffer sb = new StringBuffer(sAmount[0]);
		for (int i = StringUtils.length(sAmount[0]) - 3; i > 0; i -= 3) {
			sb.insert(i, ",");
		}
		if (sAmount.length > 1) {
			sb.append(".").append(sAmount[1]);
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		System.out.println(addComma(" "));
		System.out.println(addComma("1"));
		System.out.println(addComma("123"));
		System.out.println(addComma("123.1"));
		System.out.println(addComma("9902123.1"));
		System.out.println(addComma("99021146161561565165464123.1251361641651"));
		if (true)
			return;

		System.out.println(getEsbRsAmount("100+"));
		System.out.println(getEsbRsAmount("1.23-"));

		// String sData =
		// "3c3f786d6c2076657273696f6e3d27312e302720656e636f64696e673d275554462d38273f3e3c21444f43545950452068746d6c205055424c494320222d2f2f5733432f2f445444205848544d4c20312e30205374726963742f2f454e222022687474703a2f2f7777772e77332e6f72672f54522f7868746d6c312f4454442f7868746d6c312d7374726963742e647464223e3c68746d6c3e3c686561643e3c7469746c653e58466972652053657276696365733c2f7469746c653e3c2f686561643e3c626f64793e3c70202f3e3c703e417661696c61626c652053657276696365733a3c2f703e3c756c3e3c6c693e70696e67203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f70696e673f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e726f75746572203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f726f757465723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e5773426c7730316d3148646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f5773426c7730316d3148646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e5773436c773031713148646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f5773436c773031713148646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e5773436c773031713248646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f5773436c773031713248646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e57734971773031713148646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f57734971773031713148646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e57734971773031713248646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f57734971773031713248646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e57734971773031713348646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f57734971773031713348646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e57734971773032713148646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f57734971773032713148646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e57734e62773031713148646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f57734e62773031713148646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e57734e62773032713148646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f57734e62773032713148646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c6c693e57734e62773033713148646c72203c6120687265663d22687474703a2f2f31302e31312e3130302e34333a373737372f736b6c66742f736572766963652f57734e62773033713148646c723f7773646c223e5b7773646c5d3c2f613e3c2f6c693e3c212d2d4a7573742066696c6c696e67207370616365206163636f7264696e6720746f20687474703a2f2f737570706f72742e6d6963726f736f66742e636f6d2f64656661756c742e617370783f736369643d6b623b656e2d75733b513239343830372d2d3e3c212d2d4a7573742066696c6c696e67207370616365206163636f7264696e6720746f20687474703a2f2f737570706f72742e6d6963726f736f66742e636f6d2f64656661756c742e617370783f736369643d6b623b656e2d75733b513239343830372d2d3e3c6272202f3e3c6272202f3e3c6272202f3e3c6272202f3e3c6272202f3e2020202020202047656e657261746564206279205846697265202820687474703a2f2f78666972652e636f6465686175732e6f72672029203c6872202f3e3c2f756c3e3c2f626f64793e3c2f68746d6c3e";
		// sData = new String(ConvertUtils.hexString2ByteArray(sData));
		// String sKey = sData.substring(9, 18);
		// System.out.println(sKey);
		// System.out.println(sData);

		byte[] data = new byte[2];

		data[0] = 0x0D;

		data[1] = 0x05;

		String s = ConvertUtils.byteArray2HexString(data);

		System.out.println("s = " + s);

	}

}

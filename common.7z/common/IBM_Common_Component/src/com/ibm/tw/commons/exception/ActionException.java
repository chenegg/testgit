/*
 * ===========================================================================
 * IBM Confidential AIS Source Materials
 * 
 * 交易異常物件
 * 
 * (C) Copyright IBM Corp. 2005.
 * 
 * ===========================================================================
 */
package com.ibm.tw.commons.exception;

import java.util.Hashtable;
import java.util.Map;

import com.ibm.tw.commons.id.CommonStatus;
import com.ibm.tw.commons.util.JsonUtils;

/**
 * <p>
 * 所有的status code都必須儲存於狀態代碼表(Status Table)中
 * </p>
 * 
 * 
 * @author Kevin
 * @version 1.0, 2005/08/7
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class ActionException extends Exception {
	
	/** 訊息參數 */
	protected Map<String, Object> paramMap = new Hashtable<String, Object>();

	/** 回應狀態 */
	protected CommonStatus status = null;

	/** chain to next exception */
	protected ActionException next = null;

	/**
	 * Constructor
	 */
	public ActionException() {
		super();
		this.status = new CommonStatus();
	}
	
	public ActionException(ActionException e) {
		this("", e.getStatus(), null);
	}


	/**
	 * Constructor
	 * 
	 * @param status
	 * @param cause
	 */
	public ActionException(String msg, CommonStatus status, Throwable cause) {
		super(msg, cause);
		setStatus(status);
	}

	/**
	 * Constructor
	 * 
	 * @param status
	 * @param cause
	 */
	public ActionException(CommonStatus status, Throwable cause) {
		this("", status, cause);
	}
	
	public ActionException(String msg, CommonStatus status) {
		this(msg, status, null);
	}
	
	/**
	 * Constructor
	 * 
	 * @param status
	 */
	public ActionException(CommonStatus status) {
		this("", status, null);
	}
	
 

	/**
	 * Constructor
	 * 
	 * @param systemId
	 *            系統代碼
	 * @param statusCode
	 *            交易回應代碼，0：表示交易正確
	 * @param severity
	 *            狀態等級 ERROR/WARNING/INFO
	 * @param statusDesc
	 *            狀態描述
	 */
	public ActionException(String systemId, String statusCode, String severity, String statusDesc) {
		 
		this(new CommonStatus(systemId, statusCode, severity, statusDesc));
	}

	 
	
	/**
	 * Constructor
	 * 
	 * @param systemId
	 *            系統代碼
	 * @param statusCode
	 *            交易回應代碼，0：表示交易正確
	 * @param severity
	 *            狀態等級 ERROR/WARNING/INFO
	 * @param statusDesc
	 *            狀態描述
	 * @param cause
	 */
	public ActionException(String systemId, String statusCode, String severity, String statusDesc, Throwable cause) {
		 
		this(new CommonStatus(systemId, statusCode, severity, statusDesc), cause);
	}
	
	public ActionException(String msg, String systemId, String statusCode, String severity, String statusDesc) {
		 
		this(msg, new CommonStatus(systemId, statusCode, severity, statusDesc));
	}
	
	public ActionException(String msg, String systemId, String statusCode, String severity, String statusDesc, Throwable cause) {
		 
		this(msg, new CommonStatus(systemId, statusCode, severity, statusDesc), cause);
	}

	/**
	 * 設定 狀態資料
	 * 
	 * @param status
	 */
	public void setStatus(CommonStatus status) {
		this.status = status;
	}

	/**
	 * 取得 狀態資料
	 * 
	 * @return
	 */
	public CommonStatus getStatus() {
		return status;
	}

	/**
	 * Adds an <code>ActionException</code> object to the end of the chain.
	 * 
	 * @param ex
	 *            the new exception that will be added to the end of the
	 *            <code>ActionException</code> chain
	 * @see #getNextException
	 */
	public synchronized void setNextException(ActionException ex) {
		ActionException theEnd = this;
		while (theEnd.next != null) {
			theEnd = theEnd.next;
		}
		theEnd.next = ex;
	}

	/**
	 * Retrieves the exception chained to this <code>ActionException</code>
	 * object.
	 * 
	 * @return the next <code>ActionException</code> object in the chain;
	 *         <code>null</code> if there are none
	 * @see #setNextException
	 */
	public ActionException getNextException() {
		return (next);
	}


//	@Override
//	public String getMessage() {
//		//return StringUtils.isBlank(super.getMessage()) ? status.getStatusDesc() : status.getStatusDesc() + "\n" + super.getMessage();
//		
//		
//	}

	
	/**
	 * 是否為Timeout
	 * 
	 * @return
	 */
	public boolean isTimeout() {
		return status.isTimeout();
	}
	
	@Override
	public String toString() {
		
		StringBuffer sb = new StringBuffer();
		
		sb.append(super.toString());
		
		sb.append(", error system id = ").append(status.getSystemId());
		sb.append(", error code = ").append(status.getStatusCode());
		sb.append(", error desc = ").append(status.getStatusDesc());
		
		return sb.toString();
	}

	/**
	 * 取得錯誤參數
	 * 
	 * @return
	 */
	public String getErrorParams() {
		return JsonUtils.getJson(paramMap);
	}
	
	/**
	 * 設定訊息參數
	 * @param key
	 * @param value
	 */
	public void putParam(String key, Object value) {
		paramMap.put(key, value);
	}
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.tw.commons.util;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author chenegg
 */
public class EnumUtils extends org.apache.commons.lang.enums.EnumUtils {

	private static Logger logger = LoggerFactory.getLogger(EnumUtils.class);

	public static <E extends Enum<E>> E toValueOf(Class<E> clazz, String s) {
		E unKnown = null;
		if (clazz != null) {
			for (E en : EnumSet.allOf(clazz)) {
				if (StringUtils.equals(en.name(), EnumBase.UNKNOWN)) {
					unKnown = en;
					continue;
				} else if (StringUtils.equals(en.name(), s)) {
					return en;
				}
			}
		}
		return unKnown;
	}

	public static <E extends Enum<E>> List<E> asList(Class<E> clazz) {
		List<E> names = new ArrayList<E>();
		if (clazz != null) {
			for (E en : EnumSet.allOf(clazz)) {
				String name = StringUtils.replace(en.name(), "$$", "&");
				if (StringUtils.equals(name, EnumBase.UNKNOWN)) {
					/* 忽略UNKNOWN */
					continue;
				}
				names.add(en);
			}
		}
		return names;
	}

	public static <E extends Enum<E>> Map<String, E> asMap(Class<E> clazz) {
		Map<String, E> result = new HashMap<String, E>();
		if (clazz != null) {
			for (E en : EnumSet.allOf(clazz)) {
				String name = StringUtils.replace(en.name(), "$$", "&");
				if (StringUtils.equals(name, EnumBase.UNKNOWN)) {
					/* 忽略UNKNOWN */
					continue;
				}
				result.put(name, en);
			}
		}
		return result;
	}

	/** 
	* 從指定的枚舉類中根據property搜尋匹配指定值的枚舉實例 
	* @param <T> 
	* @param enumClass 
	* @param property 
	* @param propValue 
	* @return 
	*/
	public static <T extends Enum<T>> T fromEnumProperty(Class<T> enumClass, String property, Object propValue) {
		T[] enumConstants = enumClass.getEnumConstants();
		for (T t : enumConstants) {
			Object constantPropValue;
			try {
				constantPropValue = BeanUtils.getDeclaredFieldValue(t, property);
				if (ObjectUtils.equals(constantPropValue, propValue)) {
					return t;
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new RuntimeException(e);
			}
		}
		return null;
	}

	/** 
	 * 從從指定的枚舉類中根據名稱匹配指定值 
	 * @param <T> 
	 * @param enumClass 
	 * @param constantName 
	 * @return 
	 */
	public static <T extends Enum<T>> T fromEnumConstantName(Class<T> enumClass, String constantName) {
		T[] enumConstants = enumClass.getEnumConstants();
		for (T t : enumConstants) {
			if (((Enum<?>) t).name().equals(constantName)) {
				return t;
			}
		}
		return null;
	}

}

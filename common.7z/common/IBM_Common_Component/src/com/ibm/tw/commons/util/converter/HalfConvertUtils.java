/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 半形轉全形之工具
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util.converter;

import java.util.Hashtable;
import java.util.Map;

/**
 * 全形/半形轉換工具集
 * <p>
 * 目前工具集僅支援ASCII字元(英數字、符號)間的轉換，不支援中文字
 * </p>
 * 
 * @author Ping Lee
 * @version 1.0, 2004/10/18
 * @see
 * @since
 */
public class HalfConvertUtils {

	/** 半形->全形轉換表 */
	public final static Map<String, String> m_half2FullMappingTable = new Hashtable<String, String>();

	/** 全形->半形轉換表 */
	public final static Map<String, String> m_full2HalfMappingTable = new Hashtable<String, String>();

	/**
	 * 註冊轉換表
	 */
	static {

		deregister();
	}

	/**
	 * 半形轉全形
	 * 
	 * @param sHalfFormString
	 * @return
	 */
	public static String half2Full(String sHalfFormString) {
		int iLen = sHalfFormString.length();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < iLen; i++) {

			String s = sHalfFormString.substring(i, i + 1);

			String sConvertValue = (String) m_half2FullMappingTable.get(s);
			if (sConvertValue != null) {
				sb.append(sConvertValue);
			} else {
				sb.append(s);
			}

		}

		return sb.toString();
	}

	/**
	 * 全形轉半形
	 * 
	 * @param sFullFormString
	 * @return
	 */
	public static String full2Half(String sFullFormString) {
		int iLen = sFullFormString.length();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < iLen; i++) {

			String s = sFullFormString.substring(i, i + 1);

			String sConvertValue = (String) m_full2HalfMappingTable.get(s);
			if (sConvertValue != null) {
				sb.append(sConvertValue);
			} else {
				sb.append(s);
			}

		}

		return sb.toString();
	}

	/**
	 * 
	 *
	 */
	public static void deregister() {

		registerHalf();

		registerFull();
	}

	/**
	 * 註冊全形/半形轉換表
	 *
	 */
	private static void registerHalf() {

		m_half2FullMappingTable.clear();

		m_half2FullMappingTable.put("(", "（");
		m_half2FullMappingTable.put("(", "（");
		m_half2FullMappingTable.put(")", "）");
		m_half2FullMappingTable.put("[", "〔");
		m_half2FullMappingTable.put("]", "〕");
		m_half2FullMappingTable.put("{", "｛");
		m_half2FullMappingTable.put("}", "｝");
		m_half2FullMappingTable.put(".", "。");
		m_half2FullMappingTable.put(",", "，");
		m_half2FullMappingTable.put(";", "；");
		m_half2FullMappingTable.put(":", "：");
		m_half2FullMappingTable.put("-", "－");
		m_half2FullMappingTable.put("?", "？");
		m_half2FullMappingTable.put("!", "！");
		m_half2FullMappingTable.put("@", "＠");
		m_half2FullMappingTable.put("#", "＃");
		m_half2FullMappingTable.put("$", "＄");
		m_half2FullMappingTable.put("%", "％");
		m_half2FullMappingTable.put("&", "＆");
		m_half2FullMappingTable.put("|", "｜");
		m_half2FullMappingTable.put("\\", "＼");
		m_half2FullMappingTable.put("/", "／");
		m_half2FullMappingTable.put("+", "＋");
		m_half2FullMappingTable.put("=", "＝");
		m_half2FullMappingTable.put("*", "＊");
		m_half2FullMappingTable.put("0", "０");
		m_half2FullMappingTable.put("1", "１");
		m_half2FullMappingTable.put("2", "２");
		m_half2FullMappingTable.put("3", "３");
		m_half2FullMappingTable.put("4", "４");
		m_half2FullMappingTable.put("5", "５");
		m_half2FullMappingTable.put("6", "６");
		m_half2FullMappingTable.put("7", "７");
		m_half2FullMappingTable.put("8", "８");
		m_half2FullMappingTable.put("9", "９");
		m_half2FullMappingTable.put("a", "ａ");
		m_half2FullMappingTable.put("b", "ｂ");
		m_half2FullMappingTable.put("c", "ｃ");
		m_half2FullMappingTable.put("d", "ｄ");
		m_half2FullMappingTable.put("e", "ｅ");
		m_half2FullMappingTable.put("f", "ｆ");
		m_half2FullMappingTable.put("g", "ｇ");
		m_half2FullMappingTable.put("h", "ｈ");
		m_half2FullMappingTable.put("i", "ｉ");
		m_half2FullMappingTable.put("j", "ｊ");
		m_half2FullMappingTable.put("k", "ｋ");
		m_half2FullMappingTable.put("l", "ｌ");
		m_half2FullMappingTable.put("m", "ｍ");
		m_half2FullMappingTable.put("n", "ｎ");
		m_half2FullMappingTable.put("o", "ｏ");
		m_half2FullMappingTable.put("p", "ｐ");
		m_half2FullMappingTable.put("q", "ｑ");
		m_half2FullMappingTable.put("r", "ｒ");
		m_half2FullMappingTable.put("s", "ｓ");
		m_half2FullMappingTable.put("t", "ｔ");
		m_half2FullMappingTable.put("u", "ｕ");
		m_half2FullMappingTable.put("v", "ｖ");
		m_half2FullMappingTable.put("w", "ｗ");
		m_half2FullMappingTable.put("x", "ｘ");
		m_half2FullMappingTable.put("y", "ｙ");
		m_half2FullMappingTable.put("z", "ｚ");
		m_half2FullMappingTable.put("A", "Ａ");
		m_half2FullMappingTable.put("B", "Ｂ");
		m_half2FullMappingTable.put("C", "Ｃ");
		m_half2FullMappingTable.put("D", "Ｄ");
		m_half2FullMappingTable.put("E", "Ｅ");
		m_half2FullMappingTable.put("F", "Ｆ");
		m_half2FullMappingTable.put("G", "Ｇ");
		m_half2FullMappingTable.put("H", "Ｈ");
		m_half2FullMappingTable.put("I", "Ｉ");
		m_half2FullMappingTable.put("J", "Ｊ");
		m_half2FullMappingTable.put("K", "Ｋ");
		m_half2FullMappingTable.put("L", "Ｌ");
		m_half2FullMappingTable.put("M", "Ｍ");
		m_half2FullMappingTable.put("N", "Ｎ");
		m_half2FullMappingTable.put("O", "Ｏ");
		m_half2FullMappingTable.put("P", "Ｐ");
		m_half2FullMappingTable.put("Q", "Ｑ");
		m_half2FullMappingTable.put("R", "Ｒ");
		m_half2FullMappingTable.put("S", "Ｓ");
		m_half2FullMappingTable.put("T", "Ｔ");
		m_half2FullMappingTable.put("U", "Ｕ");
		m_half2FullMappingTable.put("V", "Ｖ");
		m_half2FullMappingTable.put("W", "Ｗ");
		m_half2FullMappingTable.put("X", "Ｘ");
		m_half2FullMappingTable.put("Y", "Ｙ");
		m_half2FullMappingTable.put("Z", "Ｚ");
		m_half2FullMappingTable.put(" ", "　");

		m_half2FullMappingTable.put("~", "～");
		m_half2FullMappingTable.put("^", "︿");
		m_half2FullMappingTable.put("`", "‵");
		m_half2FullMappingTable.put("'", "’");
		m_half2FullMappingTable.put("\"", "＂");
	}

	/**
	 * 
	 * 
	 *
	 */
	private static void registerFull() {

		m_full2HalfMappingTable.clear();

		m_full2HalfMappingTable.put("（", "(");
		m_full2HalfMappingTable.put("（", "(");
		m_full2HalfMappingTable.put("）", ")");
		m_full2HalfMappingTable.put("〔", "[");
		m_full2HalfMappingTable.put("〕", "]");
		m_full2HalfMappingTable.put("｛", "{");
		m_full2HalfMappingTable.put("｝", "}");
		m_full2HalfMappingTable.put("。", ".");
		m_full2HalfMappingTable.put("，", ",");
		m_full2HalfMappingTable.put("；", ";");
		m_full2HalfMappingTable.put("：", ":");
		m_full2HalfMappingTable.put("－", "-");
		m_full2HalfMappingTable.put("？", "?");
		m_full2HalfMappingTable.put("！", "!");
		m_full2HalfMappingTable.put("＠", "@");
		m_full2HalfMappingTable.put("＃", "#");
		m_full2HalfMappingTable.put("＄", "$");
		m_full2HalfMappingTable.put("％", "%");
		m_full2HalfMappingTable.put("＆", "&");
		m_full2HalfMappingTable.put("｜", "|");
		m_full2HalfMappingTable.put("＼", "\\");
		m_full2HalfMappingTable.put("／", "/");
		m_full2HalfMappingTable.put("＋", "+");
		m_full2HalfMappingTable.put("＝", "=");
		m_full2HalfMappingTable.put("＊", "*");
		m_full2HalfMappingTable.put("０", "0");
		m_full2HalfMappingTable.put("１", "1");
		m_full2HalfMappingTable.put("２", "2");
		m_full2HalfMappingTable.put("３", "3");
		m_full2HalfMappingTable.put("４", "4");
		m_full2HalfMappingTable.put("５", "5");
		m_full2HalfMappingTable.put("６", "6");
		m_full2HalfMappingTable.put("７", "7");
		m_full2HalfMappingTable.put("８", "8");
		m_full2HalfMappingTable.put("９", "9");
		m_full2HalfMappingTable.put("ａ", "a");
		m_full2HalfMappingTable.put("ｂ", "b");
		m_full2HalfMappingTable.put("ｃ", "c");
		m_full2HalfMappingTable.put("ｄ", "d");
		m_full2HalfMappingTable.put("ｅ", "e");
		m_full2HalfMappingTable.put("ｆ", "f");
		m_full2HalfMappingTable.put("ｇ", "g");
		m_full2HalfMappingTable.put("ｈ", "h");
		m_full2HalfMappingTable.put("ｉ", "i");
		m_full2HalfMappingTable.put("ｊ", "j");
		m_full2HalfMappingTable.put("ｋ", "k");
		m_full2HalfMappingTable.put("ｌ", "l");
		m_full2HalfMappingTable.put("ｍ", "m");
		m_full2HalfMappingTable.put("ｎ", "n");
		m_full2HalfMappingTable.put("ｏ", "o");
		m_full2HalfMappingTable.put("ｐ", "p");
		m_full2HalfMappingTable.put("ｑ", "q");
		m_full2HalfMappingTable.put("ｒ", "r");
		m_full2HalfMappingTable.put("ｓ", "s");
		m_full2HalfMappingTable.put("ｔ", "t");
		m_full2HalfMappingTable.put("ｕ", "u");
		m_full2HalfMappingTable.put("ｖ", "v");
		m_full2HalfMappingTable.put("ｗ", "w");
		m_full2HalfMappingTable.put("ｘ", "x");
		m_full2HalfMappingTable.put("ｙ", "y");
		m_full2HalfMappingTable.put("ｚ", "z");
		m_full2HalfMappingTable.put("Ａ", "A");
		m_full2HalfMappingTable.put("Ｂ", "B");
		m_full2HalfMappingTable.put("Ｃ", "C");
		m_full2HalfMappingTable.put("Ｄ", "D");
		m_full2HalfMappingTable.put("Ｅ", "E");
		m_full2HalfMappingTable.put("Ｆ", "F");
		m_full2HalfMappingTable.put("Ｇ", "G");
		m_full2HalfMappingTable.put("Ｈ", "H");
		m_full2HalfMappingTable.put("Ｉ", "I");
		m_full2HalfMappingTable.put("Ｊ", "J");
		m_full2HalfMappingTable.put("Ｋ", "K");
		m_full2HalfMappingTable.put("Ｌ", "L");
		m_full2HalfMappingTable.put("Ｍ", "M");
		m_full2HalfMappingTable.put("Ｎ", "N");
		m_full2HalfMappingTable.put("Ｏ", "O");
		m_full2HalfMappingTable.put("Ｐ", "P");
		m_full2HalfMappingTable.put("Ｑ", "Q");
		m_full2HalfMappingTable.put("Ｒ", "R");
		m_full2HalfMappingTable.put("Ｓ", "S");
		m_full2HalfMappingTable.put("Ｔ", "T");
		m_full2HalfMappingTable.put("Ｕ", "U");
		m_full2HalfMappingTable.put("Ｖ", "V");
		m_full2HalfMappingTable.put("Ｗ", "W");
		m_full2HalfMappingTable.put("Ｘ", "X");
		m_full2HalfMappingTable.put("Ｙ", "Y");
		m_full2HalfMappingTable.put("Ｚ", "Z");
		m_full2HalfMappingTable.put("　", " ");

		m_half2FullMappingTable.put("～", "~");
		m_half2FullMappingTable.put("︿", "^");
		m_half2FullMappingTable.put("‵", "`");
		m_half2FullMappingTable.put("’", "'");
		m_half2FullMappingTable.put("＂", "\"");
	}

}

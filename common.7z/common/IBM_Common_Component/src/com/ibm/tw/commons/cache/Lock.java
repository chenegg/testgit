/*
 * ===========================================================================
 * IBM Confidential AIS Source Materials
 * 
 * Read/Write Lock
 * 
 * (C) Copyright IBM Corp. 2005.
 * 
 * ===========================================================================
 */
package com.ibm.tw.commons.cache;

/**
 * @author Kevin
 * @version 1.0, 2006/1/23
 * @see
 * @since
 */
public class Lock {
    //寫入優先
    private boolean m_bWriterFirst = true;

    // 正在寫入者之個數
    private int m_iWritingWriters = 0;

    // 等待寫入者之個數
    private int m_iWaitingWriters = 0;

    // 正在讀取者之個數
    private int m_iReadingReaders = 0;

    /**
     * get read lock
     *  
     */
    public synchronized void readLock() {
        try {
            while (m_iWritingWriters > 0 || (m_bWriterFirst && m_iWaitingWriters > 0)) {
                //System.err.println("wait read lock");
                wait();
            }
        }
        catch (InterruptedException e) {
        }

        m_iReadingReaders++;
    }

    /**
     * rlease read lock
     *  
     */
    public synchronized void readUnLock() {
        m_iReadingReaders--;
        m_bWriterFirst = true;
        notifyAll();
    }

    /**
     * get write lock
     *  
     */
    public synchronized void writeLock() {
        m_iWaitingWriters++;
        try {
            while (m_iReadingReaders > 0 || m_iWritingWriters > 0) {
                //System.err.println("wait write lock");
                wait();
            }
        }
        catch (InterruptedException e) {
        }
        finally {
            m_iWaitingWriters--;
        }

        m_iWritingWriters++;
    }

    /**
     * release write lock
     *  
     */
    public synchronized void writeUnLock() {
        m_iWritingWriters--;
        m_bWriterFirst = false;
        notifyAll();
    }

}

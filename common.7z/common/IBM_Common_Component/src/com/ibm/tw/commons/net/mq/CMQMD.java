/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2009.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import java.util.GregorianCalendar;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMD;
 

/**
 * <p>MQ MQMD</p>
 *
 * @author  jeff
 * @version 1.0, Mar 16, 2009
 * @see	    
 * @since 
 */
public class CMQMD {
	
	private int m_report = MQC.MQRO_NONE;
	
	private int m_messageType = MQC.MQMT_DATAGRAM;
 
	/** MQ Expiry Time (1/10) */
	private int m_expiry = MQC.MQEI_UNLIMITED;
	
	private int m_feedback = MQC.MQFB_NONE;
	
	/** MQ Encoding */
	private int m_encoding = MQC.MQENC_NATIVE;
	 
	/** MQ Character Set (編碼) */
	private int m_characterSet = CMQMessage.DEFAULT_CCSID;
	
	/** MQ Formate (String, RFH2) */
	private String m_format = MQC.MQFMT_NONE;;
	
	private int m_priority = MQC.MQPRI_PRIORITY_AS_Q_DEF;
	
	/** Read-write. The message's persistence setting */
	private int m_persistence = MQC.MQPER_PERSISTENCE_AS_Q_DEF;
	 
	/** MQ Message ID */
	private byte[] m_messageId = MQC.MQMI_NONE;
	
	/** MQ Correlation ID */
	private byte[] m_correlationId = MQC.MQMI_NONE;
	
	/** Read-only. The MQMD BackoutCount */
	private int m_backoutCount = 0;
	
	/** MQ Group ID */
	private byte[] m_groupId = MQC.MQMI_NONE;
	
	/** Reply To Queue Manager Name */
	private String m_replyToQueueManagerName = "";
	
	/** Reply To Queue Name */
	private String m_replyToQueueName = "";
	
	/** Version */
	private int m_version = MQC.MQMD_VERSION_2;
	
	private String m_putApplicationName = "";
	
	private GregorianCalendar m_putDateTime = null;
	
 
	
	public CMQMD() {
		
	}
	
	public CMQMD(MQMD mqmd) {
		decode(mqmd);
	}
	
	/**
	 * MQMD -> CMQMD
	 * 
	 * @param mqmd
	 */
	public void decode(MQMD mqmd) {
		m_report = mqmd.report;
		
		m_messageType = mqmd.messageType;
		
		m_expiry = mqmd.expiry;
		
		m_feedback = mqmd.feedback;
		
		m_encoding = mqmd.encoding;
		
		m_characterSet = mqmd.characterSet;
		
		m_format = mqmd.format;
		
		m_priority = mqmd.priority;
		
		m_persistence = mqmd.persistence;
		
		m_messageId = new byte[mqmd.messageId.length];
		System.arraycopy(mqmd.messageId, 0, m_messageId, 0, m_messageId.length);
		
 	
		
		m_correlationId = new byte[mqmd.correlationId.length];
		System.arraycopy(mqmd.correlationId, 0, m_correlationId, 0, m_correlationId.length);
		
		m_backoutCount = mqmd.backoutCount;
		
		m_groupId = new byte[mqmd.groupId.length];
		System.arraycopy(mqmd.groupId, 0, m_groupId, 0, m_groupId.length);
		
		m_replyToQueueManagerName = mqmd.replyToQueueManagerName;
		
		m_replyToQueueName = mqmd.replyToQueueName;
		
		m_version = mqmd.getVersion();
		
		m_putApplicationName = mqmd.putApplicationName;
		
		m_putDateTime = mqmd.putDateTime;
	}
	
	/**
	 * CMQMD -> MQMD (MQMessage)
	 * 
	 * @param mqmd
	 * @throws MQException 
	 * @throws MQException 
	 */
	public void encode(MQMD mqmd) throws MQException {
		mqmd.report = m_report;
		
		mqmd.messageType = m_messageType;
		
		mqmd.expiry = m_expiry;
		
		mqmd.feedback = m_feedback;
		
		mqmd.encoding = m_encoding;
		
		mqmd.characterSet = m_characterSet;
		
		mqmd.format = m_format;
		
		mqmd.priority = m_priority;
		
		mqmd.persistence = m_persistence;
		
		mqmd.messageId = new byte[m_messageId.length];
		 
		System.arraycopy(m_messageId, 0, mqmd.messageId, 0, m_messageId.length);
		
		mqmd.correlationId = new byte[m_correlationId.length];
		System.arraycopy(m_correlationId, 0, mqmd.correlationId, 0, m_correlationId.length);
		
		mqmd.backoutCount = m_backoutCount;
		
		mqmd.groupId = new byte[m_groupId.length];
	 
		System.arraycopy(m_groupId, 0, mqmd.groupId, 0, m_groupId.length);
		
		mqmd.replyToQueueManagerName = m_replyToQueueManagerName;
		
		mqmd.replyToQueueName = m_replyToQueueName;
		
		mqmd.setVersion(m_version);
		 
		
		mqmd.putApplicationName = m_putApplicationName;
		
		mqmd.putDateTime = m_putDateTime;
	}

	public int getCharacterSet() {
		return m_characterSet;
	}

	public void setCharacterSet(int characterSet) {
		this.m_characterSet = characterSet;
	}

	public byte[] getCorrelationId() {
		return m_correlationId;
	}

	public void setCorrelationId(byte[] correlationId) {
		this.m_correlationId = correlationId;
	}

	public int getEncoding() {
		return m_encoding;
	}

	public void setEncoding(int encoding) {
		this.m_encoding = encoding;
	}

	public String getFormat() {
		return m_format;
	}

	public void setFormat(String format) {
		this.m_format = format;
	}

	public byte[] getGroupId() {
		return m_groupId;
	}

	public void setGroupId(byte[] groupId) {
		this.m_groupId = groupId;
	}

	public byte[] getMessageId() {
		return m_messageId;
	}

	public void setMessageId(byte[] messageId) {
		this.m_messageId = messageId;
	}

	public int getVersion() {
		return m_version;
	}

	public void setVersion(int version) {
		this.m_version = version;
	}
	
	 
	public int getExpiry() {
		return m_expiry;
	}
	
	public void setExpiry(int expiry) {
		m_expiry = expiry;
	}

	public int getBackoutCount() {
		return m_backoutCount;
	}

 
	public int getFeedback() {
		return m_feedback;
	}

	public void setFeedback(int m_feedback) {
		this.m_feedback = m_feedback;
	}
 
 
 

	public int getMessageType() {
		return m_messageType;
	}

	public void setMessageType(int type) {
		m_messageType = type;
	}

	public int getPersistence() {
		return m_persistence;
	}

	public void setPersistence(int m_persistence) {
		this.m_persistence = m_persistence;
	}

	public int getPriority() {
		return m_priority;
	}

	public void setPriority(int m_priority) {
		this.m_priority = m_priority;
	}

	public String getPutApplicationName() {
		return m_putApplicationName;
	}

	public void setPutApplicationName(String applicationName) {
		m_putApplicationName = applicationName;
	}

	public GregorianCalendar getPutDateTime() {
		return m_putDateTime;
	}

	public void setPutDateTime(GregorianCalendar dateTime) {
		m_putDateTime = dateTime;
	}

	public String getReplyToQueueManagerName() {
		return m_replyToQueueManagerName;
	}

	public void setReplyToQueueManagerName(String toQueueManagerName) {
		m_replyToQueueManagerName = toQueueManagerName;
	}

	public String getReplyToQueueName() {
		return m_replyToQueueName;
	}

	public void setReplyToQueueName(String toQueueName) {
		m_replyToQueueName = toQueueName;
	}

	public int getReport() {
		return m_report;
	}

	public void setReport(int m_report) {
		this.m_report = m_report;
	}

 
	
}



 
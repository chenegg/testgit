/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 字串處理工具集
 * <p>
 * 字串工具集主要功能繼承自{@link org.apache.commons.lang.StringUtils}， 並增加下列功能：
 * <ul>
 * <li>金額型態字串處理功能</li>
 * <li>字串切割功能</li>
 * </ul>
 * </p>
 * 
 * @author Jeff Liu
 * @version 1.0, 2004/10/18
 * @see {@link org.apache.commons.lang.StringUtils}
 * @since
 */
public class StringUtils extends org.apache.commons.lang.StringUtils {

	private static Logger logger = LoggerFactory.getLogger(StringUtils.class);

	/**
	 * 根據字串長度切割字串，一個中文字長度是1
	 * 
	 * <pre>
	 * StringUtils.getTokens(null, *)         	= []
	 * StringUtils.getTokens("", *)           	= []
	 * StringUtils.getTokens("abc def", -1) 	= []
	 * StringUtils.getTokens("abc def", 0)  	= []
	 * StringUtils.getTokens("abc  def", 2) 	= ["ab", "c ", "de", "f"]
	 * </pre>
	 * 
	 * @param sData   原始字串
	 * @param iLength 切割的長度
	 * @return 字串陣列，永不為null
	 */
	public static String[] getTokens(String sData, int iLength) {

		if (null == sData || iLength < 1) {
			return ArrayUtils.EMPTY_STRING_ARRAY;
		}

		List<String> tokens = new ArrayList<String>();

		int iLeft = 0;

		int iDataLen = sData.length();

		while (iLeft < iDataLen) {

			int iRight = (iLeft + iLength) > iDataLen ? iDataLen : iLeft + iLength;

			String sToken = sData.substring(iLeft, iRight);

			iLeft += iLength;

			tokens.add(sToken);
		}

		return (String[]) tokens.toArray(new String[tokens.size()]);
	}

	/**
	 * 根據字串實際的長度切割字串
	 * 
	 * <pre>
	 * 	StringUtils.getTokens(null, *)         	= []
	 * 	StringUtils.getTokens("", *)           	= []
	 * 	StringUtils.getTokens("abc def", -1) 	= []
	 * 	StringUtils.getTokens("abc def", 0)  	= []
	 * StringUtils.getTokens("abc  def", 2) 	= ["ab", "c ", "de", "f"]
	 * </pre>
	 * 
	 * @param sData   原始字串
	 * @param iLength 切割的長度(byte)
	 * @return 切割後的字串陣列，永不為NULL
	 */
	public static String[] getTokensByBytes(String sData, int iLength) {

		if (null == sData || iLength < 1) {
			return ArrayUtils.EMPTY_STRING_ARRAY;
		}

		List<String> tokens = new ArrayList<String>();

		byte[] datas = sData.getBytes();

		int iLeft = 0;

		int iTotalLength = datas.length;

		while (iLeft < iTotalLength) {

			int iTokenLength = (iLeft + iLength) > iTotalLength ? iTotalLength - iLeft : iLength;

			byte[] token = new byte[iTokenLength];

			System.arraycopy(datas, iLeft, token, 0, iTokenLength);

			iLeft += iLength;

			tokens.add(new String(token));
		}

		return (String[]) tokens.toArray(new String[tokens.size()]);
	}

	/**
	 * 根據分隔子切割字串
	 * 
	 * <pre>
	 * StringUtils.getTokens(null, *)         	= []
	 * StringUtils.getTokens("", *)           	= []
	 * StringUtils.getTokens("abc def", null) 	= ["abc", "def"]
	 * StringUtils.getTokens("abc def", " ")  	= ["abc", "def"]
	 * StringUtils.getTokens("abc  def", " ") 	= ["abc", "def"]
	 * StringUtils.getTokens("ab:cd:ef", ":") 	= ["ab", "cd", "ef"]
	 * StringUtils.getTokens("ab:cd:ef:", ":") = ["ab", "cd", "ef", ""]
	 * </pre>
	 * 
	 * @param sData   原始字串
	 * @param iLength 切割的長度(byte)
	 * @return 切割後的字串陣列，永不為NULL
	 */
	public static String[] getTokens(String sData, String sDelim) {

		if (null == sData) {
			return ArrayUtils.EMPTY_STRING_ARRAY;
		}

		List<String> tokens = new ArrayList<String>();

		int iDataLen = sData.length();
		int iDelimLen = sDelim.length();

		int iLeft = 0;
		int iRight = sData.indexOf(sDelim);

		while (iRight >= 0) {

			String sToken = sData.substring(iLeft, iRight).trim();
			tokens.add(sToken);
			iLeft = iRight + iDelimLen;
			iRight = sData.indexOf(sDelim, iLeft);
		}

		if (iLeft < iDataLen) {
			String sToken = sData.substring(iLeft, iDataLen);
			tokens.add(sToken);
		}

		// 取最後一個token，如果為delim則加入一個空白("")token
		if (iDataLen >= iDelimLen) {
			String sLastToken = sData.substring(iDataLen - iDelimLen, iDataLen);

			if (sLastToken.equals(sDelim)) {
				tokens.add("");
			}
		}
		return (String[]) tokens.toArray(new String[tokens.size()]);

	}

	/**
	 * 取代字串中的分隔子
	 * 
	 * <pre>
	 * StringUtils.replaceDelim(null, null, null)			= null
	 * StringUtils.replaceDelim("", null, null)           	= ""
	 * StringUtils.replaceDelim("a*b*c*, "*", []) 			= "a*b*c*"
	 * StringUtils.replaceDelim("a*b*c*", "*", null)  		= "a*b*c*"
	 * StringUtils.replaceDelim("a*b*c*", "*", [1])    	= "a*b*c*"
	 * StringUtils.replaceDelim("a*b*c*", "*", [1, 2, 3])  = "a1b2c3"
	 * StringUtils.replaceDelim("a*b*c*", "&", [1, 2, 3])  = "a*b*c*"
	 * </pre>
	 * 
	 * @param sSource string to seach and replace in, may be null
	 * @param sDelim  the string to search for, may be null
	 * @param with    the strings to replace with
	 * @return
	 */
	public static String replaceDelim(String sSource, String sDelim, String with[]) {

		if (sSource == null || sDelim == null || with == null || sDelim.length() == 0 || with.length == 0) {
			return sSource;
		}

		String[] tokens = StringUtils.getTokens(sSource, sDelim);

		// token number - 1 == with number
		if ((tokens.length - 1) != with.length) {
			return sSource;
		}

		StringBuffer sb = new StringBuffer("");

		for (int i = 0; i < with.length; i++) {

			sb.append(tokens[i]);

			sb.append(with[i]);
		}

		// last token
		sb.append(tokens[tokens.length - 1]);

		return sb.toString();

	}

	// /**
	// * 取代字串中的分隔子
	// * <pre>
	// * StringUtils.replaceDelim(null, null, null) = null
	// * StringUtils.replaceDelim("", null, null) = ""
	// * StringUtils.replaceDelim("a*b*c*, "*", []) = "a*b*c*"
	// * StringUtils.replaceDelim("a*b*c*", "*", null) = "a*b*c*"
	// * StringUtils.replaceDelim("a*b*c*", "*", [1]) = "a*b*c*"
	// * StringUtils.replaceDelim("a*b*c*", "*", [1, 2, 3]) = "a1b2c3"
	// * StringUtils.replaceDelim("a*b*c*", "&", [1, 2, 3]) = "a*b*c*"
	// * </pre>
	// *
	// * @param sSource string to seach and replace in, may be null
	// * @param sDelim the string to search for, may be null
	// * @param with the strings to replace with
	// * @return
	// */
	// public static String replaceDelim(String sSource, String sDelim, List
	// with) {
	//
	// String[] array = (String[]) with.toArray(new String[with.size()]);
	//
	// return replaceDelim(sSource, sDelim, array);
	//
	// }

	/**
	 * 將字串轉換為數字，如果轉換失敗則回傳預設值
	 * 
	 * <pre>
	 * ConvertUtils.str2Int(null) = 0
	 * ConvertUtils.str2Int("abc") = 0
	 * ConvertUtils.str2Int("1") = 1
	 * </pre>
	 * 
	 * @param sValue        待轉換之字串
	 * @param iDefaultValue 轉換失敗時之預設值
	 * @return 轉換後之數字，失敗則傳回iDefaultValue
	 * 
	 * @deprecated 請改使用{@link com.ibm.tw.util.ConvertUtils.str2Int}
	 */
	public static int str2Int(String sValue, int iDefaultValue) {
		int iValue = iDefaultValue;
		try {
			iValue = Integer.parseInt(sValue);
		} catch (Exception e) {
			iValue = iDefaultValue;
		}

		return iValue;
	}

	/**
	 * 將字串轉換為數字，如果轉換失敗則回傳0
	 * 
	 * <pre>
	 * ConvertUtils.str2Int(null, 0) = 0
	 * ConvertUtils.str2Int("abc", 0) = 0
	 * ConvertUtils.str2Int("1", 0) = 1
	 * </pre>
	 * 
	 * @param sValue        待轉換之字串
	 * @param iDefaultValue 轉換失敗時之預設值
	 * @return 轉換後之數字，失敗則傳回0
	 * 
	 * @deprecated 請改使用{@link com.ibm.tw.util.ConvertUtils.str2Int)}
	 */
	public static int str2Int(String sValue) {
		return ConvertUtils.str2Int(sValue, 0);
	}

	/**
	 * 將字串轉換為金額的表示方式
	 * 
	 * <pre>
	 * StringUtils.getMoneyStr(null) = ""
	 * StringUtils.getMoneyStr(" ") = ""
	 * StringUtils.getMoneyStr("1234567.89") = "1,234,567.89"
	 * StringUtils.getMoneyStr("1234567.00") = "1,234,567"
	 * StringUtils.getMoneyStr("1234567.0100") = "1,234,567.01"
	 * </pre>
	 * 
	 * @param sMoney
	 * @return
	 */
	public static String getMoneyStr(String sMoney) {

		if (isBlank(sMoney)) {
			return "";
		}

		sMoney = sMoney.trim();

		StringBuffer sb = new StringBuffer();
		int iLen = sMoney.length();

		if (sMoney.startsWith("+") || sMoney.startsWith("-")) {

			String sSign = substring(sMoney, 0, 1);
			// '-' 放回去, '+' 濾除
			sb.append(sSign.equals("-") ? sSign : "");
			sMoney = substring(sMoney, 1);
		}

		// 整數
		String sInt = "";

		// 小數
		String sDecimal = "";

		// 小數點
		String sDot = "";

		int index = sMoney.indexOf(".");

		if (index >= 0) {
			sDot = ".";
			sInt = sMoney.substring(0, index);
			if ((index + 1) < iLen) {
				sDecimal = sMoney.substring(index + 1, sMoney.length());
			}
		} else {
			sInt = sMoney;
		}

		// 整數
		sInt = getIntMoneyStr(sInt);

		// 小數
		sDecimal = trimRightZero(sDecimal);

		// 有整數部分
		if (sInt.length() > 0) {
			sb.append(sInt);

			if (sDecimal.length() > 0) {
				sb.append(sDot).append(sDecimal);
			}
		}
		// 沒有整數部分
		else {
			if (sDecimal.length() > 0) {
				sb.append("0.").append(sDecimal);
			} else {
				sb.append("0");
			}
		}

		return sb.toString();
	}

	/**
	 * 將字串轉換為金額的表示方式
	 * 
	 * <pre>
	 * StringUtils.getMoneyStr(null, 1) = ""
	 * StringUtils.getMoneyStr(" ", 2) = ""
	 * StringUtils.getMoneyStr("1234567.89", 2) = "1,234,567.89" 
	 * StringUtils.getMoneyStr("1234567.00", 1) = "1,234,567.0";
	 * StringUtils.getMoneyStr("1234567.0100", 2) = "1,234,567.01";
	 * </pre>
	 * 
	 * @param sMoney 待轉換之字串
	 * @param iScale 小數有效位數
	 * @return 金額表示型態的字串，永不為null
	 */
	public static String getMoneyStr(String sMoney, int iScale) {

		if (isBlank(sMoney)) {
			return "";
		}

		sMoney = sMoney.trim();

		StringBuffer sb = new StringBuffer();
		int iLen = sMoney.length();

		if (sMoney.startsWith("+") || sMoney.startsWith("-")) {

			String sSign = substring(sMoney, 0, 1);
			// '-' 放回去, '+' 濾除
			sb.append(sSign.equals("-") ? sSign : "");
			sMoney = substring(sMoney, 1);
		}

		// 整數
		String sInt = "";

		// 小數
		String sDecimal = "";

		// 小數點
		String sDot = "";

		int index = sMoney.indexOf(".");

		if (index >= 0) {
			sDot = ".";
			sInt = sMoney.substring(0, index);
			if ((index + 1) < iLen) {
				sDecimal = sMoney.substring(index + 1, sMoney.length());
			}
		} else {
			sInt = sMoney;
		}

		// 整數
		sInt = getIntMoneyStr(sInt);

		// 小數
		sDecimal = substring(sDecimal, 0, iScale);

		// 有整數部分
		if (sInt.length() > 0) {
			sb.append(sInt);

			if (sDecimal.length() > 0) {
				sb.append(sDot).append(rightPad(sDecimal, iScale, "0"));
			} else {
				if (iScale > 0) {
					sb.append(".").append(rightPad(sDecimal, iScale, "0"));
				}
			}
		}
		// 沒有整數部分
		else {
			if (sDecimal.length() > 0) {
				sb.append("0.").append(rightPad(sDecimal, iScale, "0"));
			} else {
				if (iScale > 0) {
					sb.append("0.").append(rightPad(sDecimal, iScale, "0"));
				} else {
					sb.append("0");
				}
			}
		}

		return sb.toString();
	}

	/**
	 * 將字串轉換為金額表示型態的字串
	 * 
	 * <pre>
	 * StringUtils.getIntMoneyStr(&quot;001234567&quot;) = &quot;1,234,567&quot;
	 * </pre>
	 * 
	 * @param sInt
	 * @return
	 * 
	 * @deprecated 請改用{@link com.ibm.tw.utils.StringUtils.getMoneyStr}
	 */
	public static String getIntMoneyStr(String sInt) {

		if (isBlank(sInt)) {
			return "";
		}

		sInt = sInt.trim();

		//
		// long lAmountInteger = Long.parseLong(sInt);
		//
		// String sPattern = "###,###";
		//
		// DecimalFormat df = new DecimalFormat(sPattern);
		//
		// return df.format(lAmountInteger);

		StringBuffer sb = new StringBuffer();

		sInt = trimLeftZero(sInt);
		int iLen = sInt.length();

		for (int i = 0; i < iLen; i++) {

			char ch = sInt.charAt(i);

			sb.append(ch);
			// 剩餘長度
			int iRemainLen = iLen - i - 1;

			if ((iRemainLen > 0) && (iRemainLen % 3 == 0)) {
				sb.append(",");
			}

		}
		return sb.toString();

	}

	/**
	 * 將數字字串依照指定的小數位數輸出成浮點數字串
	 * 
	 * <pre>
	 * parseFloat("12345678", 2) -> "123456.78"
	 * parseFloat("12345678", 6) -> "12.345678"
	 * parseFloat("12345678", 10) -> "0.0012345678"
	 * parseFloat("12345678", 0) -> "12345678"
	 * parseFloat("12345678", -1) -> "12345678"
	 * parseFloat("a12s5w6dd", 3) -> ""
	 * parseFloat("", 3) -> ""
	 * parseFloat(null, 3) -> ""
	 * </pre>
	 * 
	 * @param sSourceStr 原始字串
	 * @param iScale     小數位數
	 * @return
	 */
	public static String parseFloat(String sSourceStr, int iScale) {

		if (!NumericUtils.isDigits(sSourceStr)) {
			return "";
		}

		if (StringUtils.isBlank(sSourceStr) || iScale < 1) {
			return StringUtils.defaultString(sSourceStr);
		}

		String sInt = "";

		String sDecimal = "";

		int iLength = sSourceStr.length();

		if (iLength > iScale) {
			// 整數長度
			int iIntLength = iLength - iScale;

			sInt = sSourceStr.substring(0, iIntLength);

			sDecimal = sSourceStr.substring(iIntLength);
		} else {

			sInt = "0";

			sDecimal = StringUtils.leftPad(sSourceStr, iScale, "0");

		}

		return sInt + "." + sDecimal;
	}

	/**
	 * 移除字串左邊的<code>0</code>字元
	 * 
	 * <pre>
	 * StringUtils.trimLeftZero(null) = ""
	 * StringUtils.trimLeftZero("0012345600") = "12345600"
	 * </pre>
	 * 
	 * @param sSource 待處理之字串
	 * @return 移除左側<code>0</code>字元後的字串，永不為null
	 */
	public static String trimLeftZero(String sSource) {

		if (sSource == null) {
			return "";
		}

		int iLen = sSource.length();
		int index = -1;
		for (int i = 0; (i < iLen && index < 0); i++) {
			char ch = sSource.charAt(i);

			if (ch != '0') {
				index = i;
			}
		}
		String s = "";
		// 發現非0之數字
		if (index >= 0) {
			s = sSource.substring(index, iLen);
		}

		return s;

	}

	// /**
	// * StringUtils.trimLeft(" 345600") = "345600"
	// * StringUtils.trimLeft(" 345600 ") = "345600 "
	// *
	// * @param sSource
	// * @return
	// */
	// public static String trimLeft(String sSource) {
	//
	//
	//
	// if (sSource == null) {
	// return "";
	// }
	//
	// int iLen = sSource.length();
	// int index = -1;
	// for (int i = 0; (i < iLen && index < 0) ; i++) {
	// char ch = sSource.charAt(i);
	//
	// if (ch != ' ') {
	// index = i;
	// }
	// }
	// String s = "";
	//
	// if (index >= 0) {
	// s = sSource.substring(index, iLen);
	// }
	//
	//
	// return s;
	//
	// }

	/**
	 * StringUtils.trimRightZero("01234500") = "012345"
	 * 
	 * @param sSource
	 * @return
	 */
	public static String trimRightZero(String sSource) {

		if (sSource == null) {
			return "";
		}

		int iLen = sSource.length();
		int index = -1;
		// 由後至前
		for (int i = (iLen - 1); (i >= 0 && index < 0); i--) {
			char ch = sSource.charAt(i);
			if (ch != '0') {
				index = i;
			}
		}

		String s = "";
		if (index >= 0) {
			s = sSource.substring(0, index + 1);
		}

		return s;
	}

	/**
	 * 將字串轉換為百分比顯示型態
	 * 
	 * <pre>
	 * StringUtils.getRateStr(null) = ""
	 * StringUtils.getRateStr("000122.00100") = "122.001"
	 * StringUtils.getRateStr("00.12") = "0.12"
	 * StringUtils.getRateStr("00.00") = "0.0"
	 * </pre>
	 * 
	 * @param sRate
	 * @return 轉換後之百分比顯示型態字串，永不為null
	 */
	public static String getRateStr(String sRate) {
		if (StringUtils.isBlank(sRate)) {
			return "";
		}

		StringBuffer sb = new StringBuffer();
		int iLen = sRate.length();

		// 整數
		String sInt = "";

		// 小數
		String sDecimal = "";

		// 小數點
		String sDot = "";

		int index = sRate.indexOf(".");

		if (index >= 0) {
			sDot = ".";
			sInt = sRate.substring(0, index);
			if ((index + 1) < iLen) {
				sDecimal = sRate.substring(index + 1, sRate.length());
			}
		} else {
			sInt = sRate;
		}

		// 整數
		sInt = trimLeftZero(sInt);

		// 小數
		sDecimal = trimRightZero(sDecimal);

		// 有整數部分
		if (sInt.length() > 0) {
			sb.append(sInt);

			if (sDecimal.length() > 0) {
				sb.append(sDot).append(sDecimal);
			}
		}
		// 沒有整數部分
		else {
			if (sDecimal.length() > 0) {
				sb.append("0.").append(sDecimal);
			} else {
				sb.append("0.0");
			}
		}

		// sb.append("%");

		return sb.toString();
	}

	/**
	 * 取得字串中的整數部分
	 * 
	 * <pre>
	 * StringUtils.getRateStr(null) = ""
	 * StringUtils.getRateStr("000122.00100") = "122"
	 * </pre>
	 * 
	 * @param sRate
	 * @return
	 */
	public static String getIntPart(String sRate) {

		if (StringUtils.isBlank(sRate)) {
			return "";
		}

		// 整數
		String sInt = "";

		int index = sRate.indexOf(".");

		if (index >= 0) {
			sInt = sRate.substring(0, index);
		} else {
			sInt = sRate;
		}

		// 整數
		sInt = trimLeftZero(sInt);

		return sInt;
	}

	/**
	 * 移除字串右邊之全形空白
	 * 
	 * @param sValue
	 * @return
	 */
	public static String trimRightBigSpace(String sValue) {
		String sResult = sValue;

		if (StringUtils.isNotBlank(sValue)) {
			while (sResult.endsWith("　")) {
				sResult = sResult.substring(0, sResult.length() - 1);
			}
		}

		return sResult;
	}

	/**
	 * 將StringArray轉換為SQL的Where In格式 ex : StringUtils.StrArray2WhereInSql(["A", "B",
	 * "C"]) = "'A','B','C'"
	 * 
	 * @param array
	 * @param sSeparator
	 * @return
	 */
	public static String StrArray2WhereInSql(String[] array) {
		if (array == null) {
			return null;
		}

		String sSeparator = ",";

		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < array.length; i++) {
			if (i != 0) {
				sb.append(sSeparator);
			}
			sb.append("'").append(StringUtils.defaultString(array[i])).append("'");
		}

		return sb.toString();
	}

	/**
	 * 
	 * 把大寫的空白拿掉
	 * 
	 */
	public static String trimAll(String str) {
		if (str == null) {
			return null;
		}
		StringBuffer s = new StringBuffer(100);
		for (int i = 0; i < str.length(); i++) {
			if (!(str.charAt(i) == '　' || str.charAt(i) == ' '))
				s.append(str.charAt(i));
		}
		return s.toString();
	}

	/**
	 * 移除字串左右邊之半形、全形空白
	 * 
	 * @param sValue
	 * @return
	 */
	public static String trimAllBigSpace(String sValue) {

		if (StringUtils.isBlank(sValue)) {
			return "";
		}

		String sResult = sValue;

		while (sResult.endsWith("　") || sResult.endsWith(" ")) {
			sResult = sResult.substring(0, sResult.length() - 1);
		}

		while (sResult.startsWith("　") || sResult.startsWith(" ")) {
			sResult = sResult.substring(1);
		}

		return sResult;
	}

	/*** 後置 0 ***/
	public static String post_space(String inpustr, int len) {
		String rtn_str = "";
		String space = "";
		for (int i = 0; i < (11 - inpustr.length()); i++) {
			space = space + " ";
		}

		rtn_str = inpustr + space;
		return rtn_str;
	}

	/**
	 * Encode a string using algorithm specified in web.xml and return the resulting
	 * encrypted password. If exception, the plain credentials string is returned
	 *
	 * @param password  Password or other credentials to use in authenticating this
	 *                  username
	 * @param algorithm Algorithm used to do the digest
	 *
	 * @return encypted password based on the algorithm.
	 */
	public static String encodePassword(String password, String algorithm) {
		byte[] unencodedPassword = password.getBytes();

		MessageDigest md = null;

		try {
			// first create an instance, given the provider
			md = MessageDigest.getInstance(algorithm);
		} catch (Exception e) {
			logger.error("Exception: " + e);

			return password;
		}

		md.reset();

		// call the update method one or more times
		// (useful when you don't know the size of your data, eg. stream)
		md.update(unencodedPassword);

		// now calculate the hash
		byte[] encodedPassword = md.digest();

		StringBuffer buf = new StringBuffer();

		for (int i = 0; i < encodedPassword.length; i++) {
			if ((encodedPassword[i] & 0xff) < 0x10) {
				buf.append("0");
			}

			buf.append(Long.toString(encodedPassword[i] & 0xff, 16));
		}

		return buf.toString();
	}

	public static String getStackTraceAsString(Throwable exception) {
		ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
		PrintWriter printwriter = new PrintWriter(bytearrayoutputstream, true);
		exception.printStackTrace(printwriter);
		return bytearrayoutputstream.toString();
	}

	public static String trimLeft(String s) {
		int j = s.length();
		if (j == 0)
			return s;
		int i = 0;
		do {
			if (i >= j)
				break;
			char c = s.charAt(i);
			if (c != ' ' && c != '\t')
				break;
			i++;
		} while (true);
		if (i == j)
			return "";
		else
			return s.substring(i);
	}

	public static String trimRight(String s) {
		int j = s.length();
		if (j == 0)
			return s;
		int i = j - 1;
		do {
			if (i < 0)
				break;
			char c = s.charAt(i);
			if (c != ' ' && c != '\t')
				break;
			i--;
		} while (true);
		if (i < 0)
			return "";
		else
			return s.substring(0, i + 1);
	}

	public static String fillLeft(String s, int i, char c) {
		StringBuffer stringbuffer = new StringBuffer();
		for (int j = i; j > s.length(); j--)
			stringbuffer.append(c);

		stringbuffer.append(s);
		return stringbuffer.toString();
	}

	public static String fillRight(String s, int i, char c) {
		StringBuffer stringbuffer = new StringBuffer();
		stringbuffer.append(s);
		for (int j = i; j > s.length(); j--)
			stringbuffer.append(c);

		return stringbuffer.toString();
	}

	public static String replace(String s, String s1, String s2) {
		if (s1 != s2) {
			StringBuffer stringbuffer = new StringBuffer();
			int i = s.length();
			int j = s1.length();
			int k = s2.length();
			for (int l = 0; l < i;) {
				int i1 = s.indexOf(s1, l);
				if (i1 >= l) {
					stringbuffer.append(s.substring(l, i1));
					stringbuffer.append(s2);
					l = i1 + j;
				} else {
					stringbuffer.append(s.substring(l));
					l = i;
				}
			}

			return stringbuffer.toString();
		} else {
			return s;
		}
	}

	public static String trimDoubleToPrecision(double d, int i) {
		String s;
		if (i >= 0)
			s = String.valueOf(d + Math.pow(10D, -(i + 1)) * (double) 5);
		else
			s = String.valueOf(d);
		int j = s.indexOf('.') + i + 1;
		if (j <= 0 || j >= s.length())
			return s;
		else
			return s.substring(0, j);
	}

	public static String trimDoubleToPrecision(String s, int i) throws NumberFormatException {
		double d = Double.parseDouble(s);
		return trimDoubleToPrecision(d, i);
	}

	// to-do
	public static String getDateLong(Date date) {
		long long_time = date.getTime();
		String.valueOf(long_time);
		return String.valueOf(long_time);
	}

	/**
	 * 置換掉全形空白 and 做 String 的 trim
	 * 
	 * @param str
	 * @return
	 */
	public static String replaceAllSpace(String str) {
		return str == null ? str : str.replaceAll("　", "").trim();
	}

	/**
	 * 去掉金額欄位的千分位逗號 比如 : for VB53 用
	 * 
	 * @param str
	 * @return
	 */
	public static String replaceAllComma(String str) {
		return str == null ? str : str.replaceAll(",", "").trim();
	}

	public static String getStringByBytes(String s, int start, int len) {
		byte[] theByteArray = s.getBytes();
		String rntStr = "";

		if (!"".equals(s) && s != null && theByteArray.length > len)
			rntStr = new String(s.getBytes(), start, len);
		else
			return s;

		return rntStr;
	}

	public static String encodeString(String str) {
		return Base64.encodeBase64String(str.getBytes());
	}

	/**
	 * Decode a string using Base64 encoding.
	 *
	 * @param str
	 * @return String
	 */
	public static String decodeString(String str) {
//		sun.misc.BASE64Decoder dec = new sun.misc.BASE64Decoder();
		try {
			String s = new String(Base64.decodeBase64(str));
//			String s1 = new String(dec.decodeBuffer(str));
//			System.out.println("s0" + s + "aaaa");
			return s;
		} catch (Exception io) {
			throw new RuntimeException(io.getMessage(), io.getCause());
		}
	}

	// 根據Unicode編碼完美的判斷中文漢字和符號
	public static boolean isChinese(char c) {
		Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
		if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
				|| ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
				|| ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
				|| ub == Character.UnicodeBlock.GENERAL_PUNCTUATION) {
			return true;
		}
		return false;
	}

//	public static void main(String[] args) {
//		System.out.println(decodeString(encodeString("123fgvaqgvaq3rerv%$##")));
//	}

}

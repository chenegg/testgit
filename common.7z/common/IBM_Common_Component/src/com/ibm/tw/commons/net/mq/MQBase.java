/*
 * ===========================================================================
 * IBM Confidential AIS Source Materials
 * 
 * MQ Base Class
 * 
 * (C) Copyright IBM Corp. 2005.
 * 
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;

/**
 * MQ Base Class
 * 
 * @author jeff
 * @author jeff, 2006/02/09
 * @version 1.0, 2005/8/29
 * @see com.ibm.tw.commons.net.mq.MQBase
 * @since
 */
public class MQBase {
	public final static int MQ_BROWSE = 5;

	public final static int MQ_CLEAR = 4;

	public final static int MQ_INQUIRE = 3;

	public final static int MQ_READ = 1;

	public final static int MQ_WRITE = 2;

	// open queue for write in cluster env.
	public final static int MQ_CLWRITE = 6;

	public final static int MQ_CLREAD = 8;

	// change queue attribute
	public final static int MQ_SET = 7;

	/** the reason code for mq read timeout */
	public final static int MQ_READ_TIMEOUT = 2033;

	public final static int MQ_CONNECT_BROKEN = 2009;

	// common logger
	protected static Log m_logger = LogFactory.getLog(MQBase.class);

	// private boolean m_bShared = false;
	protected MQQueue m_queue = null;

	protected MQQueueManager m_queueManager = null;

	/** the MQ environment */
	protected CMQEnvironment m_env = null;

	/** the connection option */
	protected int m_iOptionMode = 0;

	protected boolean m_bIsConnected = false;

	/**
	 * turn off MQ log message
	 * 
	 */
	public MQBase() {
		MQException.log = null;

		m_env = new CMQEnvironment();
	}

	/**
	 * using client mode to connect MQ
	 * 
	 * @param java.lang.String sIP: ip address of the queue manager
	 * @param int              iPort: the mq listner port (such like 1414)
	 * @param java.lang.String sChannel: server channel name
	 * 
	 */
	public void setMQEnvironment(String sIP, int iPort, String sChannel) {

		m_env.setIP(sIP);
		m_env.setPort(iPort);
		m_env.setServerChannel(sChannel);
		m_env.setMode(IMQEnvironment.CLIENT_MODE);
	}

	/**
	 * connect to mq
	 * 
	 * @param java.lang.String sQueueManager: queue manager name
	 * @param java.lang.String sQueueName: queue name
	 * @param int              iMode: operation mode (MQ_READ | MQ_WRITE | MQ_CLEAR
	 *                         | MQ_BROWSE)
	 * @exception com.ibm.mq.MQException
	 * 
	 */
	protected void connect(String sQueueManagerName, String sQueueName, int iOptionMode) throws MQException {
		m_bIsConnected = false;

		m_env.setQueueManager(sQueueManagerName);
		m_env.setQueue(sQueueName);

		m_iOptionMode = iOptionMode;

		if (isClientMode()) {
			connectByClientMode();
		} else {
			connectByServerMode();
		}

		m_bIsConnected = true;
	}

	/**
	 * connect to MQ by server mode
	 * 
	 * @throws MQException
	 */
	protected void connectByServerMode() throws MQException {
		m_queueManager = new MQQueueManager(m_env.getQueueManager());
		int iOpenOptions = getOpenOptions(m_iOptionMode);
		m_queue = m_queueManager.accessQueue(m_env.getQueue(), iOpenOptions, null, null, null);

	}

	/**
	 * <p>
	 * connect to MQ by client mode
	 * </p>
	 * 
	 * @return
	 * @throws MQException
	 */
	protected void connectByClientMode() throws MQException {

		m_queueManager = new MQQueueManager(m_env.getQueueManager(), m_env.getMQProperty());

		int iOpenOptions = getOpenOptions(m_iOptionMode);
		m_queue = m_queueManager.accessQueue(m_env.getQueue(), iOpenOptions, null, null, null);

	}

	/**
	 * MQ連線是否為Client Mode(設定IP, Port and Server Channel)
	 * 
	 * @return
	 */
	public boolean isClientMode() {
		return m_env.isClientMode();
	}

	/**
	 * clear queue
	 */
	public void clearQueue() {
		try {
			int iDepth = getQueueDepth();
			for (int i = 0; i < iDepth; i++) {
				MQMessage message = new MQMessage();
				m_queue.get(message);
			}
		} catch (MQException e) {
			getLogger().error(e);
		}
	}

	/**
	 * close queue and disconnect queue manager
	 * 
	 */
	public void close() {
		try {
			if (m_queue != null) {
				m_queue.close();

			}

			if (m_queueManager != null) {
				m_queueManager.disconnect();
			}
		} catch (MQException e) {
			getLogger().error(e);
		} finally {
			m_bIsConnected = false;
			m_queue = null;
			m_queueManager = null;
		}
	}

	/**
	 * get open queue option
	 * 
	 * @param int iMode: MQ_READ | MQ_WRITE | MQ_CLEAR | MQ_BROWSE
	 * @return int: MQ options
	 * 
	 */
	protected int getOpenOptions(int iMode) {
		int iOpenOptions;
		switch (iMode) {
		case MQ_READ:
			iOpenOptions = MQConstants.MQOO_FAIL_IF_QUIESCING | MQConstants.MQOO_INPUT_AS_Q_DEF;
			break;
		case MQ_WRITE:

			iOpenOptions = MQConstants.MQOO_FAIL_IF_QUIESCING | MQConstants.MQOO_OUTPUT
					| MQConstants.MQOO_BIND_NOT_FIXED;
			break;
		case MQ_INQUIRE:
			iOpenOptions = MQConstants.MQOO_INQUIRE;
			break;
		case MQ_CLEAR:
			iOpenOptions = MQConstants.MQOO_INQUIRE | MQConstants.MQOO_INPUT_SHARED;
			break;
		case MQ_BROWSE:
			iOpenOptions = MQConstants.MQOO_BROWSE | MQConstants.MQOO_INPUT_SHARED;
			break;
		case MQ_CLWRITE:
			iOpenOptions = MQConstants.MQOO_FAIL_IF_QUIESCING | MQC.MQOO_OUTPUT | MQC.MQOO_INQUIRE;
			break;
		case MQ_CLREAD:
			iOpenOptions = MQConstants.MQOO_FAIL_IF_QUIESCING | MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_INQUIRE;
			break;

		case MQ_SET:
			iOpenOptions = MQConstants.MQOO_SET;
			break;

		default:
			iOpenOptions = MQConstants.MQOO_FAIL_IF_QUIESCING | MQConstants.MQOO_INPUT_SHARED;
			break;
		}
		return iOpenOptions;
	}

	/**
	 * 取得 Queue
	 * 
	 * @return
	 */
	public MQQueue getQueue() {
		return m_queue;
	}

	/**
	 * get queue depth
	 * 
	 * @return queue depth
	 * 
	 */
	public int getQueueDepth() {
		int iDepth = 0;
		try {
			iDepth = m_queue.getCurrentDepth();
		} catch (MQException e) {
			iDepth = 0;
			getLogger().error(e);
		}
		return iDepth;
	}

	/**
	 * get queue manager
	 * 
	 */
	public MQQueueManager getQueueManager() {
		return m_queueManager;
	}

	/**
	 * 取得MQEnvironment
	 * 
	 * @return
	 */
	public CMQEnvironment getMQEnvironment() {
		return m_env;
	}

	/**
	 * is connected to MQ
	 * 
	 * @return
	 */
	public boolean isConnected() {
		return m_bIsConnected;
	}

	/**
	 * get the queue manager name
	 * 
	 * @return
	 */
	public String getQueueManagerName() {
		return m_env.getQueueManager();
	}

	/**
	 * set the queue manager name
	 * 
	 * @param sQueueManagerName
	 */
	public void setQueueManagerName(String sQueueManagerName) {
		m_env.setQueueManager(sQueueManagerName);
	}

	/**
	 * get the queue name
	 * 
	 * @return
	 */
	public String getQueueName() {
		return m_env.getQueue();
	}

	/**
	 * set the queue name
	 * 
	 * @param sQueueName
	 */
	public void setQueueName(String sQueueName) {
		m_env.setQueue(sQueueName);
	}

	/**
	 * 取得 Log
	 * 
	 * @return
	 */
	protected Log getLogger() {
		return m_logger;
	}

	/**
	 * get exception for connection broken
	 * 
	 * @return
	 */
	protected MQException getConnectionBrokenException() {

		MQException ex = new MQException(MQException.MQCC_FAILED, MQException.MQRC_CONNECTION_BROKEN, null);

		return ex;
	}

	/**
	 * 檢查是否為MQ連線中斷之錯誤
	 * 
	 * @param e
	 * @return
	 */
	public boolean isConnectBroken(MQException e) {

		return (MQ_CONNECT_BROKEN == e.reasonCode);
	}

	/**
	 * 檢查exception是否為read time out MQ Reason Code == 2033
	 * 
	 */
	public boolean isReadTimeOut(MQException e) {

		return (MQ_READ_TIMEOUT == e.reasonCode);
	}

}
package com.ibm.tw.commons.util;

import java.math.BigDecimal;

/**
 * 數字處理工具集
 * <p>
 * 數字工具集主要功能繼承自{@link org.apache.commons.lang.math.NumberUtils}，
 * 並增加下列功能：
 * <ul>
 * 	<li>BigDecimal處理功能</li>
 * </ul>
 * </p>
 * 
 * @author  Jeff Liu
 * @version 1.0, 2004/10/18
 * @see {@link org.apache.commons.lang.math.NumberUtils}	    
 * @since 
 */
public class NumericUtils extends org.apache.commons.lang.math.NumberUtils {

	public static void main(String[] args) {
		BigDecimal num = new BigDecimal(12.250);

		System.out.println("number = " + NumericUtils.setScale(num, 1));
	}

	/**
	 * 根據有效位數轉換BigDecimal，採用四捨五入
	 * <pre>
	 * setScale(BigDecimal(12.24, 1)) = BigDecimal(12.2)
	 * setScale(BigDecimal(12.25, 1)) = BigDecimal(12.3)
	 * </pre>
	 * 
	 * @param sAmount
	 * @param iScale
	 * @return
	 */
	public static BigDecimal setScale(BigDecimal value, int iScale) {
		if ((null == value) || (iScale < 0)) {
			return null;
		}

		BigDecimal amount = value.setScale(iScale, BigDecimal.ROUND_HALF_UP);

		return amount;

	}

	public static boolean isInteger(String val) {
		String objVal = val.trim();
		if (objVal == null || objVal.length() == 0)
			return false;
		String decimalFormat = ".";
		int checkChar = objVal.indexOf(decimalFormat);
		if (checkChar < 1)
			return checkNumber(objVal);
		else
			return false;
	}

	public static boolean checkNumber(String val) {
		String objVal = val.trim();
		if (objVal == null || objVal.length() == 0)
			return false;
		String startFormat = " .+-0123456789";
		String numberFormat = " .0123456789 ";
		boolean isDecimal = false;
		boolean trailingBlank = false;
		boolean digits = false;
		int checkChar = startFormat.indexOf(objVal.charAt(0));
		if (checkChar == 1)
			isDecimal = true;
		else if (checkChar < 1)
			return false;
		for (int i = 1; i < objVal.length(); i++) {
			checkChar = numberFormat.indexOf(objVal.charAt(i));
			if (checkChar <= 0)
				return false;
			if (checkChar == 1) {
				if (isDecimal)
					return false;
				isDecimal = true;
				continue;
			}
			if (checkChar == 0) {
				if (isDecimal || digits)
					trailingBlank = true;
				continue;
			}
			if (trailingBlank)
				return false;
			digits = true;
		}

		return true;
	}

}

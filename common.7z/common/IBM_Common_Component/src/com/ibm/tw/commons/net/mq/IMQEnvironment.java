/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */ 
package com.ibm.tw.commons.net.mq;

/**
 * <p>MQ Environment Interface</p>
 *
 * @author  jeff
 * @version 1.0, Mar 16, 2009
 * @see	    
 * @since 
 */
public interface IMQEnvironment {
    
    public final static String SERVER_MODE = "server";
    public final static String CLIENT_MODE = "client";

    public String getMode();
    public String getIP();
    public int getPort();
    public String getServerChannel();
    public String getQueueManager();
    public String getQueue();
    
    // ms
    public int getWaitInterval();
}

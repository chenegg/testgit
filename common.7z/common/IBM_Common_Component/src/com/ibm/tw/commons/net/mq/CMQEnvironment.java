/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import java.util.Hashtable;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
 

/**
 * <p>MQ Environment</p>
 *
 * @author  jeff
 * @version 1.0, Mar 16, 2009
 * @see	    
 * @since 
 */ 
public class CMQEnvironment implements IMQEnvironment {
    
    // ms
    public final static int DEFAULT_WAIT_INTERVAL = 3000;
    
    // server or client
    protected String m_sMode = IMQEnvironment.SERVER_MODE;
    
    //------------ ip, port, server channel are used for client mode ---------
    
    // the ip address of the MQ Server
    protected String m_sIP = "";
    
    // the port of MQ Listner
    protected int m_iPort = 0;
    
    // the server channel
    protected String m_sServerChannel = "";
    
    // the queue manager name
    protected String m_sQueueManagerName = "";
    
    // the queue name
    protected String m_sQueueName = "";
    
    // for receiver
    protected int m_iWaitInterval = DEFAULT_WAIT_INTERVAL;
    
    public CMQEnvironment() {
        
    }
    
    /**
     * 
     * @param env
     */
    public CMQEnvironment(IMQEnvironment env) {
        m_sMode = env.getMode();
        m_sIP = env.getIP();
        m_iPort = env.getPort();
        m_sServerChannel = env.getServerChannel();
        m_sQueueManagerName = env.getQueueManager();
        m_sQueueName = env.getQueue();
        m_iWaitInterval = env.getWaitInterval();
    }
    
    /**
	 * 建立 MQEnvironment 參數
	 * @return
	 * @throws MQException
	 * create 2008/03/10
	 */
	public Hashtable getMQProperty() throws MQException {
		
		
		
		Hashtable<String, Object> mqProperty = new Hashtable<String, Object>();
		
		mqProperty.put(MQC.HOST_NAME_PROPERTY, getIP());
		mqProperty.put(MQC.PORT_PROPERTY, new Integer(getPort()));
		mqProperty.put(MQC.CHANNEL_PROPERTY, getServerChannel());	
		mqProperty.put(MQC.CCSID_PROPERTY, new Integer(1208));
		//mqProperty.put(MQC.USER_ID_PROPERTY, m_userid);
		//mqProperty.put(MQC.PASSWORD_PROPERTY, m_password);
		
		return mqProperty;
	}    
    /**
     * 
     * @param sMode	client or server
     */
    public void setMode(String sMode) {
        m_sMode = sMode;
    }
    
    public String getMode() {
        return m_sMode;
    }
    
    public void setIP(String sIP) {
        m_sIP = sIP;
    }
    
    public String getIP() {
        return m_sIP;
    }
    
    public void setPort(int iPort) {
        m_iPort = iPort;
    }
    
    public int getPort() {
        return m_iPort;
    }
    
    public void setServerChannel(String sServerChannel) {
        m_sServerChannel = sServerChannel;
    }
    
    public String getServerChannel() {
        return m_sServerChannel;
    }
    
    public void setQueueManager(String sQueueManager) {
        m_sQueueManagerName = sQueueManager;
    }
    
    public String getQueueManager() {
        return m_sQueueManagerName;
    }
    
    public void setQueue(String sQueue) {
        m_sQueueName = sQueue;
    }
    
    public String getQueue() {
        return m_sQueueName;
    }

    
    public void setWaitInterval(int iWaitInterval) {
        m_iWaitInterval = iWaitInterval;
    }
    
    /**
     * @see com.ibm.tw.commons.net.mq.IMQEnvironment#getWaitInterval()
     */
    public int getWaitInterval() {
         
        return m_iWaitInterval;
    }

    public boolean isClientMode() {
        return m_sMode.equalsIgnoreCase(IMQEnvironment.CLIENT_MODE);
    }
    
    
}

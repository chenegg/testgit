/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2008.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import java.io.IOException;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;


/**
 * <p>MQ String Message</p>
 *
 * @author  jeff
 * @version 1.0, Nov 12, 2008
 * @see	    
 * @since 
 */
public class CMQStrMessage extends CMQMessage {
	
	public CMQStrMessage() {
		super();
		
		setFormat(MQC.MQFMT_STRING);
	}
	
	public CMQStrMessage(MQMessage mqMessage) {
		 
		
		decode(mqMessage);
	}
	
	
	/**
	 * MQMessage -> CMQStrMessage
	 * 
	 * 
	 */
	protected void decode(MQMessage mqMessage) {
		try {
						
			// MQMD
			m_mqmd = new CMQMD(mqMessage);
			
			// Data
			int iMsgLen = mqMessage.getMessageLength();

			m_messageData = new byte[iMsgLen];
 
			mqMessage.readFully(m_messageData);
		}
		catch (IOException e) {
			m_messageData = null;
			getLogger().error(e);
		}
	}

 
	 
	/**
	 * CMQStrMessage -> MQMessage
	 * @throws MQException 
	 */
	public MQMessage toMQMessage() throws MQException  {
		MQMessage mqMessage = new MQMessage();
		try {
			// MQMD
			m_mqmd.encode(mqMessage);
			
			// Message Data
			mqMessage.write(m_messageData);
		}
		catch(IOException e) {
			m_logger.error(e);
		}
	 
		
		return mqMessage;
		
	}
	
	/**
	 * set message data
	 * 
	 * @param messageData
	 */
	public void setMessage(byte[] messageData) {
		m_messageData = messageData;
	}
}



 
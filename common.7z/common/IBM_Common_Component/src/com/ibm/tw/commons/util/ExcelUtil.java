package com.ibm.tw.commons.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellUtil;

public class ExcelUtil {
	// Field descriptor #4 S
	public static final short ALIGN_LEFT = 1;

	// Field descriptor #4 S
	public static final short ALIGN_CENTER = 2;

	/**
	 * get excel byte
	 * 
	 * @param sheetName
	 * @param headers
	 * @param datas
	 * @return
	 */
	public byte[] toExcel(String sheetName, ExcelHeader beforeHeaders, ExcelHeader headers, ExcelContent datas)
			throws Exception {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFCellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		headerCellStyle.setFillForegroundColor(new HSSFColor.GREY_25_PERCENT().getIndex());
		HSSFSheet sheet = workbook.createSheet(sheetName);

		int rowIndex = 0;
		HSSFRow row = null;

		/* create some data before header */
		if (beforeHeaders != null) {
			for (int i = 0; i < beforeHeaders.getSize(); i++) {
				row = sheet.createRow(rowIndex++);
				HSSFCell cell = row.createCell(0);
				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				cell.setCellValue(beforeHeaders.getHeaderValue(i));
				CellUtil.setAlignment(cell, workbook, ALIGN_LEFT);
			}
		}

		/* Create Excel Header - 嚙踝蕭嚙踝蕭嚙瘩嚙踝蕭 */
		if (headers != null) {
			row = sheet.createRow(rowIndex++);
			for (int i = 0; i < headers.getSize(); i++) {
				HSSFCell cell = row.createCell(i);
				cell.setCellValue(html2Excel(headers.getHeaderValue(i)));
				cell.setCellStyle(headerCellStyle);
				CellUtil.setAlignment(cell, workbook, ALIGN_CENTER);
			}
		}

		/* Create Excel Data */
		for (int r = 0; r < datas.getSize(); r++) {
			row = sheet.createRow(rowIndex++);
			ArrayList<String> record = datas.getRecord(r);
			if (record.size() > 0) {
				int columnSize = record.size()/* 嚙踝蕭嚙踝蕭嚙� */;
				for (int c = 0, offsetColumn = 0; c < columnSize; c++, offsetColumn++) {

					HSSFCell cell = row.createCell(offsetColumn);
					String value = record.get(c);
					cell.setCellType(HSSFCell.CELL_TYPE_STRING);
					cell.setCellValue(value);
					CellUtil.setAlignment(cell, workbook, ALIGN_CENTER); // 嚙練嚙踝蕭

				}
			}
		}

		adjustColumn(workbook, sheet);
		// get byte data from workbook
		return getWorkbookBytes(workbook);
	}

	private void adjustColumn(HSSFWorkbook workbook, HSSFSheet sheet) {
		// auto size all column
		HSSFRow row = sheet.getRow(0);
		if (row != null) {
			for (int x = 0; x < sheet.getRow(0).getPhysicalNumberOfCells(); x++) {
				// cannot autosize correctly, maybe font problem, see
				// http://stackoverflow.com/questions/16943493/apache-poi-autosizecolumn-resizes-incorrectly
				sheet.autoSizeColumn(x); // or use setColumnWidth will work

				sheet.setColumnWidth(x, sheet.getColumnWidth(x) + 500); // 嚙踝蕭嚙踝蕭嚙踝蕭嚙箴嚙論好嚙豎一嚙瘢嚙璀嚙踝蕭嚙踝蕭嚙誶是嚙緯嚙踝蕭autosize
			}
		}
	}

	private String html2Excel(String value) {
		value = StringUtils.trimToEmpty(value);
		value = value.replaceAll("<br/>", "\r\n");
		return value;
	}

	/**
	 * 嚙踝蕭o HSSFWorkbook 嚙踝蕭嚙賬的 byte data (嚙踝蕭嚙諸恬蕭嚙踝蕭i嚙踝蕭U嚙踝蕭)
	 * 
	 * Ref: http://goo.gl/T6mK5v
	 * 
	 * @param workbook
	 * @return
	 */
	public byte[] getWorkbookBytes(HSSFWorkbook workbook) throws Exception {

		byte[] data = null;

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			workbook.write(bos);
			data = bos.toByteArray();
		} finally {
			try {
				bos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return data;
	}

	/**
	 * bytes to file
	 * 
	 * @param btyes
	 * @param path
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public File createExcelFile(byte[] btyes, String path, String fileName) throws Exception {
		File file = null;
		file = new File(path, fileName);
		createExcelFile(btyes, file);
		return file;
	}

	public File createExcelFile(byte[] btyes, File file) throws Exception {
		BufferedOutputStream bufferedOutput = null;
		try {
			OutputStream output = new FileOutputStream(file);
			bufferedOutput = new BufferedOutputStream(output);
			bufferedOutput.write(btyes);

			bufferedOutput.close();
			bufferedOutput = null;
		} finally {
			if (bufferedOutput != null) {
				try {
					bufferedOutput.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return file;
	}
}

package com.ibm.tw.commons.util;

/**
 * 
 * @author Egg.chen
 * 
 */
public interface EnumBase {

	public static final String UNKNOWN = "UNKNOWN";

	public static final int UNKNOWN_INT = -99;

	public static final String UNKNOWN_STR = "-99";

}

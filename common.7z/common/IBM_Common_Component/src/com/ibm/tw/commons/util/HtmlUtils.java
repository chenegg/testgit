package com.ibm.tw.commons.util;

import org.apache.commons.lang3.StringUtils;

/**
*
* @author chenegg
*/
public class HtmlUtils {

	private static final String HTML_SPACE = "&nbsp;";

	private HtmlUtils() {
	}

	/**
	* �Nhtml����<br/>�ন\r\n
	*
	* @param str
	* @return
	*/
	public static String br2nl(String str) {
		if (StringUtils.isBlank(str)) {
			return str;
		}
		// todo���g�o��,����b�[
		return str.replaceAll(HTML_SPACE, " ").replaceAll("<br[/s]*/>", "\r\n");
		// return str.replaceAll("<br[/s]*/?>", "\r\n");
	}

	/**
	* �L�ohtml tag,�Ȩ��Xtext
	*
	* @param str
	* @return
	*/
	public static String extractText(String str) {
		if (StringUtils.isBlank(str)) {
			return "";
		}
		return str.replaceAll("\\<.*?>", "");
	}

	public static String rightSpacePad(String str, int size) {
		return StringUtils.rightPad(StringUtils.defaultString(str), size, " ").replaceAll(" ", HTML_SPACE);
	}
}

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;

/**
 * MQ 接收物件
 * 
 * @author jeff
 * @version 1.0, 2005/11/28
 * @see
 * @since
 * 
 */
public class MQReceiver extends MQBase {

	/**
	 * 
	 */
	public MQReceiver() {

	}

	/**
	 * 連接MQ Server
	 * 
	 * @param sQueueManagerName
	 * @param sQueueName
	 * @throws MQException
	 */
	public void connect(String sQueueManagerName, String sQueueName) throws MQException {
		connect(sQueueManagerName, sQueueName, MQBase.MQ_READ);
	}

	/**
	 * get mq message by message id
	 * 
	 * 過濾 2033 no message 的exception
	 * 
	 * @param msgId
	 * @param iWaitInterval
	 * @param message
	 * @throws MQException
	 */
	public CMQMessage receive(byte[] msgId, int iWaitInterval) throws MQException {

		MQMessage mqMessage = new MQMessage();
		// get message by message id
		// TODO: 是否使用array copy
		if (msgId != null) {

			mqMessage.messageId = msgId;
		}

		return receiveByMessage(mqMessage, iWaitInterval);
	}

	/**
	 * get mq message by message id
	 * 
	 * 過濾 2033 no message 的exception
	 * 
	 * @param msgId
	 * @param iWaitInterval
	 * @param message
	 * @throws MQException
	 */
	protected CMQMessage receiveByMessage(MQMessage mqMessage, int iWaitInterval) throws MQException {

		if (!isConnected()) {
			throw getConnectionBrokenException();
		}

		CMQMessage message = null;

		try {

			MQGetMessageOptions oGMO = new MQGetMessageOptions();
			// wait to read message from queue
			oGMO.options = MQC.MQGMO_WAIT;

			if (iWaitInterval > 0) {
				oGMO.waitInterval = iWaitInterval;
			}
			// unlimited
			else {
				oGMO.waitInterval = MQC.MQWI_UNLIMITED;
			}
			m_queue.get(mqMessage, oGMO);

			// RFH2 Message
			if (mqMessage.format.equals(MQC.MQFMT_RF_HEADER_2)) {

				message = new CMQRfh2Message(mqMessage);
			} else {
				message = new CMQStrMessage(mqMessage);

			}

		} catch (MQException e) {
			message = null;
			if (!isReadTimeOut(e)) {
				close();
				throw e;
			}
		}

		return message;
	}

	/**
	 * get mq message by correlation id
	 * 
	 * @param correlationID
	 * @param iWaitInterval
	 * @return
	 * @throws MQException
	 */
	public CMQMessage receiveByCorrelationID(byte[] correlationId, int iWaitInterval) throws MQException {

		MQMessage mqMessage = new MQMessage();

		// get message by message id
		if (correlationId != null) {
			mqMessage.correlationId = correlationId;
		}
		return receiveByMessage(mqMessage, iWaitInterval);
	}

}
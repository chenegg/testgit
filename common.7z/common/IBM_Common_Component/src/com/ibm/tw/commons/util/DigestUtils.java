/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.ibm.tw.commons.exception.CryptException;

/**
 * 資料簽章工具<BR>
 * 支援下列演算法: <li>MD5</li> <li>SHA-1</li>
 * 
 * @author Kevin
 * @version 1.0, 2007/7/5
 * @see
 * @since
 * 
 */
public class DigestUtils {

	/**
	 * 將資料透過MD5雜湊加密
	 * 
	 * @param content
	 * @return
	 */
	public static String md5Hex(byte[] content) throws CryptException {
		MessageDigest md5;
		String digest = "";
		try {
			md5 = MessageDigest.getInstance("MD5");
			digest = bytesToHex(md5.digest(content));
		}
		catch (NoSuchAlgorithmException e) {
			throw new CryptException("cannot md5, data = " + ConvertUtils.byteArray2HexString(content), e);
		}
		return digest;
	}

	/**
	 * 將資料透過SHA雜湊加密
	 * 
	 * @param content
	 * @return
	 */
	public static String shaHex(byte[] content) throws CryptException {
		MessageDigest sha;
		String digest = "";
		try {
			sha = MessageDigest.getInstance("SHA");
			digest = bytesToHex(sha.digest(content));
		}
		catch (NoSuchAlgorithmException e) {
			throw new CryptException("cannot sha, data = " + ConvertUtils.byteArray2HexString(content), e);
		}
		return digest;
	}

	/**
	 * 將byte array轉成Hex的字串
	 * 
	 * @param b
	 * @return
	 */
	private static String bytesToHex(byte[] b) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < b.length; ++i) {
			sb.append((Integer.toHexString((b[i] & 0xFF) | 0x100)).substring(1, 3));
		}
		return sb.toString();
	}
}

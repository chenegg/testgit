/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * Default Cache
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.cache;

import java.util.HashMap;


/**
 * @author  Kevin
 * @version 1.0, 2006/1/23
 * @see	    
 * @since 
 */
public class Cache implements ICache {
    
    protected Lock m_lock = null;
    protected HashMap<Object, Object> m_values = null;
    
     
    public Cache() {
        m_lock = new Lock();
        m_values = new HashMap<Object, Object>();
    }

    /**
     * @see com.ibm.test.cache.ICache#retrieve(java.lang.Object)
     */
    public Object retrieve(Object key) {
        Object value = null;
        m_lock.readLock();
        
        try {
            value = m_values.get(key);
            
            
        }
        finally {
            m_lock.readUnLock();
        }
        
        return value;
        

    }

    /**
     * @see com.ibm.test.cache.ICache#store(java.lang.Object, java.lang.Object)
     */
    public void store(Object key, Object value) {
        m_lock.writeLock();
        try {
            m_values.put(key, value);
        }
        finally {
            m_lock.writeUnLock();
        }
        
        
    }

    /**
     * @see com.ibm.test.cache.ICache#remove(java.lang.Object)
     */
    public Object remove(Object key) {
        Object value = null;
        m_lock.writeLock();
        try {
            value = m_values.remove(key);
        }
        finally {
            m_lock.writeUnLock();
        }
        
        return value;
    }

    /**
     * @see com.ibm.test.cache.ICache#clear()
     */
    public void clear() {
        m_lock.writeLock();
        
        try {
            m_values.clear();
        }
        finally {
            m_lock.writeUnLock();
        }
        
    }

    /**
     * TODO: lock or not
     * 
     * @see com.ibm.test.cache.ICache#size()
     */
    public int size() {
         return m_values.size();
    }

    
    
}

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */  
package com.ibm.tw.commons.util;

 

/**
 * Class載入異常物件
 * 
 * @author  Jeff Liu
 * @version 1.0, 2004/10/18
 * @see 
 * @since 
 */ 
@SuppressWarnings("serial")
public class ClassLoaderException extends Exception {
 
  
    public ClassLoaderException() {
    		
    	super();
    }
    
    public ClassLoaderException(String sMsg) {
    	
    	super(sMsg);
    }
    
    
    
    public ClassLoaderException(String sMsg, Throwable cause) {
    	
    	super(sMsg, cause);
		 
    }
 

  
  
 
}

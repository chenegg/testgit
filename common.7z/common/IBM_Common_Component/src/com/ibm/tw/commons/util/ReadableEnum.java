package com.ibm.tw.commons.util;

import java.util.Locale;

/**
 * 
 * @author Egg.chen
 * 
 */
public interface ReadableEnum extends EnumBase {

	public String getDisplayName();

	public String getDisplayByLocale(Locale locale);

}

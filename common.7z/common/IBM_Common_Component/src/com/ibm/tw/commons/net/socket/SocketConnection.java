/*
 * ===========================================================================
 * IBM Confidential AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 * 
 * ===========================================================================
 */
package com.ibm.tw.commons.net.socket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Socket Client Connection
 * 
 * @author Kevin
 * @version 1.0, 2008/1/31
 * @see
 * @since
 */
public class SocketConnection {
	/** Log */
	// protected static Log m_logger =
	// LogFactory.getLog(SocketConnection.class);
	private static Logger m_logger = LoggerFactory.getLogger(SocketConnection.class);
	/** 預設接收資料等候之時間(單位:ms) */
	public final static int WAIT_INTERVAL = 30000;

	/** IP */
	private String m_sIP;

	/** Port */
	private int m_iPort;

	/** Socket */
	private Socket m_socket;

	/** InputStream */
	private BufferedInputStream m_in = null;

	/** OutputStream */
	private BufferedOutputStream m_out = null;

	/**
	 * @param sIP
	 * @param iPort
	 */
	public SocketConnection(String sIP, int iPort) {
		m_sIP = sIP;
		m_iPort = iPort;
	}

	/**
	 * 連線
	 * 
	 * @return
	 */
	public boolean connectEx() {
		boolean bResult = false;
		try {
			m_socket = new Socket(m_sIP, m_iPort);
			m_in = new BufferedInputStream(m_socket.getInputStream(), m_socket.getReceiveBufferSize());
			m_out = new BufferedOutputStream(m_socket.getOutputStream(), m_socket.getSendBufferSize());
			m_logger.info("Socket connection success ");
			bResult = true;
		} catch (UnknownHostException e) {
			m_logger.error(e.getMessage(), e);
			m_socket = null;
		} catch (IOException e) {
			m_logger.error(e.getMessage(), e);
			m_socket = null;
		}
		return bResult;
	}

	/**
	 * 傳送資料
	 * 
	 * @param m_message
	 * @throws SocketException
	 * @throws IOException
	 */
	public void sendEx(byte[] m_message) throws SocketException, IOException {
		m_logger.info("Socket send [" + new String(m_message) + "]");
		m_out.write(m_message);
		m_out.flush();
	}

	/**
	 * 傳送資料
	 * 
	 * @return
	 * @throws IOException
	 */
	public byte[] receiveEx() throws IOException {
		return receiveEx(WAIT_INTERVAL);
	}

	/**
	 * 收取資料
	 * 
	 * @param iWaitInterval
	 * @return
	 * @throws IOException
	 */
	public byte[] receiveEx(int iWaitInterval) throws IOException {
		// m_socket.setSoTimeout(iWaitInterval);
		byte[] data = new byte[4096];
		int iLen = m_in.read(data);
		m_logger.info("receive data length:" + iLen);
		iLen = iLen < 0 ? 0 : iLen;
		byte[] bDa = new byte[iLen];
		m_logger.info("Socket receive [" + new String(bDa) + "]");
		System.arraycopy(data, 0, bDa, 0, iLen);
		return bDa;
	}

	/**
	 * 關閉 Socket 連線
	 */
	public void close() {
		try {
			m_in.close();
		} catch (Exception e) {
			m_logger.error(e.getMessage(), e);
		}
		try {
			m_out.close();
		} catch (Exception e) {
			m_logger.error(e.getMessage(), e);
		}
		try {
			m_socket.close();
		} catch (Exception e) {
			m_logger.error(e.getMessage(), e);
		}
	}

	public static void main(String[] args) {

		SocketConnection connect = new SocketConnection("10.200.48.42", 7090);
		System.out.println("connect success:" + connect.connectEx());

		try {

			while (true) {
				byte[] btData = connect.receiveEx(350000);

				System.out.println(btData);

				if (btData.length > 10) {
					connect.sendEx(btData);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		connect.close();
	}

}

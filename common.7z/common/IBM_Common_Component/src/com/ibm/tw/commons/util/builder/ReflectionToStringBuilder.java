package com.ibm.tw.commons.util.builder;

import java.lang.reflect.Field;

import org.apache.commons.lang3.builder.StandardToStringStyle;

public class ReflectionToStringBuilder {

	public static String toString(Object o) {
		if (o == null) {
			return "";
		}

		StandardToStringStyle style = new StandardToStringStyle();
		style.setFieldSeparator(", ");
		style.setUseClassName(false);
		style.setUseIdentityHashCode(false);

		org.apache.commons.lang3.builder.ReflectionToStringBuilder builder = new org.apache.commons.lang3.builder.ReflectionToStringBuilder(
				o, style) {
			@Override
			protected boolean accept(Field field) {
				if (field.isAnnotationPresent(KgiQueryString.class)) {
					return true;
				}
				return false;
			}
		};
		return builder.toString();
	}

	// @KgiQueryString
	// private String s;
	//
	// @KgiQueryString
	// private String b;
	//
	// public static void main(String[] args) {
	// ReflectionToStringBuilder a = new ReflectionToStringBuilder();
	// a.s = "gg";
	// a.b = "2222";
	// System.out.println("a=" + toString(a));
	// }
}

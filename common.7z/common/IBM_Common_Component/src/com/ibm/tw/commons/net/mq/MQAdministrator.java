/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.ibm.mq.constants.CMQC;
import com.ibm.mq.constants.MQConstants;
import com.ibm.mq.headers.MQDataException;
import com.ibm.mq.headers.pcf.PCFException;
import com.ibm.mq.headers.pcf.PCFMessage;
import com.ibm.mq.headers.pcf.PCFMessageAgent;



/**
 * <p> MQ Administrator </p>
 *
 * @author  Hank
 * @version 1.0, 2011/8/18
 * @see	    
 * @since 
 */
public class MQAdministrator {

	
	private PCFMessageAgent agent = null;
	
	
	/**
	 * 
	 * @throws MQDataException
	 */
	public void initAgent(String host, int port, String channel) throws MQDataException{
		
		try {
			
			agent = new PCFMessageAgent(host, port, channel);
		}
		catch (MQDataException mqde) {
			
			if (mqde.reasonCode == CMQC.MQRC_Q_MGR_NAME_ERROR) {
				System.out.print("Either could not find the ");
				System.out.print("default queue manager at \"" + host + "\", port \"" + port + "\"");
				System.out.println(" or could not find the default channel \"" + channel
		            + "\" on the queue manager.");
			}
		      throw mqde;
		}	
	}
	
	
	/**
	 * 
	 * @throws MQDataException
	 */
	public void destroyAgent() {
	    // Disconnect the agent.
		if (agent != null) {
			try {
				agent.disconnect();
			}
			catch (MQDataException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	/**
	 * 建立 Local Queue
	 * 
	 * @param queueName	Local Queue Name
	 * @param transmitQueue Boolean used to determine if the created queue should be a transmit queue.
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void createLocalQueue(String queueName, boolean transmitQueue) throws MQDataException, IOException {
		
		if (agent == null) {
			return;
		}
		
		int queueType = MQConstants.MQQT_LOCAL;


		// Create the PCF message type for the create queue.
		// NB: The parameters must be added in a specific order or an exception (3015)
		// will be thrown.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_CREATE_Q);

		// Queue name - Mandatory.
		pcfCmd.addParameter(MQConstants.MQCA_Q_NAME, queueName);

		// Queue Type - Optional.
		pcfCmd.addParameter(MQConstants.MQIA_Q_TYPE, queueType);
		
		

		if (transmitQueue) {
			// Queue Type - This must be the second parameter!
			pcfCmd.addParameter(MQConstants.MQIA_USAGE, MQConstants.MQUS_TRANSMISSION);
		}

		// Add description.
		pcfCmd.addParameter(MQConstants.MQCA_Q_DESC, "Queue created by PCF samples");

		try {
			// Execute the command. The returned object is an array of PCF messages.
			// If the Queue already exists, then catch the exception, otherwise rethrow.
			/* PCFMessage[] pcfResponse = */// We ignore the returned result
			agent.send(pcfCmd);
		}
		catch (PCFException pcfe) {
			if (pcfe.reasonCode == MQConstants.MQRCCF_OBJECT_ALREADY_EXISTS) {
				System.out.println("The queue \"" + queueName
						+ "\" already exists on the queue manager.");
			}
			else {
				throw pcfe;
			}
		}

	}
	
	
	/**
	 * 建立 Cluster Queue
	 * 
	 * @param queueName
	 * @param clusterName
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void createClusterQueue(String queueName, String clusterName) throws MQDataException, IOException {
		
		if (agent == null) {
			return;
		}
		
		int queueType = MQConstants.MQQT_LOCAL;


		// Create the PCF message type for the create queue.
		// NB: The parameters must be added in a specific order or an exception (3015)
		// will be thrown.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_CREATE_Q);

		// Queue name - Mandatory.
		pcfCmd.addParameter(MQConstants.MQCA_Q_NAME, queueName);

		// Queue Type - Optional.
		pcfCmd.addParameter(MQConstants.MQIA_Q_TYPE, queueType);
		
		pcfCmd.addParameter(MQConstants.MQCA_CLUSTER_NAME, clusterName);
		
		
		// Add description.
		pcfCmd.addParameter(MQConstants.MQCA_Q_DESC, "Queue created by PCF samples");

		try {
			// Execute the command. The returned object is an array of PCF messages.
			// If the Queue already exists, then catch the exception, otherwise rethrow.
			/* PCFMessage[] pcfResponse = */// We ignore the returned result
			agent.send(pcfCmd);
		}
		catch (PCFException pcfe) {
			if (pcfe.reasonCode == MQConstants.MQRCCF_OBJECT_ALREADY_EXISTS) {
				System.out.println("The queue \"" + queueName
						+ "\" already exists on the queue manager.");
			}
			else {
				throw pcfe;
			}
		}
		
	}
		
		
	
	/**
	 * 建立 Queue
	 * 
	 * @param queueName
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void deleteQueue(String queueName) throws PCFException, MQDataException, IOException {
		
		if (agent == null) {
			return;
		}
		
		// Create the PCF message type for the delete queue.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_DELETE_Q);

		// Queue name - This must be the first parameter!
		pcfCmd.addParameter(MQConstants.MQCA_Q_NAME, queueName);

		// Execute the command. The returned object is an array of PCF messages.
		/* PCFMessage[] pcfResponse = */// We ignore the returned result
		agent.send(pcfCmd);
	
	}
	
	
	/**
	 * 清除訊息
	 * 
	 * @param queueName
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void clearQueue(String queueName) throws PCFException, MQDataException, IOException {
	
		if (agent == null) {
			return;
		}

		
		// The sample has so far connected to the Queue and filled it with a random number of
		// random length messages. The sample has demonstrated that these messages are on the
		// Queue. Now clear the queue and then demonstrate that the queue is empty.
		// Clear the messages. Note that rather than create another PCFMessage, the existing
		// object can be reinitialised with another command.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_CLEAR_Q);

		
		// Add the inquire rules.
		pcfCmd.addParameter(MQConstants.MQCA_Q_NAME, queueName);

		// Execute the command. The returned object is an array of PCF messages.
		agent.send(pcfCmd);

	}
	
	
	/**
	 * 查詢佇列深度
	 * 
	 * @param queueName
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public int inquireQueueDepth(String queueName) throws PCFException, MQDataException, IOException {
		
		if (agent == null) {
			return -1;
		}
		
		// Now have several message on a Queue. Display Queue information.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_INQUIRE_Q);
		
		

		// Add the inquire rules.
		pcfCmd.addParameter(MQConstants.MQCA_Q_NAME, queueName);

		// Execute the command. The returned object is an array of PCF messages. There will
		// only be one set of queue status information, but this shows how it could be extended.
		PCFMessage[] pcfResponse = agent.send(pcfCmd);


		for (int index = 0; index < pcfResponse.length; index++) {
			PCFMessage response = pcfResponse[index];
			String queue = (String)response.getParameterValue(MQConstants.MQCA_Q_NAME);
			int depth = Integer.parseInt("" + response.getParameterValue(MQConstants.MQIA_CURRENT_Q_DEPTH));
			
			//MQConstants.MQIA_OPEN_INPUT_COUNT
			//MQConstants.MQIA_OPEN_OUTPUT_COUNT
			
			if (queue.trim().equalsIgnoreCase(queueName)) {
				return depth;
			}
		}

		return 0;	
	}
	
	
	/**
	 * 建立通道
	 * 
	 * @param channelName
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void createSvrconnChannel(String channelName, String userId) throws MQDataException, IOException {
		
		if (agent == null) {
			return;
		}
		
		// Create the PCF message type for the create channel.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_CREATE_CHANNEL);

		// Add the create channel mandatory parameters.
		// Channel name.
		pcfCmd.addParameter(MQConstants.MQCACH_CHANNEL_NAME, channelName);

		// Channel type.
		pcfCmd.addParameter(MQConstants.MQIACH_CHANNEL_TYPE, MQConstants.MQCHT_SVRCONN);
		
		pcfCmd.addParameter(MQConstants.MQCACH_MCA_USER_ID, userId);
		

		// Execute the command. If the command causes the 'MQRCCF_OBJECT_ALREADY_EXISTS' exception
		// to be thrown, catch it here as this is ok.
		// If successful, the returned object is an array of PCF messages.
		try {
			/* PCFMessage[] pcfResponse = */// We ignore the returned result
			agent.send(pcfCmd);
		}
		catch (PCFException pcfe) {
			if (pcfe.reasonCode != MQConstants.MQRCCF_OBJECT_ALREADY_EXISTS) {
				throw pcfe;
			}
		}

	}
	
	
	/**
	 * 刪除通道
	 * 
	 * @param channelName
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void deleteChannel(String channelName) throws PCFException, MQDataException, IOException {
		
		if (agent == null) {
			return;
		}
		
		// Create the PCF message type for the delete channel.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_DELETE_CHANNEL);

		// Add the delete channel mandatory parameters.
		// Channel name.
		pcfCmd.addParameter(MQConstants.MQCACH_CHANNEL_NAME, channelName);

		// Execute the command. The returned object is an array of PCF messages.
		/* PCFMessage[] pcfResponse = */// We ignore the returned result
		agent.send(pcfCmd);
		
	}
	
	
	/**
	 * 停止通道
	 * 
	 * @param channelName
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void stopChannel(String channelName) throws PCFException, MQDataException, IOException {
		
		if (agent == null) {
			return;
		}
		
		// Create the PCF message type for the stop channel.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_STOP_CHANNEL);

		// Add the stop channel mandatory parameters.
		// Channel name.
		pcfCmd.addParameter(MQConstants.MQCACH_CHANNEL_NAME, channelName);

		// Execute the command. The returned object is an array of PCF messages.
		/* PCFMessage[] pcfResponse = */// We ignore the returned result
		agent.send(pcfCmd);

	}
	
	
	/**
	 * 啟動通道
	 * 
	 * @param channelName
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void startChannel(String channelName) throws PCFException, MQDataException, IOException {
		
		if (agent == null) {
			return;
		}
		
		// Create the PCF message type for the start channel.
		PCFMessage pcfCmd = new PCFMessage(MQConstants.MQCMD_START_CHANNEL);

		// Add the start channel mandatory parameters.
		// Channel name.
		pcfCmd.addParameter(MQConstants.MQCACH_CHANNEL_NAME, channelName);

		// Execute the command. The returned object is an array of PCF messages.
		/* PCFMessage[] pcfResponse = */// We ignore the returned result
		agent.send(pcfCmd);

	}
	
	
	/**
	 * 取得應用程式連線資訊
	 * 
	 * @return
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public List<ClientConn> getClientConnectionsInfo() throws PCFException, MQDataException, IOException {
		
		List<ClientConn> conns = new ArrayList<ClientConn>();
		
		if (agent == null) {
			return conns;
		}
		
		PCFMessage request = new PCFMessage(MQConstants.MQCMD_INQUIRE_CONNECTION); 
		request.addParameter(MQConstants.MQBACF_GENERIC_CONNECTION_ID, new byte[0]); 
		request.addParameter(MQConstants.MQIACF_CONNECTION_ATTRS, new int[] { MQConstants.MQIACF_ALL });
		request.addParameter(MQConstants.MQIACF_CONN_INFO_TYPE, MQConstants.MQIACF_CONN_INFO_CONN );
		
		PCFMessage [] responses = agent.send(request); 

		for(int i=0; i<responses.length; i++) {
			
			PCFMessage response = responses[i];
			
			ClientConn conn = new ClientConn();
			
			// 過濾非透過 Channel的連線
			String channelName = ((String)response.getParameterValue(MQConstants.MQCACH_CHANNEL_NAME)).trim();
			if (channelName.length() == 0) {
				continue;
			}
			
			conn.setConnectionId((byte[])response.getParameterValue(MQConstants.MQBACF_CONNECTION_ID));
			conn.setConnInfoType((Integer)response.getParameterValue(MQConstants.MQIACF_CONN_INFO_TYPE));
			conn.setChannelName(((String)response.getParameterValue(MQConstants.MQCACH_CHANNEL_NAME)).trim());
			conn.setConnectionName(((String)response.getParameterValue(MQConstants.MQCACH_CONNECTION_NAME)).trim());
			conn.setApplTag(((String)response.getParameterValue(MQConstants.MQCACF_APPL_TAG)).trim());
			conn.setUserId(((String)response.getParameterValue(MQConstants.MQCACF_USER_IDENTIFIER)).trim());
			
			// TODO : 其他資訊
			
			conns.add(conn);
		}
		
		return conns;
	}
	
	
	
	/**
	 * 停止透過此通道的連線
	 * 
	 * @param channelName
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void stopConnection(String channelName) throws PCFException, MQDataException, IOException{
		
		if (agent == null) {
			return;
		}
		
		List<byte[]> connIds = getConnectionIds(channelName);
		
		for(byte[] connId : connIds) {
			stopConnection(connId);
		}
		
	}
	
	
	
	/**
	 * 取得透過此通道連線的 連線ID
	 * 
	 * @param channelName
	 * @return
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	private List<byte[]> getConnectionIds(String channelName) throws PCFException, MQDataException, IOException {
		
		List<byte[]> connIds = new ArrayList<byte[]>();
		
		PCFMessage request = new PCFMessage(MQConstants.MQCMD_INQUIRE_CONNECTION); 
		request.addParameter(MQConstants.MQBACF_GENERIC_CONNECTION_ID, new byte[0]); 
		request.addParameter(MQConstants.MQIACF_CONNECTION_ATTRS , new int[] { MQConstants.MQIACF_ALL });
		request.addFilterParameter(MQConstants.MQCACH_CHANNEL_NAME , MQConstants.MQCFOP_EQUAL, channelName);

		PCFMessage [] responses = agent.send(request); 
		
		for(int i=0; i<responses.length; i++) 
		{ 
			
			PCFMessage response = responses[i];
			
			byte[] connID = (byte[])response.getParameterValue(MQConstants.MQBACF_CONNECTION_ID);
			
			connIds.add(connID);
		} 
		
		return connIds;
		
	}
	
	
	
	/**
	 * 停止連線
	 * 
	 * @param connID
	 * @throws PCFException
	 * @throws MQDataException
	 * @throws IOException
	 */
	public void stopConnection(byte[] connID) throws PCFException, MQDataException, IOException{
		
		PCFMessage request = new PCFMessage(MQConstants.MQCMD_STOP_CONNECTION); 
		request.addParameter(MQConstants.MQBACF_CONNECTION_ID, connID);
		
		agent.send(request); 
	}
	

}

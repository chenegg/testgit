package com.ibm.tw.commons.util;

public class TraceUtils {

	private TraceUtils() {

	}

	public static void info(org.slf4j.Logger logger, String log) {
		logger.info(log);
	}

	public static void error(org.slf4j.Logger logger, String log) {
		logger.error(log);
	}

}

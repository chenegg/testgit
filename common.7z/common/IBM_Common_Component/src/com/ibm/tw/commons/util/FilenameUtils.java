/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2008.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util;
 
/**
 * <p> TODO description</p>
 *
 * @author  Kevin
 * @version 1.0, Dec 12, 2008
 * @see	    
 * @since 
 */
public class FilenameUtils extends org.apache.commons.io.FilenameUtils {
	
	/**
	 * 正規化檔案路徑，並將所有路徑分隔子代換為Unix分隔子"/"，
	 * 同時在路徑最後加上分隔子
	 * 
	 * <pre>
	 * "e:\\tmp" = "e:/tmp/";
	 * </pre>
	 * 
	 * @param path
	 */
	public static String normalizeDir(String path) {
		
		String dir = FilenameUtils.normalizeNoEndSeparator(path);
		
		if (StringUtils.isNotBlank(dir)) {
			return StringUtils.replace(dir, "\\", "/") + "/";
		}
		else {
			return "";
		}
		
		 
	}
	
	public static void main(String[] args) {
		
		String path = "e:/tmp/ftp";
		
		System.out.println(FilenameUtils.normalizeDir(path));
		
		
	}

}



 
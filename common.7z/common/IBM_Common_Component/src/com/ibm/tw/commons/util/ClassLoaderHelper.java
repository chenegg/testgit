package com.ibm.tw.commons.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
 
/**
 * 物件載入工具集
 * 
 * @author Jeff Liu
 * @version 1.0, 2004/10/18
 * @see
 * @since
 */

public class ClassLoaderHelper {
 
//	/**
//	 * get class instance by class name
//	 * 
//	 * @param sClassName
//	 * @return
//	 * @throws ClassLoaderException
//	 */
//	public static Object getInstance(String className) throws ClassLoaderException {
//
//		Object obj = null;
//
//		try {
//			Class<?> clazz = Class.forName(className);
//			obj = clazz.newInstance();
//		}
//
//		catch (InstantiationException e) {
//			
//			throw new ClassLoaderException("cannot instantiate class [" + className + "]", e);
//		}
//		catch (IllegalAccessException e) {
//			throw new ClassLoaderException("illegal access class [" + className + "]", e);
//		}
//		catch (ClassNotFoundException e) {
//			throw new ClassLoaderException("class not found [" + className + "]", e);
//		}
//
//		return obj;
//
//	}
	
	/**
	 * get class instance by class name
	 * 
	 * @param sClassName
	 * @return
	 * @throws ClassLoaderException
	 */
	public static Object getInstance(String className, Class<?>[] constructArgClasses, Object[] constructArgValues) throws ClassLoaderException {

		Object obj = null;

		try {
			Class<?> clazz = Class.forName(className);
			 
			 
			obj = ClassLoaderHelper.getInstance(clazz, constructArgClasses, constructArgValues); 
		}
 
		catch (ClassNotFoundException e) {
			throw new ClassLoaderException("class not found [" + className + "]", e);
		}
		catch (SecurityException e) {
			throw new ClassLoaderException("security exception [" + className + "]", e);
		}
		 

		return obj;

	}
	

	/**
	 * get class instance by class name
	 * 
	 * @param sClassName
	 * @return
	 * @throws ClassLoaderException
	 */
	public static Object getInstance(Class<?> clazz, Class<?>[] constructArgClasses, Object[] constructArgValues) throws ClassLoaderException {

		Object obj = null;

		try {
			 
			Constructor<?> constructorClazz = clazz.getConstructor(constructArgClasses);
			obj = constructorClazz.newInstance(constructArgValues);
	  
			 
		}

		catch (InstantiationException e) {
			throw new ClassLoaderException("cannot instantiate class [" + clazz + "]", e);
		}
		catch (IllegalAccessException e) {
			throw new ClassLoaderException("illegal access class [" + clazz + "]", e);
		}
		 
		catch (SecurityException e) {
			throw new ClassLoaderException("security exception [" + clazz + "]", e);
		}
		catch (NoSuchMethodException e) {
			throw new ClassLoaderException("no such constructor [" + clazz + "]", e);
		}
		catch (IllegalArgumentException e) {
			throw new ClassLoaderException("invalid constructor args [" + clazz + "]", e);
		}
		catch (InvocationTargetException e) {
			throw new ClassLoaderException("constructor invocation fail [" + clazz + "]", e);
		}

		return obj;

	}

	/**
	 * This method will search for <code>resource</code> in different places.
	 * The rearch order is as follows:
	 * 
	 * <ol>
	 * 
	 * <p>
	 * <li>Search for <code>resource</code> using the thread context class
	 * loader under Java2. If that fails, search for <code>resource</code>
	 * using the class loader that loaded this class (<code>Loader</code>).
	 * Under JDK 1.1, only the the class loader that loaded this class (<code>Loader</code>)
	 * is used.
	 * 
	 * <p>
	 * <li>Try one last time with
	 * <code>ClassLoader.getSystemResource(resource)</code>, that is is using
	 * the system class loader in JDK 1.2 and virtual machine's built-in class
	 * loader in JDK 1.1.
	 * 
	 * </ol>
	 */
	static public URL getResource(String resource) throws ClassLoaderException {
		ClassLoader classLoader = null;
		URL url = null;

		try {
		 
			// We could not find resource. Ler us now try with the
			// classloader that loaded this class.
			classLoader = ClassLoaderHelper.class.getClassLoader();
			if (classLoader != null) {
				 
				url = classLoader.getResource(resource);
				if (url != null) {
					return url;
				}
			}
		}
		catch (Throwable t) {

			 
			throw new ClassLoaderException("Caught Exception while in Loader.getResource. This may be innocuous.", t);
		}

		// Last ditch attempt: get the resource from the class path. It
		// may be the case that clazz was loaded by the Extentsion class
		// loader which the parent of the system class loader. Hence the
		// code below.
		 
		url = ClassLoader.getSystemResource(resource);

		if (null == url) {
			throw new ClassLoaderException("cannot load resource [" + resource + "]");
		}
		return url;
	}

 
 


	/**
	 * get class instance by class
	 * 
	 * @param sClassName
	 * @return
	 * @throws ClassLoaderException
	 */
	public static Object getInstance(Class<?> clazz) throws ClassLoaderException {

		Object obj = null;

		try {

			obj = clazz.newInstance();
		}

		catch (InstantiationException e) {
			throw new ClassLoaderException("cannot instantiate class [" + clazz.getName() + "]", e);
		}
		catch (IllegalAccessException e) {
			throw new ClassLoaderException("illegal access class [" + clazz.getName() + "]", e);
		}

		return obj;

	}

	  

}

package com.ibm.tw.commons.util.time;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.time.FastDateFormat;

/**
 * @author Kevin
 * 
 *         2004/10/20
 */
public class DateFormatUtils extends org.apache.commons.lang.time.DateFormatUtils {

	public static final FastDateFormat yyyyMM = FastDateFormat.getInstance("yyyyMM");

	public static FastDateFormat ddMMyyyy = FastDateFormat.getInstance("ddMMyyyy");

	public static final FastDateFormat MMddyyyy = FastDateFormat.getInstance("MMddyyyy");

	public static final FastDateFormat MMddyy = FastDateFormat.getInstance("MMddyy");

	public static final FastDateFormat SIMPLE_DATE_TIME_FORMAT = FastDateFormat.getInstance("yyyyMMdd HHmmss");

	/** yyyyMMdd (eg. 20071001) */
	public static final FastDateFormat SIMPLE_ISO_DATE_FORMAT = FastDateFormat.getInstance("yyyyMMdd");

	/** yyyyMMdd (eg. 20071001) */
	public static final FastDateFormat SIMPLE_DATE_FORMAT = FastDateFormat.getInstance("yyyyMMdd");

	/** HHmmss (eg. 131020) */
	public static final FastDateFormat SIMPLE_ISO_TIME_FORMAT = FastDateFormat.getInstance("HHmmss");

	public static final FastDateFormat SIMPLE_ISO_TIME_FORMAT2 = FastDateFormat.getInstance("HHmmssSSS");

	/** yyyyMMdd'T'HHmmss (eg. 20071001T131020) */
	public static final FastDateFormat SIMPLE_ISO_DATETIME_FORMAT = FastDateFormat.getInstance("yyyyMMdd'T'HHmmss");

	/** yyyy-MM-dd HHmmss (eg. 2007-10-01 13:10:20) */
	public static final FastDateFormat SQL_DATETIME_FORMAT = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");

	/** yyyyMMddHHmmss (eg. 20071001131020) */
	public static final FastDateFormat SIMPLE_DATETIME_FORMAT = FastDateFormat.getInstance("yyyyMMddHHmmss");

	public static final FastDateFormat SIMPLE_YYYYMM_FORMAT = FastDateFormat.getInstance("yyyy MM");

	/** ccc/MM/dd (eg. 099/01/01) */
	public static final String ROC_DATE_FORMAT = "ccc/MM/dd";

	/** ccc/MM/dd HH:mm:ss (eg. 099/01/01 13:10:20) */
	public static final String ROC_DATETIME_FORMAT = "ccc/MM/dd HH:mm:ss";

	/** cccMMdd (eg. 0990101) */
	public static final String SIMPLE_ROC_DATE_FORMAT = "cccMMdd";

	/** yyyy/MM/dd (eg. 2009/01/01) */
	public static final FastDateFormat CE_DATE_FORMAT = FastDateFormat.getInstance("yyyy/MM/dd");
	public static final FastDateFormat DD_MM_YYYY = FastDateFormat.getInstance("dd/MM/yyyy");

	public static final FastDateFormat CE_DATETIME_FORMAT2 = FastDateFormat.getInstance("yyyy/MM/dd HH:mm:ss");

	// public static final String CE_DATE_FORMAT = "yyyy/MM/dd";

	/** yyyy/MM/dd HH:mm:ss (eg. 2009/01/01 13:10:20) */
	public static final String CE_DATETIME_FORMAT = "yyyy/MM/dd HH:mm:ss";

	/** yyyy-MM-dd HH:mm:ss.SSS (eg. 2009-01-01 13:10:20.123) */
	public static final FastDateFormat CLIENTDT_FORMAT = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS");

	/** <code>START_TOKEN</code> 的註解 */
	private static Set<Character> START_TOKEN;

	public final static String java_date_pattern = "yyyy-MM-dd HH:mm:ss";

	/** yyyy-MM-dd HH:mm:ss.SSS (eg. 2009-01-01 13:10:20.123) */
	public static final FastDateFormat MM_dd = FastDateFormat.getInstance("MM/dd");

	static {
		START_TOKEN = new HashSet<Character>();
		START_TOKEN.add(Character.valueOf('c'));
		START_TOKEN.add(Character.valueOf('y'));
		START_TOKEN.add(Character.valueOf('M'));
		START_TOKEN.add(Character.valueOf('d'));
		START_TOKEN.add(Character.valueOf('h'));
		START_TOKEN.add(Character.valueOf('H'));
		START_TOKEN.add(Character.valueOf('m'));
		START_TOKEN.add(Character.valueOf('s'));
		START_TOKEN.add(Character.valueOf('-'));
		START_TOKEN.add(Character.valueOf('/'));
		START_TOKEN.add(Character.valueOf(':'));
		START_TOKEN.add(Character.valueOf(' '));
		START_TOKEN.add(Character.valueOf('('));
		START_TOKEN.add(Character.valueOf(')'));
	}

	/**
	 * @param format
	 * @return
	 */
	private static String[] parsePattern(String format) {
		int i = 0;
		int objLength = 0;
		String objs[] = new String[START_TOKEN.size()];
		while (i < format.length()) {
			char currentChar = format.charAt(i);
			// System.out.println("currentChar:" + currentChar);
			if (START_TOKEN.contains(currentChar)) {
				int oriPos = i;
				while (true) {
					if (i + 1 == format.length())
						break;
					if (i < format.length() && currentChar == format.charAt(i + 1))
						i++;
					else
						break;
				}
				i++;
				objs[objLength++] = format.substring(oriPos, i);
			} else {
				i++;
			}
		}
		return objs;
	}

	/**
	 * @param format
	 * @param date
	 * @return
	 */
	public static String format(Date date, String format) {
		if (date == null)
			return null;

		String[] fmtString = parsePattern(format);
		String strDate = getStrDate(fmtString, date);

		return strDate;
	}

	/**
	 * @param pattern
	 * @param dateVar
	 * @return
	 */
	private static String getStrDate(String[] pattern, Date dateVar) {
		StringBuffer strDate = new StringBuffer();
		Calendar c = Calendar.getInstance();
		c.setTime(dateVar);

		for (int j = 0; j < pattern.length; j++) {
			// System.out.println("array : " + pattern[j]);
			String patternValue = pattern[j];
			if (pattern[j] != null) {
				if (patternValue.contains("y")) {
					strDate.append(c.get(Calendar.YEAR));

				} else if (patternValue.contains("c")) {
					if (patternValue.equals("cc"))
						strDate.append(fixLength(String.valueOf((c.get(Calendar.YEAR) - 1911) % 100), 2, '0'));
					else if (patternValue.equals("ccc"))
						strDate.append(fixLength(String.valueOf(c.get(Calendar.YEAR) - 1911), 3, '0'));
					else if (patternValue.equals("cccc")) {
						if (c.get(Calendar.YEAR) - 1911 < 100)
							strDate.append("00").append(c.get(Calendar.YEAR) - 1911);
						else
							strDate.append("0").append(c.get(Calendar.YEAR) - 1911);
					}
				} else if (patternValue.contains("M")) {
					int month = c.get(Calendar.MONTH) + 1;
					checkTime(month, strDate);
					strDate.append(month);
				} else if (patternValue.contains("d")) {
					int date = c.get(Calendar.DATE);
					checkTime(date, strDate);
					strDate.append(date);
				} else if (patternValue.contains("h") || patternValue.contains("H")) {
					int hr = c.get(Calendar.HOUR_OF_DAY);
					checkTime(hr, strDate);
					strDate.append(hr);
				} else if (patternValue.contains("m")) {
					int min = c.get(Calendar.MINUTE);
					checkTime(min, strDate);
					strDate.append(min);
				} else if (patternValue.contains("s")) {
					int sec = c.get(Calendar.SECOND);
					checkTime(sec, strDate);
					strDate.append(sec);
				} else if (patternValue.contains("-")) {
					strDate.append("-");
				} else if (patternValue.contains("/")) {
					strDate.append("/");
				} else if (patternValue.contains(":")) {
					strDate.append(":");
				} else if (patternValue.contains(" ")) {
					strDate.append(" ");
				} else if (patternValue.contains(")")) {
					strDate.append(")");
				} else if (patternValue.contains("(")) {
					strDate.append("(");
				}
			}
		}
		return strDate.toString();
	}

	/**
	 * @param val
	 * @param sb
	 */
	private static void checkTime(int val, StringBuffer sb) {
		if (val < 10) {
			sb.append("0");
		}
	}

	/**
	 * @param data
	 * @param length
	 * @param token
	 * @return
	 */
	private static String fixLength(String data, int length, char token) {
		int i = data.length();
		StringBuilder buf = new StringBuilder();
		while (i < length) {
			buf.append(token);
			i++;
		}
		buf.append(data);
		return buf.toString();
	}
}

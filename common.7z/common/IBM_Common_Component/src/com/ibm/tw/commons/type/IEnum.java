/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2012.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.type;


/**
 * <p>
 * Enum共同介面 (for i18n)
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2012/11/26
 * @see
 * @since
 */
public interface IEnum {

	public static String ENUM_I18N_CATE = "EnumType";

	/** 未知代碼 */
	public int UNKNOWN_INT_CODE = -9;

	/** 未知代碼 */
	public String UNKNOWN_STR_CODE = "";

	public String name();

	public String getMemo();

}

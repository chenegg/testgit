package com.ibm.tw.commons.util;

import java.util.ArrayList;

/**
 * Excel的表頭檔
 * @author Egg.chen
 *
 */
public class ExcelHeader {

	private ArrayList<String> headers = null;

	public String getHeaderValue(int index) {
		String value = "";
		if (getSize() > 0) {
			value = this.getHeaders().get(index);
		}
		return value;
	}

	private ArrayList<String> getHeaders() {
		if (headers == null) {
			headers = new ArrayList<String>();
		}
		return headers;
	}

	public void setHeaders(ArrayList<String> headers) {
		this.headers = headers;
	}

	public int getSize() {
		return getHeaders().size();
	}

}

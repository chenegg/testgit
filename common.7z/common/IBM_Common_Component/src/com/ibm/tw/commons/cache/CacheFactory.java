/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.cache;

import java.util.Hashtable;
import java.util.Map;


/**
 * <p>Cache Factory</p>
 *
 * @author  jeff
 * @version 1.0, 2011/2/10
 * @see	    
 * @since 
 */
public class CacheFactory {
	
	/** CACHE MAP <系統代碼，ICacheManager> */
	protected static Map<String, CacheManager> cacheManagerMap = new Hashtable<String, CacheManager>();
	
	/**
	 * 註冊CacheManager
	 * 
	 * @param cacheManager
	 */
	public static void register(CacheManager cacheManager) {
		
		if (null == cacheManager) {
			return;
		}
		
		String className = cacheManager.getClass().getName();
		
		cacheManagerMap.put(className, cacheManager);
	}
	
	/**
	 * 取得系統
	 * 
	 * @param systemId
	 * @return
	 */
	public static CacheManager getCacheManager(Class<? extends CacheManager> clazz) throws RuntimeException {
		
		if (null == clazz) {
			throw new RuntimeException("clazz is null");
		}
		
		String className = clazz.getName();
		
		CacheManager cacheManager = cacheManagerMap.get(className);
		
		if (null == cacheManager) {
			throw new RuntimeException("no cache manager for class name = " + className);
		}
		
		return cacheManager;
	}
	

}



 
/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.exception;



/**
 * Type Mismatch Exception
 *
 * @author  Jeff Liu
 * @version 1.0, 2007/10/25
 * @see	    
 * @since 
 */
@SuppressWarnings("serial")
public class TypeMismatchException extends RuntimeException {
	 
 
	public TypeMismatchException() {
    		
	    super();
	}
    
	public TypeMismatchException(String sMsg) {
    	
		super(sMsg);
	}
    
	 
    
	public TypeMismatchException(String sMsg, Throwable cause) {
    	
		super(sMsg, cause);
	 
	 
	}
 

	 

}

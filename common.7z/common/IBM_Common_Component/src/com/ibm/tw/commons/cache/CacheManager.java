/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.cache;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>Cache Manager共用元件</p>
 *
 * @author  jeff
 * @version 1.0, 2011/2/10
 * @see	    
 * @since 
 */
public abstract class CacheManager {

	protected Log logger = LogFactory.getLog(CacheManager.class);

}

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util.converter;

import java.sql.Types;
import java.util.Hashtable;
import java.util.Map;


/**
 * TODO DESCRIPTION
 *
 * @author  Jeff Liu
 * @version 1.0, 2007/11/7
 * @see	    
 * @since 
 */
public class JavaClass2SQLTypeConverter {
	
	/** Java Class -> SQL Type Mapping Table */
	private static Map<Class<?>, Integer> m_map = new Hashtable<Class<?>, Integer>();
	
	static {
		deregister();
	}
	
	/**
	 * 取得SQL Type
	 * 
	 * @param clazz
	 * @return
	 */
	public static int getSQLType(Class<?> clazz) {
		Integer value = (Integer)m_map.get(clazz);
		
		return (value != null) ? value.intValue() : 0;
	}


	/**
	 * Java Class -> SQL Type Mapping Table
	 *
	 */
	public static void deregister() {
		m_map.clear();
		// BIT 		=  -7
		m_map.put(Boolean.class, Types.BIT);

		// TINYINT 	=  -6
		m_map.put(Integer.class, Types.TINYINT);

		// SMALLINT	=   5
		m_map.put(Integer.class, Types.SMALLINT);

		// INTEGER 	=   4
		m_map.put(Integer.class, Types.INTEGER);

		// BIGINT 		=  -5
		m_map.put(Long.class, Types.BIGINT);

		// FLOAT 		=   6
		m_map.put(Double.class, Types.FLOAT);

		// REAL 		=   7
		m_map.put(Float.class, Types.REAL);

		// DOUBLE 		=   8
		m_map.put(Double.class, Types.DOUBLE);

		// NUMERIC 	=   2
		m_map.put(java.math.BigDecimal.class, Types.NUMERIC);

		// DECIMAL		=   3
		m_map.put(java.math.BigDecimal.class, Types.DECIMAL);

		// CHAR		=   1
		m_map.put(String.class, Types.CHAR);

//		// VARCHAR 	=  12
//		m_map.put("VARCHAR", String.class);

//		// LONGVARCHAR 	=  -1
//		m_map.put("LONGVARCHAR", String.class);

		// DATE 		=  91
		m_map.put(java.sql.Date.class, Types.DATE);

		// TIME 		=  92
		m_map.put(java.sql.Time.class, Types.TIME);

		// TIMESTAMP 	=  93
		m_map.put(java.sql.Timestamp.class, Types.TIMESTAMP);
		
 

		//BINARY		=  -2
		m_map.put(byte[].class, Types.BINARY);

		// VARBINARY 	=  -3
		m_map.put(byte[].class, Types.VARBINARY);

		// LONGVARBINARY 	=  -4
		m_map.put(byte[].class, Types.LONGVARBINARY);

		// NULL		=   0

		// OTHER		= 1111

		// JAVA_OBJECT         = 2000

		// DISTINCT            = 2001

		// STRUCT              = 2002
		m_map.put(java.sql.Struct.class, Types.STRUCT);

		// ARRAY               = 2003
		m_map.put(java.sql.Array.class, Types.ARRAY);

		// BLOB                = 2004
		m_map.put(java.sql.Blob.class, Types.BLOB);

		// CLOB                = 2005
		m_map.put(java.sql.Clob.class, Types.CLOB);

		// REF                 = 2006
		m_map.put(java.sql.Ref.class, Types.REF);

		// DATALINK = 70

		// BOOLEAN = 16

	}

	
	public static void main(String[] args) {
		
		Integer iValue = 2; 
		
		System.out.println("type = " + getSQLType(iValue.getClass()));
	}

}

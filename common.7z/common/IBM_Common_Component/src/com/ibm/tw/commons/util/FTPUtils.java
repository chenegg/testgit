package com.ibm.tw.commons.util;

import java.io.IOException;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.log4j.Logger;

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2013.
 *
 * ===========================================================================
 */

/**
 * <p>
 * FTP工具集
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2013/12/26
 * @see
 * @since
 */
public class FTPUtils {

	private static Logger logger = Logger.getLogger(FTPUtils.class);

	/**
	 * FTP連線
	 * 
	 * @return
	 * @throws IOException
	 */
	public static FTPClient connect(String server, int port, String user, String password, String workingDir)
			throws IOException {
		FTPClient ftpClient = new FTPClient();
		FTPClientConfig config = new FTPClientConfig(FTPClientConfig.SYST_UNIX);
		ftpClient.configure(config);
		ftpClient.connect(server, port);
		logger.debug(ftpClient.getReplyString());
		ftpClient.login(user, password);
		logger.debug(ftpClient.getReplyString());
		if (StringUtils.isNotBlank(workingDir)) {
			ftpClient.changeWorkingDirectory(workingDir);
		}
		logger.debug(ftpClient.getReplyString());
		logger.debug(ftpClient.printWorkingDirectory());
		logger.debug(ftpClient.getReplyString());

		ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
		logger.debug(ftpClient.getReplyString());
		// ftpClient.pasv();
		// logger.debug(ftpClient.getReplyString());
		return ftpClient;
	}

	/**
	 * FTP斷線
	 * 
	 * @param ftpClient
	 * @throws IOException
	 */
	public static void disconnect(FTPClient ftpClient) throws IOException {
		if (ftpClient != null) {
			ftpClient.logout();
			logger.debug(ftpClient.getReplyString());
			ftpClient.disconnect();
			logger.debug(ftpClient.getReplyString());
		}
	}

	/**
	 * 移除目標路徑
	 * 
	 * @throws IOException
	 */
	public static void removeDir(FTPClient ftpClient, String dir) throws IOException {

		ftpClient.removeDirectory(dir);
		logger.debug(ftpClient.getReplyString());
	}
}

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util.converter;

import java.util.Hashtable;
import java.util.Map;

import com.ibm.tw.commons.util.StringUtils;

/**
 * 將JDBC Type Name轉換成對應的Java Class
 * 
 * @author  Kevin
 * @version 1.0, 2007/10/19
 * @see	    
 * @since 
 */
public class SQLTypeName2JavaClassConverter {

	/** 儲存JDBC Type Name -> Java Class 轉碼表 */	 
	@SuppressWarnings("unchecked")
	private static Map<String, Class> m_jdbc2JavaTypes = new Hashtable<String, Class>();

	static {
		deregister();
	}

  
	 
	
	/**
	 * 
	 * @param sJdbcTypeName
	 * @return
	 */
    @SuppressWarnings("unchecked")
	public static Class getJavaClass(String sJdbcTypeName) {
        
        if (StringUtils.isBlank(sJdbcTypeName)) {
            return null;
        }
        
        return m_jdbc2JavaTypes.get(sJdbcTypeName.toUpperCase());
                        
    }

	/**
	 * mapping sql type to java class 
	 *
	 */
	public static void deregister() {
		m_jdbc2JavaTypes.clear();
		// BIT 		=  -7
		m_jdbc2JavaTypes.put("BIT", Boolean.class);

		// TINYINT 	=  -6
		m_jdbc2JavaTypes.put("TINYINT", Integer.class);

		// SMALLINT	=   5
		m_jdbc2JavaTypes.put("SMALLINT", Integer.class);

		// INTEGER 	=   4
		m_jdbc2JavaTypes.put("INTEGER", Integer.class);

		// BIGINT 		=  -5
		m_jdbc2JavaTypes.put("BIGINT", Long.class);

		// FLOAT 		=   6
		m_jdbc2JavaTypes.put("FLOAT", Double.class);

		// REAL 		=   7
		m_jdbc2JavaTypes.put("REAL", Float.class);

		// DOUBLE 		=   8
		m_jdbc2JavaTypes.put("DOUBLE", Double.class);

		// NUMERIC 	=   2
		m_jdbc2JavaTypes.put("NUMERIC", java.math.BigDecimal.class);

		// DECIMAL		=   3
		m_jdbc2JavaTypes.put("DECIMAL", java.math.BigDecimal.class);

		// CHAR		=   1
		m_jdbc2JavaTypes.put("CHAR", String.class);

		// VARCHAR 	=  12
		m_jdbc2JavaTypes.put("VARCHAR", String.class);

		// LONGVARCHAR 	=  -1
		m_jdbc2JavaTypes.put("LONGVARCHAR", String.class);

		// DATE 		=  91
		m_jdbc2JavaTypes.put("DATE", java.sql.Date.class);

		// TIME 		=  92
		m_jdbc2JavaTypes.put("TIME", java.sql.Time.class);

		// TIMESTAMP 	=  93
		m_jdbc2JavaTypes.put("TIMESTAMP", java.sql.Timestamp.class);
		
		// TIMESTMP 	=  93 => SYSIBM.SYSCOLUMNS 中的 Timetamp欄位名稱為TIMESTMP
		m_jdbc2JavaTypes.put("TIMESTMP", java.sql.Timestamp.class);

		//BINARY		=  -2
		m_jdbc2JavaTypes.put("BINARY", byte[].class);

		// VARBINARY 	=  -3
		m_jdbc2JavaTypes.put("VARBINARY", byte[].class);

		// LONGVARBINARY 	=  -4
		m_jdbc2JavaTypes.put("LONGVARBINARY", byte[].class);

		// NULL		=   0

		// OTHER		= 1111

		// JAVA_OBJECT         = 2000

		// DISTINCT            = 2001

		// STRUCT              = 2002
		m_jdbc2JavaTypes.put("STRUCT", java.sql.Struct.class);

		// ARRAY               = 2003
		m_jdbc2JavaTypes.put("ARRAY", java.sql.Array.class);

		// BLOB                = 2004
		m_jdbc2JavaTypes.put("BLOB", java.sql.Blob.class);

		// CLOB                = 2005
		m_jdbc2JavaTypes.put("CLOB", java.sql.Clob.class);

		// REF                 = 2006
		m_jdbc2JavaTypes.put("REF", java.sql.Ref.class);

		// DATALINK = 70

		// BOOLEAN = 16

	}

}

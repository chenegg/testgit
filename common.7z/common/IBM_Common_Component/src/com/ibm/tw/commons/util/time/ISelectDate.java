package com.ibm.tw.commons.util.time;

public interface ISelectDate {
	/*
	 * 查詢期間別 2 最近一週 3 最近一個月 4 最近三個月 1 特定日期 5 自行輸入查詢期間
	 */

	public String getSelectItem();

	public String getSelectYear();

	public String getSelectMonth();

	public String getSelectDay();

	public String getSelectStartYear();

	public String getSelectStartMonth();

	public String getSelectStartDay();

	public String getSelectEndYear();

	public String getSelectEndMonth();

	public String getSelectEndDay();

}

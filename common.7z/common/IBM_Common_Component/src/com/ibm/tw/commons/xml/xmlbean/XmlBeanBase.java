/*
 * ===========================================================================
 * IBM Confidential AIS Source Materials
 * 
 * XML Bean Base Class
 * 
 * (C) Copyright IBM Corp. 2005.
 * 
 * ===========================================================================
 */
package com.ibm.tw.commons.xml.xmlbean;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;

/**
 * XML Bean Base Class
 * 
 * @author Kevin
 * @version 1.0, 2004/11/15
 * @see
 * @since
 */
public abstract class XmlBeanBase {

	/** Log */
	protected static Log logger = LogFactory.getLog(XmlBeanBase.class);

	/** Document Root */
	protected XmlObject m_root = null;

	/**
	 * 
	 */
	public XmlBeanBase() {

	}

 

	/**
	 * 解析XML
	 * 
	 * @param sXml
	 * @param schemaType
	 * @throws XmlBeanException
	 */
	public void parseXml(String sXml, SchemaType schemaType) throws XmlBeanException {
		StringReader strReader = null;
		try {
			XmlOptions options = new XmlOptions();
			options.setDocumentType(schemaType);
			
//			XmlOptionCharEscapeMap map = new XmlOptionCharEscapeMap();
//			
//			char ch = 0x00;
//			map.addMapping(ch, XmlOptionCharEscapeMap.HEXADECIMAL);
			 
			
			strReader = new StringReader(sXml);
			m_root = XmlObject.Factory.parse(strReader, options);
		}
		catch (XmlException e) {
			 
			
			throw new XmlBeanException("cannot parse xml", sXml, e);
		}
		catch (IOException e) {
			throw new XmlBeanException("cannot convert xml to StringReader", e);
		}
		finally {
			IOUtils.closeQuietly(strReader);
		}
	}

	/**
	 * 解析XML<br>
	 * 發生錯誤將忽略
	 * 
	 * @param sXml
	 * @param schemaType
	 */
	public void parseXmlQuietly(String sXml, SchemaType schemaType) {
		try {
			parseXml(sXml, schemaType);
		}
		catch (XmlBeanException e) {
			// quietly
			getLogger().error(e);
		}
	}

	/**
	 * 解析XML File<br>
	 * 
	 * @param sFileName
	 * @param schemaType
	 * @throws XmlBeanException
	 */
	public void parseXmlFile(String sFileName, SchemaType schemaType) throws XmlBeanException {
		File file = null;
		try {
			file = new File(sFileName);
			XmlOptions options = new XmlOptions();
			options.setDocumentType(schemaType);
			m_root = XmlObject.Factory.parse(file, options);
		}
		catch (XmlException e) {
			throw new XmlBeanException("cannot parse xml file [" + sFileName + "]", e);
		}
		catch (IOException e) {
			throw new XmlBeanException("xml file is not found [" + sFileName + "]", e);
		}
	}

	/**
	 * 解析XML File<br>
	 * 發生錯誤將忽略
	 * 
	 * @param sFileName
	 * @param schemaType
	 */
	public void parseXmlFileQuietly(String sFileName, SchemaType schemaType) {
		try {
			parseXmlFile(sFileName, schemaType);
		}
		catch (XmlBeanException e) {
			getLogger().error(e);
		}
	}

	/**
	 * 從URL解析XML
	 * 
	 * @param url
	 * @param schemaType
	 * @throws XmlBeanException
	 */
	public void parseURL(URL url, SchemaType schemaType) throws XmlBeanException {
		try {
			XmlOptions options = new XmlOptions();
			options.setDocumentType(schemaType);
			m_root = XmlObject.Factory.parse(url, options);
		}
		catch (XmlException e) {
			throw new XmlBeanException("cannot parse xml url [" + url + "]", e);
		}
		catch (IOException e) {
			throw new XmlBeanException("xml url is not found [" + url + "]", e);
		}
	}

	/**
	 * 從URL解析XML<br>
	 * 發生錯誤將忽略
	 * 
	 * @param url
	 * @param schemaType
	 */
	public void parseURLQuietly(URL url, SchemaType schemaType) {
		try {
			parseURL(url, schemaType);
		}
		catch (XmlBeanException e) {
			getLogger().error(e);
		}
	}

	 
   

	/**
	 * 轉換成XML String
	 * 
	 * @return
	 */
	public String toXml() {
		return XmlBeanUtils.toXml(getRoot());
	}

	/**
	 * 依照編碼轉換成XML String
	 * 
	 * @param sEncoding
	 * @return
	 */
	public String toXml(String sEncoding) {
		StringBuffer sb = new StringBuffer();
		sEncoding = "\"" + sEncoding + "\"";
		sb.append("<?xml version='1.0' encoding=").append(sEncoding).append("?>\n");
		sb.append(toXml());
		return sb.toString();
	}

	/**
	 * 檢核 XML
	 * 
	 * @throws XmlBeanException
	 */
	public void validate() throws XmlBeanException {
		XmlBeanUtils.validate(getRoot());
	}

	/**
	 * @return
	 */
	protected Log getLogger() {
		return logger;
	}

	/**
	 * 取得 Root
	 * 
	 * @return
	 */
	public XmlObject getRoot() {
		return m_root;
	}
	
	
}

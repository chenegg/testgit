/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * Cache Interface
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.cache;


/**
 * @author  Kevin
 * @version 1.0, 2006/1/23
 * @see	    
 * @since 
 */
public interface ICache {
    

    
	/**
	 * Retrieve an object from the cache.
	 * @param key key associated with desired object.
	 * @return object identified by provided key.
	 */
	public abstract Object retrieve(Object key);
	 
	
	/**
	 * Store an object in the cache.
	 * @param key key associated with object to store.
	 * @param value object identified by provided key.
	 */
	public abstract void store(Object key, Object value);
	
	 
  
	
	/**
	 * Remove an object from the cache.
	 * @param key key associated with object to remove.
	 * @return object that was removed.
	 */
	public abstract Object remove(Object key);
    
	 
	
	/**
	 * Clear the cache.
	 */
    public abstract void clear();
    
    /**
     * Get the current size of the cache.
     */
    public abstract int size();
}


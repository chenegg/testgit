package com.ibm.tw.commons.util.converter;

import java.util.Date;
import org.apache.commons.beanutils.Converter;

public class DateConvert implements Converter {

	public Object convert(Class arg0, Object arg1) {
		Date date = (Date) arg1;
		return date == null ? null : date;
	}

}
/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */ 
package com.ibm.tw.commons.net.mq;

import com.ibm.mq.MQException;
 
 
/**
 * <p>MQ Exception</p>
 *
 * @author  jeff
 * @version 1.0, Mar 16, 2009
 * @see	    
 * @since 
 */
public class CMQException extends Exception {
     
    /**
	 * <code>serialVersionUID</code> 的註解
	 */
	private static final long serialVersionUID = -1400736312983613656L;

	protected MQException m_mqException = null;
    
    protected CMQEnvironment m_env = null;
    
    public CMQException(MQException ex, IMQEnvironment env) {
        super();
        
        setMQException(ex);
        
        m_env = new CMQEnvironment(env);
    }
     
    public CMQException(MQException ex, CMQEnvironment env) {
        super();
        
        setMQException(ex);
        
        setMQEnvironment(env);
    }    
     
    
    public void setMQException(MQException e) {
        m_mqException = e;
        
    }
    
    public MQException getMQException() {
        return m_mqException;
    }
    
    public void setMQEnvironment(CMQEnvironment env) {
        m_env = env;
    }
    
    public CMQEnvironment getMQEnvironment() {
        return m_env;
    }
    

    
	 
	 
}

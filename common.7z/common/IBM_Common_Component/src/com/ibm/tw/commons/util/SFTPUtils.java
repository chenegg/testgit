package com.ibm.tw.commons.util;

import java.io.File;
import java.util.Collection;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.apache.log4j.Logger;

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2013.
 *
 * ===========================================================================
 */

/**
 * <p>
 * FTP工具集
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2013/12/26
 * @see
 * @since
 */
public class SFTPUtils {

	private static Logger logger = Logger.getLogger(SFTPUtils.class);

	public static void upload(String hostName, String username, String password, Collection<File> files) {
		StandardFileSystemManager manager = null;
		try {
			manager = new StandardFileSystemManager();
			manager.init();
			for (File localFile : files) {
				logger.info("【 上傳中= " + localFile.getAbsolutePath() + "....】");
				FileObject localFileObj = manager.resolveFile(localFile.getAbsolutePath());
				FileObject remoteFileObj = manager.resolveFile(
						createConnectionString(hostName, username, password, localFile.getName()),
						createDefaultOptions());
				remoteFileObj.copyFrom(localFileObj, Selectors.SELECT_SELF);
				logger.info("【 上傳完成= " + localFile.getAbsolutePath() + "】");
			}
		} catch (FileSystemException e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			if (manager != null) {
				manager.close();
			}
		}
	}

	/**
	 * sftp://gF05_KSFTP:***@ksftp.kgibank.com/
	 * 
	 * @param hostName
	 * @param username
	 * @param password
	 * @param remoteFilePath
	 * @return
	 */
	private static String createConnectionString(String hostName, String username, String password,
			String remoteFilePath) {
		return "sftp://" + username + ":" + password + "@" + hostName + "/" + remoteFilePath;
	}

	/**
	 * 
	 * @return
	 * @throws FileSystemException
	 */
	private static FileSystemOptions createDefaultOptions() throws FileSystemException {
		FileSystemOptions opts = new FileSystemOptions();
		SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
		SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true);
		SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000);
		return opts;
	}
}

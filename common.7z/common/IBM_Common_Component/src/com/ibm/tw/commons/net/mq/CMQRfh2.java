/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2009.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;

import com.ibm.mq.MQC;
import com.ibm.mq.MQMessage;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * MQ Rfh2
 * </p>
 * 
 * @author jeff
 * @version 1.0, Mar 17, 2009
 * @see
 * @since
 */
public class CMQRfh2 {

	/** MQ RFH2 固定欄位 */

	/** Structure identifier */
	private String m_structId = MQC.MQRFH_STRUC_ID;

	/** Structure version number (MQRFH_VERSION_2) */
	private int m_version = MQC.MQRFH_VERSION_2;

	/** Total length of MQRFH2 (including NameValueData) */
	private int m_structLen = MQC.MQRFH_STRUC_LENGTH_FIXED_2;

	/** Numeric encoding of data that follows NameValueData */
	private int m_encoding = MQC.MQENC_NATIVE;

	/** Character set identifier of data that follows NameValueData (TODO: 待確認實際作用)*/
	private int m_codedCharSetId = MQC.MQCCSI_INHERIT;

	/** Format name of data that follows NameValueData */
	private String m_format = MQC.MQFMT_NONE;

	/** Flags */
	private int m_flags = MQC.MQRFH_NO_FLAGS;

	/** haracter set identifier of NameValueData */
	private int m_nameValueCCSID = 1208;

	/** MQ RFH2 Data */
	private String m_rfh2Data = "";

	private static Logger m_logger = Logger.getLogger(CMQRfh2.class);

	public CMQRfh2() {

	}

	public CMQRfh2(MQMessage message) {
		decodeRfh2FixData(message);
		decodeRfh2VariableData(message);
	}

	/**
	 * MQMessage -> CMQRfh2Message (RFH2 Fix Data)
	 * 
	 */
	private void decodeRfh2FixData(MQMessage mqMessage) {
		try {

			m_structId = mqMessage.readStringOfByteLength(4);
			m_version = mqMessage.readInt();
			m_structLen = mqMessage.readInt();
			m_encoding = mqMessage.readInt();
			m_codedCharSetId = mqMessage.readInt();

			m_format = mqMessage.readStringOfByteLength(8);
			m_flags = mqMessage.readInt();
			m_nameValueCCSID = mqMessage.readInt();

		}
		catch (IOException e) {
			m_logger.error(e);
		}
	}

	/**
	 * MQMessage -> CMQRfh2Message (RFH2中使用者自訂的訊息資料)
	 * 
	 * @return
	 */
	private void decodeRfh2VariableData(MQMessage mqMessage) {

		StringBuffer rfh2VariableData = new StringBuffer();

		try {

			int iTotalVarDataLen = this.m_structLen - MQC.MQRFH_STRUC_LENGTH_FIXED_2;

			mqMessage.seek(MQC.MQRFH_STRUC_LENGTH_FIXED_2);
			int iCCSID = this.m_nameValueCCSID;
			String sCCSIDName = ConvertUtils.ccsid2Encoding(iCCSID);
			int iLen = 0;

			while (iLen < iTotalVarDataLen) {
				// 前四bytes為RFH2變動資料長度
				int iVarLen = mqMessage.readInt();

				byte[] buf = new byte[iVarLen];
				mqMessage.readFully(buf, 0, iVarLen);
				String sData = new String(buf, sCCSIDName).trim();

				rfh2VariableData.append(sData);

				// 資料長度 ＋ 4 bytes長度
				iLen += iVarLen + 4;

			}

		}
		catch (UnsupportedEncodingException e) {
			m_logger.error(e);
		}
		catch (IOException e) {
			m_logger.error(e);
		}

		m_rfh2Data = rfh2VariableData.toString();
	}

	/**
	 * MQ RFH2 Message -> CMQRfh2
	 * 
	 * @param mqMessage
	 * @throws IOException
	 */
	public void encode(MQMessage mqMessage) throws IOException {

		String sCCSIDName = ConvertUtils.ccsid2Encoding(m_nameValueCCSID);

		// 取得變動欄位資料
		byte[] rfh2VariableData = bytes2Rfh2Data(sCCSIDName, m_rfh2Data);

		// RFH2總長度 ＝ RFH2固定欄位長度 ＋ 4 bytes儲存變動欄位長度 ＋變動欄位長度
		int iRfh2TotalLen = MQC.MQRFH_STRUC_LENGTH_FIXED_2 + 4 + rfh2VariableData.length;

		m_structLen = iRfh2TotalLen;

		// RFH2 fix data
		encodeRfh2FixData(mqMessage);

		// RFH2 variable data length
		mqMessage.writeInt(rfh2VariableData.length);
		// RFH2 variable data
		mqMessage.write(rfh2VariableData, 0, rfh2VariableData.length);

	}

	/**
	 * CMQRfh2Message (RFH2 Fix Data) -> MQMessage
	 * 
	 * @throws IOException
	 * 
	 */
	private void encodeRfh2FixData(MQMessage mqMessage) throws IOException {

		// structId
		byte[] structId = this.m_structId.getBytes();
		mqMessage.write(structId, 0, 4);

		// version
		mqMessage.writeInt(this.m_version);

		// structLength
		mqMessage.writeInt(this.m_structLen);
		// encoding
		mqMessage.writeInt(this.m_encoding);
		// codedCharSetId
		mqMessage.writeInt(this.m_codedCharSetId);
		// format
		byte[] format = StringUtils.rightPad(this.m_format, 8, " ").getBytes();
		mqMessage.write(format, 0, 8);
		// flags
		mqMessage.writeInt(this.m_flags);
		// nameValueCCSID
		mqMessage.writeInt(this.m_nameValueCCSID);

	}

	/**
	 * <p>
	 * 處理RFH2 Variable Data
	 * </p>
	 * 
	 * 資料長度必須為4的倍數，不足者補空白
	 * 
	 * @param sCCSIDName
	 * @param sMetaData
	 * @return
	 */
	private byte[] bytes2Rfh2Data(String sCCSIDName, String sMetaData) {
		byte[] data = null;

		try {
			byte[] xmlBytes = sMetaData.getBytes(sCCSIDName);

			// calculate the length of the variable part of the rfh,
			// padded with up to 3 blanks to be a multiple of 4

			int iLen = xmlBytes.length;
			if ((iLen % 4) > 0) {
				iLen += 4 - (iLen % 4);
			}
			data = new byte[iLen];
			System.arraycopy(xmlBytes, 0, data, 0, xmlBytes.length);
			//
			for (int i = xmlBytes.length; i < iLen; i++) {
				data[i] = 0x20;
			}
		}
		catch (UnsupportedEncodingException e) {
			data = null;

		}
		return data;
	}

	/**
	 * This field identifies the coded character set for any character strings
	 * in the data that follows the last NameValueData field.
	 * 
	 * @return
	 */
	public int getCodedCharSetId() {
		return m_codedCharSetId;
	}

	/**
	 * 
	 * @param charSetId
	 */
	public void setCodedCharSetId(int charSetId) {
		m_codedCharSetId = charSetId;
	}

	public int getEncoding() {
		return m_encoding;
	}

	public void setEncoding(int encoding) {
		m_encoding = encoding;
	}

	public int getFlags() {
		return m_flags;
	}

	public void setFlags(int flags) {
		m_flags = flags;
	}

	public String getFormat() {
		return m_format;
	}

	public void setFormat(String format) {
		m_format = format;
	}

	public int getNameValueCCSID() {
		return m_nameValueCCSID;
	}

	public void setNameValueCCSID(int valueCCSID) {
		m_nameValueCCSID = valueCCSID;
	}

	public String getRfh2Data() {
		return m_rfh2Data;
	}

	public void setRfh2Data(String data) {
		m_rfh2Data = data;
	}

	public String getStructId() {
		return m_structId;
	}

//	public void setStructId(String id) {
//		m_structId = id;
//	}

	public int getStructLen() {
		return m_structLen;
	}

	public void setStructLen(int len) {
		m_structLen = len;
	}

	public int getVersion() {
		return m_version;
	}

	public void setVersion(int version) {
		m_version = version;
	}

}

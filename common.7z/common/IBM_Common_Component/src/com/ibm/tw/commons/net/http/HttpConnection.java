/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2008.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Http Connection
 * 
 * @author
 * @version 1.0, May 5, 2008
 * @see
 * @since
 */
public class HttpConnection {
	/** Log */
	// private static Log logger = LogFactory.getLog(HttpConnection.class);
	private static Logger logger = LoggerFactory.getLogger(HttpConnection.class);

	public static final int INFO = 0;

	public static final int ERROR = 3;

	/** 連接的URL */
	private String urlPath = "";

	/** HTTP回應Code */
	private int responseCode = -1;

	static {
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			@SuppressWarnings("unused")
			public boolean isServerTrusted(java.security.cert.X509Certificate[] certs) {
				return true;
			}

			@SuppressWarnings("unused")
			public boolean isClientTrusted(java.security.cert.X509Certificate[] certs) {
				return true;
			}

			public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			}
		} };
		// Install the all-trusting trust manager
		try {
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			HostnameVerifier hv = new HostnameVerifier() {
				public boolean verify(String urlHostName, SSLSession session) {
					logger.debug("URL Host: " + urlHostName + " vs. " + session.getPeerHost());
					return true;
				}
			};
			HttpsURLConnection.setDefaultHostnameVerifier(hv);
		} catch (Exception e) {
			logger.error("Init Default SSL factory catch some exception", e);
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HttpConnection conn = new HttpConnection("https://www.ezpos-test.fisc.com.tw/SSLAuthUI.cgi");
		// HttpConnection conn = new
		// HttpConnection("https://www.ezpos-test.fisc.com.tw/sslauth.cgi");

		try {
			System.out.println(conn.Receive(
					"merID=695&MerchantID=009518116099001&TerminalID=90010001&MerchantName=彰化銀行信用卡代繳台北縣停車費用專戶&customize=&lidm=00920100111144947&purchAmt=1&CurrencyNote=&currency=&amtExp=&AutoCap=1",
					"Big5", 30000));
			System.out.println("ResponseCode=" + conn.getResponseCode());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 建構元
	 * 
	 * @param urlPath
	 */
	public HttpConnection(String urlPath) {
		this.urlPath = urlPath;
	}

	/**
	 * 接收訊息
	 * 
	 * @param charsetName
	 *            編碼 (eg. Big5)
	 * @param timeout
	 *            單位 ms
	 * @return
	 * @throws IOException
	 */
	public String Receive(String charsetName, int timeout) throws IOException {
		BufferedReader br = null;

		try {
			URL url = new URL(urlPath);
			URLConnection connection = (URLConnection) url.openConnection();

			if (timeout > 0) {
				connection.setConnectTimeout(timeout);
			}
			HttpURLConnection httpUrlConn = (HttpURLConnection) connection;
			httpUrlConn.connect();
			responseCode = httpUrlConn.getResponseCode();

			if (charsetName == null) {
				br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			} else {
				br = new BufferedReader(new InputStreamReader(connection.getInputStream(), charsetName));
			}

			String text = null;
			StringBuffer receiveData = new StringBuffer();
			while ((text = br.readLine()) != null) {
				receiveData.append(text).append("\n");
			}

			return receiveData.toString();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (Exception e) {

				}
			}
		}
	}

	/**
	 * 接收訊息
	 * 
	 * @param sRequest
	 * @param charsetName
	 * @param timeout
	 * @return
	 * @throws IOException
	 */
	public String Receive(String sRequest, String charsetName, int timeout) throws IOException {
		BufferedReader br = null;

		try {
			URL url = new URL(urlPath);
			URLConnection connection = (URLConnection) url.openConnection();

			if (timeout > 0) {
				connection.setConnectTimeout(timeout);
			}

			HttpURLConnection httpUrlConn = (HttpURLConnection) connection;
			httpUrlConn.setDoOutput(true);
			httpUrlConn.setDoInput(true);
			httpUrlConn.setRequestProperty("Content-Length", Integer.toString(sRequest.length()));
			httpUrlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			httpUrlConn.setRequestMethod("POST");
			httpUrlConn.connect();
			//
			OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
			writer.write(sRequest);
			writer.flush();
			writer.close();
			//
			responseCode = httpUrlConn.getResponseCode();
			//
			if (charsetName == null) {
				br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			} else {
				br = new BufferedReader(new InputStreamReader(connection.getInputStream(), charsetName));
			}

			String text = null;
			StringBuffer receiveData = new StringBuffer();
			while ((text = br.readLine()) != null) {
				receiveData.append(text).append("\n");
			}

			return receiveData.toString();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (Exception e) {

				}
			}

		}
	}

	/**
	 * 取得 HTTP回應Code
	 * 
	 * @return
	 */
	public int getResponseCode() {
		return responseCode;
	}

}
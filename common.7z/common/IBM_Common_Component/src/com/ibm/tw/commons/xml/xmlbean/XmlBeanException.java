/*
 * ===========================================================================
 * IBM Confidential AIS Source Materials
 * 
 * XML Bean Base Class
 * 
 * (C) Copyright IBM Corp. 2005.
 * 
 * ===========================================================================
 */
package com.ibm.tw.commons.xml.xmlbean;

 

import java.util.ArrayList;
import java.util.List;

import org.apache.xmlbeans.XmlError;

/**
 * XML Bean Exception
 * 
 * @author Jeff
 * @version 1.0, 2004/11/15
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class XmlBeanException extends Exception  {
   	
	protected List<XmlError> m_validationMessages = new ArrayList<XmlError>();

	
	protected String m_sXml = "";

	public XmlBeanException() {
   		
		super();
	}
   
	public XmlBeanException(String sMsg) {
   	
		super(sMsg);
	}
   
	 
   
	public XmlBeanException(String sMsg, Throwable cause) {
   	
		super(sMsg, cause);
	 	 
		
	}

	public XmlBeanException(String sMsg, String sXml, Throwable cause) {
	    super(sMsg, cause);
	    
	    setXml(sXml);
	}
	
	public void setXml(String sXml) {
	    m_sXml = sXml;
	}
	
	public String getXml() {
	    return m_sXml;
	}

	 
	public void setValidationMessages(List<XmlError> messages) {
	    
	    m_validationMessages = messages;
	}
  
 
  


}

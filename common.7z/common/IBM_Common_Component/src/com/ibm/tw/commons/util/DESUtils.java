/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2007.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.util;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.security.Key;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
//import sun.security.provider.*;
import com.ibm.tw.commons.exception.CryptException;

/**
 * 資料加解密工具<BR>
 * DES: The Digital Encryption Standard as described in FIPS PUB 46-2.<BR>
 * ECB: Electronic Codebook Mode, as defined in: The National Institute of Standards and Technology (NIST) Federal Information Processing Standard (FIPS) PUB 81, "DES Modes of Operation," U.S.
 * Department of Commerce, Dec 1980.<BR>
 * PKCS5Padding: The padding scheme described in: RSA Laboratories, "PKCS #5: Password-Based Encryption Standard," version 1.5, November 1993.<BR>
 * 
 * @author Kevin
 * @version 1.0, 2007/7/5
 * @see
 * @since
 */
public class DESUtils {
	/** Key */
	// private static String MYKEY = "IBMGBS";
	/** a secret key */
	private static Key key = null;

	/** cipher */
	private static Cipher cipher = null;

	/**  */
	private static Pattern m_aPattern = Pattern.compile("~[a-fA-F0-9]*~");

	/**
	 * @throws Exception
	 */
	private static void init() throws CryptException {
		// KeyGenerator generator = KeyGenerator.getInstance("DES");
		// generator.init(new SecureRandom(MYKEY.getBytes()));		
		//		
		// key = generator.generateKey();
		try {
			InputStream in = DESUtils.class.getResourceAsStream("key") ;
			key = (Key) new ObjectInputStream(in).readObject();
			// Get a cipher object
			cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
		}
		catch(Exception e) {
			throw new CryptException("cannot init DESUtils", e);
		}
	}

	/**
	 * 將資料加密
	 * 
	 * @param str
	 * @return
	 * @throws Exception
	 */
	public static String encrypt(String str) throws CryptException {
		return ConvertUtils.byteArray2HexString(encrypt(str.getBytes()));
	}

	/**
	 * 將資料加密
	 * 
	 * @param bytes
	 * @return
	 * @throws Exception
	 */
	public static synchronized byte[] encrypt(byte[] bytes) throws CryptException {
		if (key == null) {
			init();
		}
		
		byte[] result = null;
		try {
			cipher.init(Cipher.ENCRYPT_MODE, key);
			
			result = cipher.doFinal(bytes);
		}
		catch (Exception e) {
			throw new CryptException("cannot encrypt data, data = " + ConvertUtils.byteArray2HexString(bytes), e);
		}

		return result;
	}

	/**
	 * 將資料解密
	 * 
	 * @param hexString
	 * @return
	 * @throws Exception
	 */
	public static String decrypt(String hexString) throws CryptException {
		return new String(decrypt(ConvertUtils.hexString2ByteArray(hexString)));
	}

	/**
	 * 將資料解密
	 * 
	 * @param bytes
	 * @return
	 * @throws Exception
	 */
	public static synchronized byte[] decrypt(byte[] bytes) throws CryptException {
		if (key == null) {
			init();
		}
		byte[] data = null;
		
		try {
			cipher.init(Cipher.DECRYPT_MODE, key);
			
			data = cipher.doFinal(bytes);
		}
		catch (Exception e) {
			
			throw new CryptException("cannot decrypt, data = " + ConvertUtils.byteArray2HexString(bytes), e);
		}

		return data;
	}

	/**
	 * 是否為加入識別字的DES加密資料
	 * 
	 * @param hexString
	 */
	public static boolean isMaskDESEncrypt(String sHexString) {
		return m_aPattern.matcher(sHexString).matches();
	}

	/**
	 * 取得 去除識別字 資料加密
	 * 
	 * @param makeHexString
	 * @return
	 */
	public static String getEncrypt(String sMaskHexString) {
		return sMaskHexString.replaceAll("~", "");
	}

	/**
	 * 取得 加入識別字 資料加密
	 * 
	 * @param hexString
	 * @return
	 */
	public static String getMaskEncrypt(String sHexString) {
		return "~" + sHexString + "~";
	}
	
	public static void main(String[] args) {
		try {
			String s = "ftpuser";
			
//			s = DESUtils.getMaskEncrypt(s);
			
			s = DESUtils.encrypt(s);
			
			System.out.println("s =" + s + "==");
			
			boolean flag = DESUtils.isMaskDESEncrypt(s);
			
			System.out.println("flag = " + flag);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

//	public static void main(String[] args) {
//		try {
//			KeyGenerator generator = KeyGenerator.getInstance("DES");
//			generator.init(new SecureRandom(MYKEY.getBytes()));
//			key = generator.generateKey();
//			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("D:/key"));
//			out.writeObject(key);
//			out.flush();
//			out.close();
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
}

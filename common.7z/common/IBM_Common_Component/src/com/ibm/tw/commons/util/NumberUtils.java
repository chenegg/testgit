package com.ibm.tw.commons.util;

public class NumberUtils extends org.apache.commons.lang.math.NumberUtils {
	private NumberUtils() {

	}

	/**
	 * 取餘數
	 * @param rr
	 * @return
	 */
	public static int mod(int iVal) {
		return iVal == 0 ? 0 : iVal % 10;
	}

	/**
	*
	* @param sNumeric input value
	* @param iDecimal 小數位數
	* @param length 長度
	* @param paddChar padding char 0x30
	* @return
	*/
	public static String formatNumericStr(String sNumeric, int iDecimal, int length, char paddChar) {
		boolean bRc = true;
		String sResult = sNumeric;
		if (isNumber(sNumeric)) {
			int iLength = sNumeric.length();
			int iNu = sNumeric.indexOf(".");
			if (iNu > 0) {
				if (iNu + iDecimal + 1 < iLength) {
					iLength = iNu + iDecimal + 1;
				}
			}
			StringBuilder aBuf = new StringBuilder();
			for (int i = 0; i < iLength; i++) {
				char Char = sNumeric.charAt(i);
				if (bRc) {
					if (Char != 0x30) {
						bRc = false;
						aBuf.append(Char);
					}
				} else {
					aBuf.append(Char);
				}
			}

			sResult = aBuf.toString();

			if (sResult.length() == 0) {
				sResult = ".";
			}

			if (sResult.substring(0, 1).equals(".")) {
				sResult = "0" + sResult;
			}

			// padding right
			iLength = sResult.length();
			iNu = sResult.indexOf(".");
			if (iNu > 0) {
				if (iLength - iNu - 1 < iDecimal) {
					sResult = StringUtils.rightPad(sResult, iDecimal + iNu + 1, paddChar);
				}
			}

			// padding left
			sResult = StringUtils.leftPad(sResult, length, paddChar);

			if (iDecimal == 0) {
				int iDecimalBegin = sResult.indexOf('.');
				if (iDecimalBegin > 0) {
					sResult = sResult.substring(0, iDecimalBegin);
				}
			}
		}

		return sResult;
	}

}

/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mb;

import com.ibm.broker.config.proxy.ConfigManagerProxyException;



/**
 * <p> MB Exception </p>
 *
 * @author  Hank
 * @version 1.0, 2011/8/17
 * @see	    
 * @since 
 */
public class CMBException extends Exception{

	// Broker 內定的 Exception
	public final static String WMB_PROD_EXCEPTION = "9999"; 
	
	// 找不到 Broker
	public final static String WMB_BROKER_NOTFOUND = "0001";
	
	// 找不到 ExecuteGroup
	public final static String WMB_EXECGROUP_NOTFOUND = "0002";
	
	// 找不到 Flow
	public final static String WMB_FLOW_NOTFOUND = "0003";
	
	
	private ConfigManagerProxyException mbException;
	
	private String statusCode;
	
	private String statusDesc;
	
	
	/**
	 * Constructor
	 * @param ex
	 */
	public CMBException(ConfigManagerProxyException ex){
		
		super();
		mbException = ex;
		
		statusCode = WMB_PROD_EXCEPTION;
		statusDesc = ex.getMessage();
	}
	
	
	/**
	 * Constructor
	 * @param statusCode
	 * @param statusDesc
	 */
	public CMBException(String statusCode, String statusDesc){
	
		this.statusCode = statusCode;
		this.statusDesc = statusDesc;
	}


	
	public String getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}


	public String getStatusDesc() {
		return statusDesc;
	}
	
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
		
}



 
package com.ibm.tw.commons.util;

import java.util.ArrayList;

/**
 * Excel工具,新增每列資料
 * @author Egg.chen
 *
 */
public class ExcelContent {

	private ArrayList<ArrayList<String>> datas = null;

	/**
	 * 取得整列的資料
	 * @param row
	 * @return
	 */
	public ArrayList<String> getRecord(int row) {
		ArrayList<String> record = new ArrayList<String>();
		if (getSize() > 0) {
			record = this.getDatas().get(row);
		}
		return record;
	}

	/**
	 * 取得excel每列每欄的資料
	 * @param row
	 * @param column
	 * @return
	 */
	public String getRecordValue(int row, int column) {
		String value = "";
		if (getSize() > 0) {
			ArrayList<String> record = getDatas().get(row);
			if (record != null && record.size() > 0) {
				value = record.get(column);
			}
		}
		return value;
	}

	/**
	 * 取得筆數
	 * @return
	 */
	public int getSize() {
		return getDatas().size();
	}

	/**
	 * 新增一筆列
	 * @param row
	 */
	public void addRecord(ArrayList<String> row) {
		getDatas().add(row);
	}

	/**
	 * 列的集合
	 * @return
	 */
	private ArrayList<ArrayList<String>> getDatas() {
		if (datas == null) {
			datas = new ArrayList<ArrayList<String>>();
		}
		return datas;
	}

	public void setDatas(ArrayList<ArrayList<String>> datas) {
		this.datas = datas;
	}
}

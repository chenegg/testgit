package com.ibm.tw.commons.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 檔案處理工具集
 * <p>
 * 檔案工具集主要功能繼承自{@link org.apache.commons.io.FileUtils}， 並增加下列功能：
 * <ul>
 * <li>read file to bye array</li>
 * <li>write file to bye array</li>
 * </ul>
 * </p>
 * 
 * @author Jeff Liu
 * @version 1.0, 2004/10/18
 * @see {@link org.apache.commons.io.FileUtils}
 * @since
 */
public class FileUtils extends org.apache.commons.io.FileUtils {

	// private static Log m_logger = LogFactory.getLog(FileUtils.class);
	private static Logger m_logger = LoggerFactory.getLogger(FileUtils.class);

	public static byte[] readFileToByteArray(File file) throws IOException {

		InputStream in = new java.io.FileInputStream(file);
		try {
			return IOUtils.toByteArray(in);
		} finally {
			IOUtils.closeQuietly(in);
		}

	}

	/**
	 * 
	 * @param sFileName
	 * @return
	 * @throws IOException
	 */
	public static byte[] readFileToByteArray(String sFileName) throws IOException {

		if (StringUtils.isBlank(sFileName)) {
			return null;
		}

		byte[] data = null;

		File file = new File(sFileName);

		data = readFileToByteArray(file);

		return data;
	}

	/**
	 * 
	 * @param sFileName
	 * @return
	 */
	public static byte[] readFileToByteArrayQuietly(String sFileName) {

		if (StringUtils.isBlank(sFileName)) {
			return null;
		}

		byte[] data = null;

		try {
			File file = new File(sFileName);

			data = readFileToByteArray(file);
		} catch (IOException e) {
			// quiet

			data = null;

		}

		return data;
	}

	public static String readFileToString(String sFileName, String sEncoding) throws IOException {
		if (StringUtils.isBlank(sFileName)) {
			return null;
		}

		String sData = null;

		File file = new File(sFileName);

		sData = readFileToString(file, sEncoding);

		return sData;
	}

	public static String readFileToStringQuietly(String sFileName, String sEncoding) {
		if (StringUtils.isBlank(sFileName)) {
			return null;
		}

		String sData = null;

		try {
			File file = new File(sFileName);

			sData = readFileToString(file, sEncoding);
		} catch (IOException e) {
			// quiet

			sData = null;

		}

		return sData;
	}

	/**
	 * <p>
	 * Writes data to a file. The file will be created if it does not exist.
	 * </p>
	 * 
	 * @param file
	 *            the file to write.
	 * @param data
	 *            The content to write to the file.
	 * @throws IOException
	 *             in case of an I/O error
	 */
	public static void writeByteArrayToFile(File file, byte[] data) throws IOException {
		OutputStream out = new java.io.FileOutputStream(file);
		try {
			out.write(data);
		} finally {
			IOUtils.closeQuietly(out);
		}
	}

	/**
	 * <p>
	 * Writes data to a file. The file will be created if it does not exist.
	 * </p>
	 * 
	 * @param sFileName
	 *            the file name to write
	 * @param sData
	 *            the content to write to the file name
	 * @param sEncoding
	 *            encoding to use
	 */
	public static void writeStringToFile(String sFileName, String sData, String sEncoding) throws IOException {

		if (StringUtils.isBlank(sFileName) || StringUtils.isBlank(sEncoding)) {
			return;
		}

		File file = new File(sFileName);
		writeStringToFile(file, sData, sEncoding);
		/*
		 * BufferedOutputStream out = null; try {
		 * 
		 * out = new BufferedOutputStream(new FileOutputStream(sFileName));
		 * 
		 * out.write(sData.getBytes(sEncoding)); } finally { if (out != null) {
		 * out.flush(); out.close(); } }
		 */
	}

	/**
	 * <p>
	 * Writes data to a file. The file will be created if it does not exist.
	 * </p>
	 * 
	 * @param sFileName
	 *            the file name to write
	 * @param data
	 *            the content to write to the file name
	 */
	public static void writeByteArrayToFileQuietly(String sFileName, byte[] data) {

		if (StringUtils.isBlank(sFileName)) {
			return;
		}

		try {
			File file = new java.io.File(sFileName);

			writeByteArrayToFile(file, data);
		} catch (IOException e) {
			// quietly
		}
	}

	public static void writeByteArrayToFile(String sFileName, byte[] data) throws IOException {

		if (StringUtils.isBlank(sFileName)) {
			return;
		}

		File file = new java.io.File(sFileName);

		writeByteArrayToFile(file, data);

	}

	/**
	 * Copies a file to a directory preserving the file date. <br>
	 * 
	 * @param srcFile
	 *            an existing file to copy, must not be null
	 * @param destDir
	 *            the directory to place the copy in, must not be null
	 */
	public static void copyFileToDirectoryQuietly(File srcFile, File destDir) {

		try {

			copyFileToDirectory(srcFile, destDir);
		} catch (IOException e) {
			// quietly
		}

	}

	/**
	 * List file names by dir path name
	 * 
	 * @param filePath
	 * @return
	 */
	public static List<String> listFileNamesQuietly(String filePath) {

		List<String> fileNames = new ArrayList<String>();

		try {
			File dir = new File(filePath);

			Collection<File> files = listFiles(dir, null, true);

			Iterator<File> iter = files.iterator();

			while (iter.hasNext()) {

				File file = iter.next();

				fileNames.add(file.getName());

			}

		} catch (Exception e) {
			m_logger.error(e.getMessage(), e);
		}
		return fileNames;
	}

	/**
	 * 
	 * @param dirName
	 * @throws IOException 
	 */
	public static void forceMkdir(String dirName) throws IOException {
		if (StringUtils.isBlank(dirName)) {
			return;
		}

		dirName = FilenameUtils.normalizeDir(dirName);
		File dir = new java.io.File(dirName);

		FileUtils.forceMkdir(dir);
	}

	/**
	 * 弱掃  valid for 'Path Manipulation'
	 * @param filePath
	 * 
	 */
	public static String validPathManipulation(String fPath) {

		System.out.println(123);

		String[][] tmpArr = { { "a", "a" }, { "b", "b" }, { "c", "c" }, { "d", "d" }, { "e", "e" }, { "f", "f" },
				{ "g", "g" }, { "h", "h" }, { "i", "i" }, { "j", "j" }, { "k", "k" }, { "l", "l" }, { "m", "m" },
				{ "n", "n" }, { "o", "o" }, { "p", "p" }, { "q", "q" }, { "r", "r" }, { "s", "s" }, { "t", "t" },
				{ "u", "u" }, { "v", "v" }, { "w", "w" }, { "x", "x" }, { "y", "y" }, { "z", "z" }, { "A", "A" },
				{ "B", "B" }, { "C", "C" }, { "D", "D" }, { "E", "E" }, { "F", "F" }, { "G", "G" }, { "H", "H" },
				{ "I", "I" }, { "J", "J" }, { "K", "K" }, { "L", "L" }, { "M", "M" }, { "N", "N" }, { "O", "O" },
				{ "P", "P" }, { "Q", "Q" }, { "R", "R" }, { "S", "S" }, { "T", "T" }, { "U", "U" }, { "V", "V" },
				{ "W", "W" }, { "X", "X" }, { "Y", "Y" }, { "Z", "Z" }, { ":", ":" }, { ".", "." }, { "/", "/" },
				{ "\\", "\\" }, { ".", "." }, { "_", "_" }, { "1", "1" }, { "2", "2" }, { "3", "3" }, { "4", "4" },
				{ "5", "5" }, { "6", "6" }, { "7", "7" }, { "8", "8" }, { "9", "9" }, { "0", "0" } };

		@SuppressWarnings("unchecked")
		Map<String, String> map = ArrayUtils.toMap(tmpArr);

		String returnStr = "";
		for (int i = 0; i < fPath.length(); i++) {
			if (map.get(fPath.charAt(i) + "") != null) {
				returnStr += map.get(fPath.charAt(i) + "");
			}
		}
		return returnStr;

	}

	public static void main(String[] args) {

		String thePath = "f:/aaa/bbb/cd.txt";
		System.out.println(validPathManipulation(thePath));

		/*
		 * String path = "e:/tmp/ftp/TWBATCH00120090323/";
		 * 
		 * System.out.println("path = " + FilenameUtils.normalizeDir(path));
		 * 
		 * try { FileUtils.forceMkdir(path); } catch (IOException e) { // TODO
		 * 自動產生 catch 區塊 e.printStackTrace(); }
		 */

		// List<String> fileNames = listFileNamesQuietly(path);
		//
		// System.out.println("file count = " + fileNames.size());
		//
		// for (String fileName : fileNames) {
		// System.out.println("File Name = " + fileName);
		// }
	}

}

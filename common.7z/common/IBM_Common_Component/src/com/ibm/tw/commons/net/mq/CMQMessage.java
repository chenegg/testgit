/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2005.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;

 
import java.io.UnsupportedEncodingException;
import org.apache.commons.lang.ClassUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.tw.commons.util.ConvertUtils;
 

/**
 * Common MQ Message
 * 
 * @author jeff
 * @version 1.0, 2005/11/28
 * @see com.ibm.mq.MQMessage
 * @since
 * 
 */
public abstract class CMQMessage implements Cloneable {

	/** Default Encoding: UTF8 */
	public final static int DEFAULT_CCSID = 1208;

	/** MQMD */
	protected CMQMD m_mqmd = null;

	/** Message Data */
	protected byte[] m_messageData = null;

	/** common logger */
	protected static Log m_logger = LogFactory.getLog(CMQMessage.class);

	/**
	 * 
	 */
	public CMQMessage() {
		m_mqmd = new CMQMD();

	}
	
	/**
	 * CMQMessage -> MQMessage
	 * 
	 * @return
	 */
	public abstract MQMessage toMQMessage() throws MQException;
 
	/**
	 * 設定 Message Data
	 * 
	 * @param messageData
	 */
	public void setMessageData(byte[] messageData) {

		m_messageData = messageData;

	}
 
	/**
	 * 取得 Message Data
	 * 
	 * @return
	 */
	public byte[] getMessageData() {
		return m_messageData;
	}

	 

	/**
	 * 取得 Message Data
	 * 
	 * @return
	 */
	public String getMessageStr() {
		byte[] data = getMessageData();

		String sData = "";
		try {
			sData = new String(data, ConvertUtils.ccsid2Encoding(getCCSID()));
		}
		catch (UnsupportedEncodingException e) {
			getLogger().error(e);
		}
		return sData;
	}

	/**
	 * 是否有效
	 * 
	 * @param iExpiry
	 */
	public void setExpiry(int expiry) {
		m_mqmd.setExpiry(expiry);
		// this.mqMessage.expiry = iExpiry;
	}

	public void setReplyToQueueName(String sReplyToQueueName) {
		m_mqmd.setReplyToQueueName(sReplyToQueueName);
	}
	
	/**
	 * 取得 是否有效
	 * 
	 * @return
	 */
	public int getExpiry() {
		return m_mqmd.getExpiry();
	}
 

	 
	/**
	 * 設定 CCSID
	 * 
	 * @param iCCSID
	 */
	public void setCCSID(int ccsid) {

		m_mqmd.setCharacterSet(ccsid);
	}

	/**
	 * 取得 CCSID
	 * 
	 * @return
	 */
	public int getCCSID() {
		return m_mqmd.getCharacterSet();
	}

	/**
	 * 設定 Message ID
	 * 
	 * @param mqid
	 */
	public void setMessageId(byte[] mqid) {
		m_mqmd.setMessageId(mqid);
	}

	/**
	 * 取得 Message ID
	 * 
	 * @return
	 */
	public byte[] getMessageId() {
		return m_mqmd.getMessageId();
	}

	/**
	 * 設定 Message ID
	 * 
	 * @param sMessageId
	 */
	public void setMessageId(String sMessageId) {
		setMessageId(sMessageId.getBytes());
	}

	/**
	 * 設定 Group ID
	 * 
	 * @param data
	 */
	public void setGroupId(byte[] groupId) {

		// this.mqMessage.groupId = data;
		// this.mqMessage.messageFlags |= MQC.MQMF_LAST_MSG_IN_GROUP |
		// MQC.MQMF_MSG_IN_GROUP;

		m_mqmd.setGroupId(groupId);
	}

	/**
	 * 取得 Group ID
	 * 
	 * @return
	 */
	public byte[] getGroupId() {

		return m_mqmd.getGroupId();
	}

	/**
	 * 設定 Correlation ID
	 * 
	 * @param data
	 */
	public void setCorrelationId(byte[] correlationId) {

		m_mqmd.setCorrelationId(correlationId);
	}

	/**
	 * 取得 Correlation ID
	 * 
	 * @return
	 */
	public byte[] getCorrelationId() {
		return m_mqmd.getCorrelationId();
	}

	/**
	 * 設定 Group ID
	 * 
	 * @param sGroupId
	 */
	public void setGroupId(String sGroupId) {
		setGroupId(sGroupId.getBytes());
	}

	/**
	 * 設定 Correlation ID
	 * 
	 * @param sCorrelationId
	 */
	public void setCorrelationId(String sCorrelationId) {
		setCorrelationId(sCorrelationId.getBytes());
	}

	/**
	 * 設定 Format
	 * 
	 * @param sFormat
	 */
	public void setFormat(String format) {
		m_mqmd.setFormat(format);
	}

	/**
	 * 
	 * @return
	 */
	public String getFormat() {
		return m_mqmd.getFormat();
	}

  

	/**
	 * 取得 Log
	 * 
	 * @return
	 */
	protected Log getLogger() {
		return m_logger;
	}

}

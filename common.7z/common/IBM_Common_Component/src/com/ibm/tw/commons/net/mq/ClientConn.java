/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.ibm.tw.commons.net.mq;



/**
 * <p> 應用程式連線資訊 </p>
 *
 * @author  Hank
 * @version 1.0, 2011/8/19
 * @see	    
 * @since 
 */
public class ClientConn {

	// 連線 ID
	private byte[] connectionId;
	
	// 連線種類
	private int connInfoType;
	
	// 程式名稱
	private String applTag;
	
	//
	private int applType;
		
	// 通道名稱
	private String channelName;
	
	// 連線名稱
	private String connectionName;
	
	//
	private String connectionOptions;

	// 程序
	private int processId;
	
	//
	private String taskNumber;
	
	// 執行緒
	private int threadId;

	// recovery identifier 
	private byte[] UOWIdentifier;
	
	// work start date
	private String UOWLogStartDate;
	
	// work start time
	private String UOWLogStartTime;
	
	// work creation date 
	private String UOWStartDate;
	
	// work creation time 
	private String UOWStartTime;
	
	// unit of work 
	private int UOWState;
	
	// 
	private int UOWType;
	
	// User identifier 
	private String userId;

	
	public byte[] getConnectionId() {
		return connectionId;
	}

	
	public void setConnectionId(byte[] connectionId) {
		this.connectionId = connectionId;
	}

	
	public int getConnInfoType() {
		return connInfoType;
	}

	
	public void setConnInfoType(int connInfoType) {
		this.connInfoType = connInfoType;
	}

	
	public String getApplTag() {
		return applTag;
	}

	
	public void setApplTag(String applTag) {
		this.applTag = applTag;
	}

	
	public int getApplType() {
		return applType;
	}

	
	public void setApplType(int applType) {
		this.applType = applType;
	}
	
	
	public String getChannelName() {
		return channelName;
	}

	
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	
	public String getConnectionName() {
		return connectionName;
	}

	
	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}

	
	public String getConnectionOptions() {
		return connectionOptions;
	}

	
	public void setConnectionOptions(String connectionOptions) {
		this.connectionOptions = connectionOptions;
	}

	
	public int getProcessId() {
		return processId;
	}

	
	public void setProcessId(int processId) {
		this.processId = processId;
	}

	
	public String getTaskNumber() {
		return taskNumber;
	}

	
	public void setTaskNumber(String taskNumber) {
		this.taskNumber = taskNumber;
	}

	
	public int getThreadId() {
		return threadId;
	}

	
	public void setThreadId(int threadId) {
		this.threadId = threadId;
	}

	
	public byte[] getUOWIdentifier() {
		return UOWIdentifier;
	}

	
	public void setUOWIdentifier(byte[] identifier) {
		UOWIdentifier = identifier;
	}

	
	public String getUOWLogStartDate() {
		return UOWLogStartDate;
	}

	
	public void setUOWLogStartDate(String logStartDate) {
		UOWLogStartDate = logStartDate;
	}

	
	public String getUOWLogStartTime() {
		return UOWLogStartTime;
	}

	
	public void setUOWLogStartTime(String logStartTime) {
		UOWLogStartTime = logStartTime;
	}

	
	public String getUOWStartDate() {
		return UOWStartDate;
	}

	
	public void setUOWStartDate(String startDate) {
		UOWStartDate = startDate;
	}

	
	public String getUOWStartTime() {
		return UOWStartTime;
	}

	
	public void setUOWStartTime(String startTime) {
		UOWStartTime = startTime;
	}

	
	public int getUOWState() {
		return UOWState;
	}

	
	public void setUOWState(int state) {
		UOWState = state;
	}

	
	public int getUOWType() {
		return UOWType;
	}

	
	public void setUOWType(int type) {
		UOWType = type;
	}

	
	public String getUserId() {
		return userId;
	}

	
	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	// This parameter is valid only on z/OS.
	// private String ASID;

	// This parameter is valid only on z/OS.
	// private String OriginName;
	
	// This parameter is valid only on z/OS.
	// private String OriginUOWId;
		
	// This parameter is valid only on z/OS.
	// private String PSBName;
	
	// This parameter is valid only on z/OS.
	// private String PSTId;
	
	// This parameter is valid only on z/OS.
	// private String QMgrUOWId;
	
	// This parameter is not valid on z/OS.
	// private String StartUOWLogExtent;
		
	// This parameter is valid only on z/OS.
	// private String TransactionId;
	
	
}



 